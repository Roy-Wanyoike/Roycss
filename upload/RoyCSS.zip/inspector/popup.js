/**
 * RoyCSS Inspector — Popup Script
 *
 * Handles the "Inspect Element" button click and displays results.
 */

document.getElementById("inspectBtn").addEventListener("click", async () => {
  const btn = document.getElementById("inspectBtn");
  btn.textContent = "Click an element on the page...";
  btn.disabled = true;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: inspectElement,
    });
  } catch (err) {
    btn.textContent = "Error: " + err.message;
    btn.disabled = false;
  }
});

// Listen for results from the content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "INSPECTION_RESULT") {
    displayResults(request.data);
    const btn = document.getElementById("inspectBtn");
    btn.textContent = "Inspect Another Element";
    btn.disabled = false;
  }
});

function displayResults(data) {
  const results = document.getElementById("results");
  results.style.display = "block";
  results.innerHTML = `
    <div class="result-section">
      <h3>Element</h3>
      <div class="result-row">
        <span class="label">Tag</span>
        <span class="value">${data.tagName}</span>
      </div>
      <div class="result-row">
        <span class="label">Classes</span>
        <span class="value">${data.className || "(none)"}</span>
      </div>
      <div class="result-row">
        <span class="label">Size</span>
        <span class="value">${data.width} × ${data.height}px</span>
      </div>
    </div>

    <div class="result-section">
      <h3>Colors</h3>
      <div class="result-row">
        <span class="label">Background</span>
        <span class="value"><span class="swatch" style="background:${data.bgColor}"></span>${data.bgColor}</span>
      </div>
      <div class="result-row">
        <span class="label">Text</span>
        <span class="value"><span class="swatch" style="background:${data.textColor}"></span>${data.textColor}</span>
      </div>
      <div class="result-row">
        <span class="label">Border</span>
        <span class="value"><span class="swatch" style="background:${data.borderColor}"></span>${data.borderColor}</span>
      </div>
    </div>

    <div class="result-section">
      <h3>Spacing</h3>
      <div class="result-row">
        <span class="label">Padding</span>
        <span class="value">${data.padding}</span>
      </div>
      <div class="result-row">
        <span class="label">Margin</span>
        <span class="value">${data.margin}</span>
      </div>
    </div>

    <div class="result-section">
      <h3>Visual</h3>
      <div class="result-row">
        <span class="label">Border Radius</span>
        <span class="value">${data.borderRadius}</span>
      </div>
      <div class="result-row">
        <span class="label">Box Shadow</span>
        <span class="value">${data.boxShadow === "none" ? "none" : data.boxShadow.slice(0, 40) + "..."}</span>
      </div>
      <div class="result-row">
        <span class="label">Font Size</span>
        <span class="value">${data.fontSize}</span>
      </div>
      <div class="result-row">
        <span class="label">Font Weight</span>
        <span class="value">${data.fontWeight}</span>
      </div>
    </div>

    <div class="result-section">
      <h3>RoyCSS Equivalent</h3>
      <div class="result-row">
        <span class="label">Radius</span>
        <span class="roycss-equiv">${data.roycssRadius}</span>
      </div>
      <div class="result-row">
        <span class="label">Shadow</span>
        <span class="roycss-equiv">${data.roycssShadow}</span>
      </div>
      <div class="result-row">
        <span class="label">Spacing</span>
        <span class="roycss-equiv">${data.roycssSpacing}</span>
      </div>
      <div class="result-row">
        <span class="label">Suggested Effects</span>
        <span class="roycss-equiv">${data.suggestions}</span>
      </div>
    </div>
  `;
}

// This function runs in the page context
function inspectElement() {
  // Remove any existing inspector
  const existing = document.getElementById("roycss-inspector-overlay");
  if (existing) existing.remove();

  // Create overlay
  const overlay = document.createElement("div");
  overlay.id = "roycss-inspector-overlay";
  overlay.style.cssText = `
    position: fixed;
    inset: 0;
    z-index: 999999;
    cursor: crosshair;
    background: transparent;
  `;

  // Create highlight box
  const highlight = document.createElement("div");
  highlight.style.cssText = `
    position: absolute;
    border: 2px solid oklch(0.6 0.2 162);
    background: color-mix(in oklch, oklch(0.6 0.2 162) 10%, transparent);
    pointer-events: none;
    transition: all 0.1s ease;
    display: none;
  `;

  overlay.appendChild(highlight);
  document.body.appendChild(overlay);

  // Mouse move handler
  overlay.addEventListener("mousemove", (e) => {
    overlay.style.display = "none";
    const el = document.elementFromPoint(e.clientX, e.clientY);
    overlay.style.display = "block";

    if (el && el !== overlay && el !== highlight) {
      const rect = el.getBoundingClientRect();
      highlight.style.display = "block";
      highlight.style.left = rect.left + "px";
      highlight.style.top = rect.top + "px";
      highlight.style.width = rect.width + "px";
      highlight.style.height = rect.height + "px";
    }
  });

  // Click handler
  overlay.addEventListener("click", (e) => {
    overlay.style.display = "none";
    const el = document.elementFromPoint(e.clientX, e.clientY);
    overlay.remove();

    if (!el) return;

    const style = window.getComputedStyle(el);

    // Helper: convert CSS value to RoyCSS equivalent
    function toRoyCSSRadius(radius) {
      const val = parseFloat(radius);
      if (radius.includes("50%") || radius.includes("9999")) return "roycss radius: full";
      if (val === 0) return "roycss radius: none";
      if (val <= 4) return "roycss radius: sm";
      if (val <= 8) return "roycss radius: md";
      if (val <= 16) return "roycss radius: lg";
      return "roycss radius: xl";
    }

    function toRoyCSSShadow(shadow) {
      if (shadow === "none") return "roycss shadow: none";
      if (shadow.includes("0 0") && shadow.includes("px")) return "roycss glow effect";
      if (shadow.split(",").length >= 3) return "roycss shadow: xl";
      if (shadow.includes("10px") || shadow.includes("12px")) return "roycss shadow: lg";
      if (shadow.includes("4px") || shadow.includes("6px")) return "roycss shadow: md";
      return "roycss shadow: sm";
    }

    function toRoyCSSSpacing(padding) {
      const val = parseFloat(padding);
      if (val === 0) return "roycss spacing: none";
      if (val <= 4) return "roycss spacing: sm";
      if (val <= 8) return "roycss spacing: md";
      if (val <= 16) return "roycss spacing: lg";
      return "roycss spacing: xl";
    }

    function suggestEffects(el, style) {
      const suggestions = [];
      if (style.backdropFilter !== "none") suggestions.push("glassmorphism");
      if (style.animationName !== "none") suggestions.push("animation");
      if (style.transform.includes("rotate")) suggestions.push("rotate");
      if (style.transform.includes("scale")) suggestions.push("scale");
      if (style.boxShadow.includes("0 0")) suggestions.push("glow");
      if (parseFloat(style.borderRadius) >= 20) suggestions.push("rounded");
      if (style.background.includes("gradient")) suggestions.push("gradient");
      return suggestions.length > 0
        ? suggestions.map((s) => "roycss-" + s).join(", ")
        : "Search roycss effects for matching styles";
    }

    const data = {
      tagName: el.tagName.toLowerCase(),
      className: el.className?.toString?.()?.slice(0, 60) || "",
      width: Math.round(el.getBoundingClientRect().width),
      height: Math.round(el.getBoundingClientRect().height),
      bgColor: style.backgroundColor,
      textColor: style.color,
      borderColor: style.borderColor,
      padding: style.padding,
      margin: style.margin,
      borderRadius: style.borderRadius,
      boxShadow: style.boxShadow,
      fontSize: style.fontSize,
      fontWeight: style.fontWeight,
      roycssRadius: toRoyCSSRadius(style.borderRadius),
      roycssShadow: toRoyCSSShadow(style.boxShadow),
      roycssSpacing: toRoyCSSSpacing(style.padding),
      suggestions: suggestEffects(el, style),
    };

    // Send to popup
    chrome.runtime.sendMessage({ type: "INSPECTION_RESULT", data });
  });

  // Escape to cancel
  overlay.addEventListener("keydown", (e) => {
    if (e.key === "Escape") overlay.remove();
  });
}
