export type EffectCategory =
  | "animations"
  | "hover"
  | "text"
  | "backgrounds"
  | "loaders"
  | "3d-transforms"
  | "buttons"
  | "cards"
  | "borders"
  | "filters"
  | "forms"
  | "navigation"
  | "scroll"
  | "cursor"
  | "page-transitions"
  | "glass-ui"
  | "particles"
  | "microinteractions"
  | "visual"
  | "misc";

export type PreviewType =
  | "box"
  | "text"
  | "button"
  | "loader"
  | "card"
  | "background";

export interface CSSEffect {
  id: string;
  name: string;
  category: EffectCategory;
  description: string;
  tags: string[];
  cssCode: string;
  previewType: PreviewType;
  /** Number of child <span> elements to render inside the preview (for loaders etc.) */
  childCount?: number;
  /** Text to display for text/button previews. Defaults to "RoyCSS" or "Hover Me". */
  previewText?: string;

  // ═══════════════════════════════════════════════════════════════
  // Design Genome — machine-readable metadata for AI, search, and tooling
  // ═══════════════════════════════════════════════════════════════

  /** Design Genome: spacing scale used by the effect (sm, md, lg, xl, none). */
  spacing?: "none" | "sm" | "md" | "lg" | "xl";
  /** Design Genome: border radius scale (none, sm, md, lg, full). */
  radius?: "none" | "sm" | "md" | "lg" | "full";
  /** Design Genome: shadow scale (none, sm, md, lg, xl). */
  shadow?: "none" | "sm" | "md" | "lg" | "xl";
  /** Design Genome: accessibility compliance level. */
  accessibility?: "AA" | "AAA" | "none";
  /** Design Genome: whether the effect is responsive (uses container queries or media queries). */
  responsive?: boolean;
  /** Design Genome: animation types used by the effect. */
  animations?: string[];
  /** Design Genome: design tokens referenced by the effect (e.g., "primary", "surface", "border"). */
  tokens?: string[];
  /** Design Genome: whether the effect uses modern CSS features. */
  modernCSS?: string[];
}

/**
 * Design Genome metadata for a single effect.
 * This powers AI search, visual catalog, Inspector, and Design Audit.
 */
export interface EffectGenome {
  id: string;
  name: string;
  category: string;
  spacing: string;
  radius: string;
  shadow: string;
  accessibility: string;
  responsive: boolean;
  animations: string[];
  tokens: string[];
  modernCSS: string[];
}

/**
 * Generates Design Genome metadata from a CSSEffect.
 * Analyzes the CSS code to infer properties when they're not explicitly set.
 */
export function getEffectGenome(effect: CSSEffect): EffectGenome {
  const css = effect.cssCode;

  // Infer spacing from padding values
  const hasPadding = /padding/i.test(css);
  const spacing = effect.spacing || (hasPadding ? "md" : "none");

  // Infer radius from border-radius
  const radiusMatch = css.match(/border-radius:\s*([^;]+)/i);
  const radiusValue = radiusMatch?.[1]?.trim() || "";
  const radius = effect.radius || (radiusValue.includes("50%") || radiusValue.includes("9999") ? "full" : radiusValue && radiusValue !== "0" ? "md" : "none");

  // Infer shadow from box-shadow
  const hasShadow = /box-shadow/i.test(css);
  const shadow = effect.shadow || (hasShadow ? "md" : "none");

  // Infer accessibility
  const accessibility = effect.accessibility || (/prefers-reduced-motion/i.test(css) ? "AA" : "none");

  // Infer responsive
  const responsive = effect.responsive || /@container|@media|container-type/i.test(css);

  // Infer animations
  const animations: string[] = effect.animations || [];
  if (!animations.length) {
    if (/animation:/i.test(css)) animations.push("animated");
    if (/transition:/i.test(css)) animations.push("transition");
    if (/@keyframes/i.test(css)) animations.push("keyframes");
    if (/transform.*rotate/i.test(css)) animations.push("rotate");
    if (/transform.*scale/i.test(css)) animations.push("scale");
    if (/transform.*translate/i.test(css)) animations.push("translate");
  }

  // Infer tokens
  const tokens: string[] = effect.tokens || [];
  if (!tokens.length) {
    if (/oklch\(0\.6.*162/i.test(css)) tokens.push("primary");
    if (/backdrop-filter/i.test(css)) tokens.push("glass");
    if (/var\(--/i.test(css)) tokens.push("custom-property");
    if (/color-mix/i.test(css)) tokens.push("color-mix");
  }

  // Infer modern CSS features
  const modernCSS: string[] = effect.modernCSS || [];
  if (!modernCSS.length) {
    if (/oklch\(/i.test(css)) modernCSS.push("oklch");
    if (/color-mix\(/i.test(css)) modernCSS.push("color-mix");
    if (/inline-size|block-size|inset-inline|inset-block|margin-block|margin-inline/i.test(css)) modernCSS.push("logical-properties");
    if (/@property/i.test(css)) modernCSS.push("custom-property");
    if (/@container/i.test(css)) modernCSS.push("container-queries");
    if (/:has\(/i.test(css)) modernCSS.push("has-selector");
    if (/backdrop-filter/i.test(css)) modernCSS.push("backdrop-filter");
    if (/conic-gradient/i.test(css)) modernCSS.push("conic-gradient");
    if (/clip-path/i.test(css)) modernCSS.push("clip-path");
    if (/perspective/i.test(css)) modernCSS.push("3d-transforms");
  }

  return {
    id: effect.id,
    name: effect.name,
    category: effect.category,
    spacing,
    radius,
    shadow,
    accessibility,
    responsive,
    animations,
    tokens,
    modernCSS,
  };
}

export const categoryMeta: Record<
  EffectCategory,
  { label: string; icon: string; color: string; description: string }
> = {
  animations: {
    label: "Animations",
    icon: "Play",
    color: "emerald",
    description: "Keyframe animations that bring elements to life",
  },
  hover: {
    label: "Hover Effects",
    icon: "MousePointer",
    color: "amber",
    description: "Interactive effects triggered on mouse hover",
  },
  text: {
    label: "Text Effects",
    icon: "Type",
    color: "rose",
    description: "Stunning text transformations and decorations",
  },
  backgrounds: {
    label: "Backgrounds",
    icon: "Layers",
    color: "violet",
    description: "Dynamic background patterns and gradients",
  },
  loaders: {
    label: "Loaders",
    icon: "Loader2",
    color: "sky",
    description: "Loading indicators and spinners",
  },
  "3d-transforms": {
    label: "3D & Transforms",
    icon: "Box",
    color: "orange",
    description: "Three-dimensional transformations and perspective effects",
  },
  buttons: {
    label: "Button Effects",
    icon: "MousePointerClick",
    color: "teal",
    description: "Interactive button animations and feedback",
  },
  cards: {
    label: "Card Effects",
    icon: "Square",
    color: "pink",
    description: "Card components with glass, borders, and reveals",
  },
  borders: {
    label: "Borders",
    icon: "Frame",
    color: "cyan",
    description: "Creative border styles and animated outlines",
  },
  filters: {
    label: "Filters",
    icon: "SlidersHorizontal",
    color: "indigo",
    description: "CSS filter effects for images and elements",
  },
  forms: {
    label: "Forms & Inputs",
    icon: "FormInput",
    color: "lime",
    description: "Form input effects and validations",
  },
  navigation: {
    label: "Navigation",
    icon: "Navigation",
    color: "fuchsia",
    description: "Menu, tab, and navigation animations",
  },
  scroll: {
    label: "Scroll Effects",
    icon: "ScrollText",
    color: "teal",
    description: "Scroll-triggered and scroll-linked animations",
  },
  cursor: {
    label: "Cursor Effects",
    icon: "MousePointer2",
    color: "rose",
    description: "Custom cursor and cursor-following effects",
  },
  "page-transitions": {
    label: "Page Transitions",
    icon: "ArrowLeftRight",
    color: "violet",
    description: "Full-page transition animations",
  },
  "glass-ui": {
    label: "Glass & Modern UI",
    icon: "GlassWater",
    color: "sky",
    description: "Glassmorphism, neumorphism, and modern surface effects",
  },
  particles: {
    label: "Particles",
    icon: "Sparkles",
    color: "amber",
    description: "Particle systems and environmental effects",
  },
  microinteractions: {
    label: "Microinteractions",
    icon: "ToggleRight",
    color: "emerald",
    description: "Small interactive component animations",
  },
  visual: {
    label: "Visual Effects",
    icon: "Wand2",
    color: "fuchsia",
    description: "Holographic, metallic, chrome, and advanced visual styles",
  },
  misc: {
    label: "Miscellaneous",
    icon: "Sparkle",
    color: "yellow",
    description: "Unique effects that defy categorization",
  },
};

export const categoryOrder: EffectCategory[] = [
  "animations",
  "hover",
  "text",
  "backgrounds",
  "loaders",
  "3d-transforms",
  "buttons",
  "cards",
  "borders",
  "filters",
  "forms",
  "navigation",
  "scroll",
  "cursor",
  "page-transitions",
  "glass-ui",
  "particles",
  "microinteractions",
  "visual",
  "misc",
];
