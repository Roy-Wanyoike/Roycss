import type { CSSEffect } from "./roycss-types";

/**
 * Batch 24 — Scroll-Driven & Spring Effects (15 effects)
 *
 * Ferrum gap fill: scroll-driven (view-timeline) effects and Apple-style
 * spring physics animations needed additional variants.
 *
 * Scroll-driven (9):
 *   blur-clear, color-shift, rotate-3d, scale-zoom, sticky-shrink,
 *   translate-x, fade-sequence, progress-bar-v2, parallax-layer
 *
 * Apple spring (3):
 *   bounce-settle-v2, elastic-scale-v2, flip-spring-v2
 *
 * Unique (3):
 *   circle-reveal-in, circle-reveal-out, clouds-drift
 *
 * All effects use OKLCH colors, CSS logical properties, `roycss-` class prefix,
 * `roy-b24-` keyframe prefix, and respect `prefers-reduced-motion`.
 *
 * Scroll-driven effects use `animation-timeline: view()` with an
 * `@supports not (animation-timeline: view())` fallback so they still
 * play in browsers without scroll-timeline support.
 */
export const effectsBatch24: CSSEffect[] = [
  /* ════════════════════════════════════════════════════════════════
   * SCROLL-DRIVEN EFFECTS (9)
   * ════════════════════════════════════════════════════════════════ */

  /* 1 — scroll-driven-blur-clear ──────────────────────────────── */
  {
    id: "scroll-driven-blur-clear-b24",
    name: "Scroll Driven Blur Clear",
    category: "scroll",
    description: "Element starts blurred and clears as it scrolls into view",
    tags: ["scroll", "blur", "clear", "timeline", "view"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["keyframes", "filter", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Scroll Driven Blur Clear */
.roycss-scroll-driven-blur-clear-b24 {
  inline-size: 160px;
  block-size: 100px;
  border-radius: 0.75rem;
  background: linear-gradient(135deg,
    oklch(0.55 0.2 250) 0%,
    oklch(0.7 0.18 320) 100%);
  animation: roy-b24-blur-clear linear both;
  animation-timeline: view();
  animation-range: entry 0% cover 50%;
}

@keyframes roy-b24-blur-clear {
  0%   { filter: blur(20px); opacity: 0; }
  100% { filter: blur(0);    opacity: 1; }
}

@supports not (animation-timeline: view()) {
  .roycss-scroll-driven-blur-clear-b24 {
    animation: roy-b24-blur-clear-fallback 2.4s ease-in-out infinite alternate;
  }
  @keyframes roy-b24-blur-clear-fallback {
    0%   { filter: blur(12px); opacity: 0.3; }
    100% { filter: blur(0);    opacity: 1; }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-blur-clear-b24 { animation: none; filter: blur(0); opacity: 1; }
}`,
  },

  /* 2 — scroll-driven-color-shift ─────────────────────────────── */
  {
    id: "scroll-driven-color-shift-b24",
    name: "Scroll Driven Color Shift",
    category: "scroll",
    description: "Element background hue shifts as it crosses the viewport on scroll",
    tags: ["scroll", "color", "shift", "hue", "timeline"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["keyframes", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Scroll Driven Color Shift */
.roycss-scroll-driven-color-shift-b24 {
  inline-size: 160px;
  block-size: 100px;
  border-radius: 0.75rem;
  background: oklch(0.6 0.2 250);
  animation: roy-b24-color-shift linear both;
  animation-timeline: view();
  animation-range: entry 0% exit 100%;
}

@keyframes roy-b24-color-shift {
  0%   { background: oklch(0.6 0.2 250); }
  50%  { background: oklch(0.65 0.22 320); }
  100% { background: oklch(0.7 0.18 35); }
}

@supports not (animation-timeline: view()) {
  .roycss-scroll-driven-color-shift-b24 {
    animation: roy-b24-color-shift-fallback 4s linear infinite alternate;
  }
  @keyframes roy-b24-color-shift-fallback {
    0%   { background: oklch(0.6 0.2 250); }
    100% { background: oklch(0.7 0.18 35); }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-color-shift-b24 { animation: none; background: oklch(0.65 0.2 280); }
}`,
  },

  /* 3 — scroll-driven-rotate-3d ───────────────────────────────── */
  {
    id: "scroll-driven-rotate-3d-b24",
    name: "Scroll Driven Rotate 3D",
    category: "scroll",
    description: "Element rotates on the X-axis (3D) as it scrolls through the viewport",
    tags: ["scroll", "3d", "rotate", "perspective", "timeline"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["rotate", "keyframes", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "3d-transforms"],
    cssCode: `/* Scroll Driven Rotate 3D */
.roycss-scroll-driven-rotate-3d-b24 {
  inline-size: 160px;
  block-size: 100px;
  border-radius: 0.75rem;
  background: linear-gradient(135deg,
    oklch(0.7 0.18 160) 0%,
    oklch(0.55 0.22 200) 100%);
  transform-style: preserve-3d;
  animation: roy-b24-rotate-3d linear both;
  animation-timeline: view();
  animation-range: entry 0% exit 100%;
}

@keyframes roy-b24-rotate-3d {
  0%   { transform: perspective(800px) rotateX(75deg); opacity: 0; }
  50%  { transform: perspective(800px) rotateX(0deg);  opacity: 1; }
  100% { transform: perspective(800px) rotateX(-75deg); opacity: 0; }
}

@supports not (animation-timeline: view()) {
  .roycss-scroll-driven-rotate-3d-b24 {
    animation: roy-b24-rotate-3d-fallback 3.5s ease-in-out infinite alternate;
  }
  @keyframes roy-b24-rotate-3d-fallback {
    0%   { transform: perspective(800px) rotateX(45deg);  opacity: 0.4; }
    100% { transform: perspective(800px) rotateX(-45deg); opacity: 0.4; }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-rotate-3d-b24 { animation: none; transform: none; opacity: 1; }
}`,
  },

  /* 4 — scroll-driven-scale-zoom ──────────────────────────────── */
  {
    id: "scroll-driven-scale-zoom-b24",
    name: "Scroll Driven Scale Zoom",
    category: "scroll",
    description: "Element zooms from small to full size as it enters the viewport",
    tags: ["scroll", "scale", "zoom", "timeline", "view"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Scroll Driven Scale Zoom */
.roycss-scroll-driven-scale-zoom-b24 {
  inline-size: 160px;
  block-size: 100px;
  border-radius: 0.75rem;
  background: linear-gradient(135deg,
    oklch(0.7 0.2 35) 0%,
    oklch(0.55 0.22 350) 100%);
  animation: roy-b24-scale-zoom linear both;
  animation-timeline: view();
  animation-range: entry 0% cover 60%;
}

@keyframes roy-b24-scale-zoom {
  0%   { transform: scale(0.3); opacity: 0; }
  100% { transform: scale(1);   opacity: 1; }
}

@supports not (animation-timeline: view()) {
  .roycss-scroll-driven-scale-zoom-b24 {
    animation: roy-b24-scale-zoom-fallback 2.5s ease-in-out infinite alternate;
  }
  @keyframes roy-b24-scale-zoom-fallback {
    0%   { transform: scale(0.5); opacity: 0.4; }
    100% { transform: scale(1);   opacity: 1; }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-scale-zoom-b24 { animation: none; transform: none; opacity: 1; }
}`,
  },

  /* 5 — scroll-driven-sticky-shrink ───────────────────────────── */
  {
    id: "scroll-driven-sticky-shrink-b24",
    name: "Scroll Driven Sticky Shrink",
    category: "scroll",
    description: "Sticky header that shrinks (block-size + opacity) as page scrolls",
    tags: ["scroll", "sticky", "shrink", "header", "timeline"],
    previewType: "box",
    spacing: "none",
    radius: "sm",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Scroll Driven Sticky Shrink */
.roycss-scroll-driven-sticky-shrink-b24 {
  inline-size: 220px;
  block-size: 60px;
  border-radius: 0.5rem;
  background: linear-gradient(135deg,
    oklch(0.22 0.05 265) 0%,
    oklch(0.3 0.06 280) 100%);
  border: 1px solid oklch(0.32 0.04 265);
  position: sticky;
  inset-block-start: 0;
  animation: roy-b24-sticky-shrink linear both;
  animation-timeline: scroll();
  animation-range: 0 200px;
}

@keyframes roy-b24-sticky-shrink {
  0%   { block-size: 60px; opacity: 1;   border-radius: 0.5rem; }
  100% { block-size: 36px; opacity: 0.85; border-radius: 0.25rem; }
}

@supports not (animation-timeline: scroll()) {
  .roycss-scroll-driven-sticky-shrink-b24 {
    animation: roy-b24-sticky-shrink-fallback 3s ease-in-out infinite alternate;
  }
  @keyframes roy-b24-sticky-shrink-fallback {
    0%   { block-size: 60px; opacity: 1; }
    100% { block-size: 36px; opacity: 0.85; }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-sticky-shrink-b24 { animation: none; }
}`,
  },

  /* 6 — scroll-driven-translate-x ─────────────────────────────── */
  {
    id: "scroll-driven-translate-x-b24",
    name: "Scroll Driven Translate X",
    category: "scroll",
    description: "Element slides in horizontally from the inline-start as it enters view",
    tags: ["scroll", "translate", "horizontal", "slide", "timeline"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Scroll Driven Translate X */
.roycss-scroll-driven-translate-x-b24 {
  inline-size: 160px;
  block-size: 100px;
  border-radius: 0.75rem;
  background: linear-gradient(135deg,
    oklch(0.65 0.22 280) 0%,
    oklch(0.55 0.22 320) 100%);
  animation: roy-b24-translate-x linear both;
  animation-timeline: view();
  animation-range: entry 0% cover 70%;
}

@keyframes roy-b24-translate-x {
  0%   { transform: translateX(-100px); opacity: 0; }
  100% { transform: translateX(0);       opacity: 1; }
}

@supports not (animation-timeline: view()) {
  .roycss-scroll-driven-translate-x-b24 {
    animation: roy-b24-translate-x-fallback 2.5s ease-in-out infinite alternate;
  }
  @keyframes roy-b24-translate-x-fallback {
    0%   { transform: translateX(-60px); opacity: 0.4; }
    100% { transform: translateX(0);     opacity: 1; }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-translate-x-b24 { animation: none; transform: none; opacity: 1; }
}`,
  },

  /* 7 — scroll-driven-fade-sequence ───────────────────────────── */
  {
    id: "scroll-driven-fade-sequence-b24",
    name: "Scroll Driven Fade Sequence",
    category: "scroll",
    description: "Element fades in with a staggered translateY — sequential reveal pattern",
    tags: ["scroll", "fade", "sequence", "stagger", "timeline"],
    previewType: "loader",
    childCount: 3,
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Scroll Driven Fade Sequence */
.roycss-scroll-driven-fade-sequence-b24 {
  inline-size: 200px;
  block-size: 100px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 0.5rem;
  padding-inline: 0.75rem;
}

.roycss-scroll-driven-fade-sequence-b24 > span {
  display: block;
  block-size: 18px;
  border-radius: 0.375rem;
  background: linear-gradient(90deg,
    oklch(0.55 0.2 250) 0%,
    oklch(0.7 0.18 320) 100%);
  animation: roy-b24-fade-seq linear both;
  animation-timeline: view();
  animation-range: entry 0% cover 60%;
}

.roycss-scroll-driven-fade-sequence-b24 > span:nth-child(1) { inline-size: 100%; animation-range: entry 0% cover 30%; }
.roycss-scroll-driven-fade-sequence-b24 > span:nth-child(2) { inline-size: 80%;  animation-range: entry 10% cover 40%; }
.roycss-scroll-driven-fade-sequence-b24 > span:nth-child(3) { inline-size: 60%;  animation-range: entry 20% cover 50%; }

@keyframes roy-b24-fade-seq {
  0%   { transform: translateY(20px); opacity: 0; }
  100% { transform: translateY(0);    opacity: 1; }
}

@supports not (animation-timeline: view()) {
  .roycss-scroll-driven-fade-sequence-b24 > span {
    animation: roy-b24-fade-seq-fallback 2s ease-out infinite alternate;
  }
  .roycss-scroll-driven-fade-sequence-b24 > span:nth-child(2) { animation-delay: 0.2s; }
  .roycss-scroll-driven-fade-sequence-b24 > span:nth-child(3) { animation-delay: 0.4s; }
  @keyframes roy-b24-fade-seq-fallback {
    0%   { transform: translateY(20px); opacity: 0.3; }
    100% { transform: translateY(0);    opacity: 1; }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-fade-sequence-b24 > span { animation: none; opacity: 1; transform: none; }
}`,
  },

  /* 8 — scroll-driven-progress-bar-v2 ─────────────────────────── */
  {
    id: "scroll-driven-progress-bar-v2-b24",
    name: "Scroll Driven Progress Bar v2",
    category: "scroll",
    description: "Top progress bar that fills based on page scroll position (v2)",
    tags: ["scroll", "progress", "bar", "top", "timeline"],
    previewType: "box",
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Scroll Driven Progress Bar v2 */
.roycss-scroll-driven-progress-bar-v2-b24 {
  inline-size: 220px;
  block-size: 6px;
  border-radius: 9999px;
  background: color-mix(in oklch, oklch(0.279 0.037 260.03) 60%, transparent);
  position: relative;
  overflow: hidden;
}

.roycss-scroll-driven-progress-bar-v2-b24::after {
  content: "";
  position: absolute;
  inset-block: 0;
  inset-inline-start: 0;
  inline-size: 100%;
  transform-origin: left center;
  transform: scaleX(0);
  background: linear-gradient(90deg,
    oklch(0.65 0.22 250) 0%,
    oklch(0.7 0.2 320) 50%,
    oklch(0.7 0.18 35) 100%);
  border-radius: inherit;
  animation: roy-b24-progress linear both;
  animation-timeline: scroll(root);
}

@keyframes roy-b24-progress {
  0%   { transform: scaleX(0); }
  100% { transform: scaleX(1); }
}

@supports not (animation-timeline: scroll(root)) {
  .roycss-scroll-driven-progress-bar-v2-b24::after {
    animation: roy-b24-progress-fallback 3s ease-in-out infinite alternate;
  }
  @keyframes roy-b24-progress-fallback {
    0%   { transform: scaleX(0); }
    100% { transform: scaleX(1); }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-progress-bar-v2-b24::after { animation: none; transform: scaleX(0.5); }
}`,
  },

  /* 9 — scroll-driven-parallax-layer ──────────────────────────── */
  {
    id: "scroll-driven-parallax-layer-b24",
    name: "Scroll Driven Parallax Layer",
    category: "scroll",
    description: "Background layer drifts vertically at a slower rate than the foreground",
    tags: ["scroll", "parallax", "layer", "depth", "timeline"],
    previewType: "background",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes", "timeline"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Scroll Driven Parallax Layer */
.roycss-scroll-driven-parallax-layer-b24 {
  inline-size: 220px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    radial-gradient(circle 30px at 30% 30%,
      color-mix(in oklch, oklch(0.85 0.12 230) 60%, transparent) 0%,
      transparent 70%),
    radial-gradient(circle 50px at 70% 60%,
      color-mix(in oklch, oklch(0.7 0.18 320) 50%, transparent) 0%,
      transparent 70%),
    linear-gradient(135deg,
      oklch(0.18 0.05 265) 0%,
      oklch(0.25 0.05 280) 100%);
  position: relative;
  overflow: hidden;
  animation: roy-b24-parallax linear both;
  animation-timeline: view();
  animation-range: cover 0% cover 100%;
}

@keyframes roy-b24-parallax {
  0%   { background-position: 0% 0%, 0% 0%, 0 0; }
  100% { background-position: 0% 40%, 0% -40%, 0 0; }
}

@supports not (animation-timeline: view()) {
  .roycss-scroll-driven-parallax-layer-b24 {
    animation: roy-b24-parallax-fallback 6s ease-in-out infinite alternate;
  }
  @keyframes roy-b24-parallax-fallback {
    0%   { background-position: 0% 0%, 0% 0%, 0 0; }
    100% { background-position: 0% 30%, 0% -30%, 0 0; }
  }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-scroll-driven-parallax-layer-b24 { animation: none; }
}`,
  },

  /* ════════════════════════════════════════════════════════════════
   * APPLE SPRING EFFECTS (3)
   * ════════════════════════════════════════════════════════════════ */

  /* 10 — apple-bounce-settle-v2 ───────────────────────────────── */
  {
    id: "apple-bounce-settle-v2-b24",
    name: "Apple Bounce Settle v2",
    category: "animations",
    description: "Apple-style spring entrance: overshoot then settle with refined easing (v2)",
    tags: ["apple", "spring", "bounce", "settle", "entrance"],
    previewType: "box",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes", "spring"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Apple Bounce Settle v2 */
.roycss-apple-bounce-settle-v2-b24 {
  inline-size: 100px;
  block-size: 100px;
  border-radius: 1.25rem;
  background: linear-gradient(135deg,
    oklch(0.7 0.18 250) 0%,
    oklch(0.55 0.22 280) 100%);
  box-shadow:
    0 8px 20px color-mix(in oklch, oklch(0.55 0.22 280) 40%, transparent),
    inset 0 1px 0 color-mix(in oklch, oklch(0.95 0.02 250) 50%, transparent);
  animation: roy-b24-bounce-settle 1.1s cubic-bezier(0.34, 1.56, 0.64, 1) both;
}

@keyframes roy-b24-bounce-settle {
  0%   { transform: scale(0.6); opacity: 0; }
  60%  { transform: scale(1.08); opacity: 1; }
  80%  { transform: scale(0.97); }
  100% { transform: scale(1); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-apple-bounce-settle-v2-b24 { animation: none; opacity: 1; }
}`,
  },

  /* 11 — apple-elastic-scale-v2 ───────────────────────────────── */
  {
    id: "apple-elastic-scale-v2-b24",
    name: "Apple Elastic Scale v2",
    category: "animations",
    description: "Elastic scale spring — snaps beyond, oscillates, and dampens to rest (v2)",
    tags: ["apple", "elastic", "scale", "spring", "oscillate"],
    previewType: "box",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes", "spring"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Apple Elastic Scale v2 */
.roycss-apple-elastic-scale-v2-b24 {
  inline-size: 100px;
  block-size: 100px;
  border-radius: 1.25rem;
  background: linear-gradient(135deg,
    oklch(0.7 0.2 35) 0%,
    oklch(0.55 0.22 350) 100%);
  box-shadow:
    0 8px 20px color-mix(in oklch, oklch(0.55 0.22 350) 40%, transparent),
    inset 0 1px 0 color-mix(in oklch, oklch(0.95 0.02 35) 50%, transparent);
  animation: roy-b24-elastic-scale 1.3s cubic-bezier(0.68, -0.55, 0.265, 1.55) both;
}

@keyframes roy-b24-elastic-scale {
  0%   { transform: scale(0); }
  40%  { transform: scale(1.2); }
  60%  { transform: scale(0.9); }
  80%  { transform: scale(1.05); }
  100% { transform: scale(1); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-apple-elastic-scale-v2-b24 { animation: none; }
}`,
  },

  /* 12 — apple-flip-spring-v2 ─────────────────────────────────── */
  {
    id: "apple-flip-spring-v2-b24",
    name: "Apple Flip Spring v2",
    category: "3d-transforms",
    description: "3D Y-axis flip with spring overshoot — bounces past 180° then settles (v2)",
    tags: ["apple", "flip", "3d", "spring", "rotate"],
    previewType: "box",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["rotate", "keyframes", "spring"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "3d-transforms"],
    cssCode: `/* Apple Flip Spring v2 */
.roycss-apple-flip-spring-v2-b24 {
  inline-size: 100px;
  block-size: 100px;
  border-radius: 1.25rem;
  background: linear-gradient(135deg,
    oklch(0.55 0.22 160) 0%,
    oklch(0.7 0.18 200) 100%);
  box-shadow:
    0 8px 20px color-mix(in oklch, oklch(0.55 0.22 200) 40%, transparent),
    inset 0 1px 0 color-mix(in oklch, oklch(0.95 0.02 200) 50%, transparent);
  transform-style: preserve-3d;
  animation: roy-b24-flip-spring 1.2s cubic-bezier(0.34, 1.56, 0.64, 1) both;
}

@keyframes roy-b24-flip-spring {
  0%   { transform: perspective(800px) rotateY(0deg); }
  60%  { transform: perspective(800px) rotateY(200deg); }
  80%  { transform: perspective(800px) rotateY(170deg); }
  100% { transform: perspective(800px) rotateY(180deg); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-apple-flip-spring-v2-b24 { animation: none; transform: perspective(800px) rotateY(180deg); }
}`,
  },

  /* ════════════════════════════════════════════════════════════════
   * UNIQUE EFFECTS (3)
   * ════════════════════════════════════════════════════════════════ */

  /* 13 — circle-reveal-in ─────────────────────────────────────── */
  {
    id: "circle-reveal-in-b24",
    name: "Circle Reveal In",
    category: "page-transitions",
    description: "Content revealed by a circle expanding from center — page transition entrance",
    tags: ["circle", "reveal", "in", "transition", "clip-path"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes", "clip-path"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "clip-path"],
    cssCode: `/* Circle Reveal In */
.roycss-circle-reveal-in-b24 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background: linear-gradient(135deg,
    oklch(0.7 0.2 250) 0%,
    oklch(0.55 0.22 320) 100%);
  position: relative;
  overflow: hidden;
  clip-path: circle(0% at 50% 50%);
  animation: roy-b24-circle-in 1.1s cubic-bezier(0.65, 0, 0.35, 1) forwards;
}

@keyframes roy-b24-circle-in {
  0%   { clip-path: circle(0% at 50% 50%); }
  100% { clip-path: circle(75% at 50% 50%); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-circle-reveal-in-b24 { animation: none; clip-path: circle(75% at 50% 50%); }
}`,
  },

  /* 14 — circle-reveal-out ────────────────────────────────────── */
  {
    id: "circle-reveal-out-b24",
    name: "Circle Reveal Out",
    category: "page-transitions",
    description: "Content hidden by a circle contracting to center — page transition exit",
    tags: ["circle", "reveal", "out", "transition", "clip-path"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes", "clip-path"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "clip-path"],
    cssCode: `/* Circle Reveal Out */
.roycss-circle-reveal-out-b24 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background: linear-gradient(135deg,
    oklch(0.7 0.2 250) 0%,
    oklch(0.55 0.22 320) 100%);
  position: relative;
  overflow: hidden;
  clip-path: circle(75% at 50% 50%);
  animation: roy-b24-circle-out 1.1s cubic-bezier(0.65, 0, 0.35, 1) forwards;
}

@keyframes roy-b24-circle-out {
  0%   { clip-path: circle(75% at 50% 50%); }
  100% { clip-path: circle(0% at 50% 50%); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-circle-reveal-out-b24 { animation: none; clip-path: circle(75% at 50% 50%); }
}`,
  },

  /* 15 — clouds-drift ─────────────────────────────────────────── */
  {
    id: "clouds-drift-b24",
    name: "Clouds Drift",
    category: "backgrounds",
    description: "Soft cloud-like blobs drifting horizontally across a sky background",
    tags: ["clouds", "drift", "sky", "background", "ambient"],
    previewType: "background",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Clouds Drift */
.roycss-clouds-drift-b24 {
  inline-size: 220px;
  block-size: 140px;
  border-radius: 1rem;
  background: linear-gradient(to bottom,
    oklch(0.7 0.12 230) 0%,
    oklch(0.82 0.1 220) 60%,
    oklch(0.88 0.06 200) 100%);
  position: relative;
  overflow: hidden;
}

.roycss-clouds-drift-b24::before,
.roycss-clouds-drift-b24::after {
  content: "";
  position: absolute;
  inline-size: 90px;
  block-size: 30px;
  border-radius: 9999px;
  background:
    radial-gradient(circle at 30% 50%,
      oklch(0.98 0.01 250) 0%,
      oklch(0.95 0.02 250) 60%,
      transparent 100%);
  filter: blur(4px);
  opacity: 0.85;
}

.roycss-clouds-drift-b24::before {
  inset-block-start: 30%;
  inset-inline-start: -30%;
  inline-size: 110px;
  block-size: 36px;
  animation: roy-b24-cloud-drift-1 18s linear infinite;
}

.roycss-clouds-drift-b24::after {
  inset-block-start: 55%;
  inset-inline-start: -50%;
  inline-size: 80px;
  block-size: 26px;
  opacity: 0.7;
  animation: roy-b24-cloud-drift-2 24s linear infinite;
}

@keyframes roy-b24-cloud-drift-1 {
  0%   { transform: translateX(0); }
  100% { transform: translateX(360px); }
}

@keyframes roy-b24-cloud-drift-2 {
  0%   { transform: translateX(0); }
  100% { transform: translateX(400px); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-clouds-drift-b24::before,
  .roycss-clouds-drift-b24::after { animation: none; }
}`,
  },
];
