import type { CSSEffect } from "./roycss-types";

/**
 * Batch 23 — Status & Linear.app Effects (25 effects)
 *
 * Ferrum gap fill: status indicators (online/pulse/heartbeat) and refined
 * Linear.app-inspired aesthetics (spotlight, magnetic pull, glow borders,
 * gradient mesh backgrounds) needed more coverage.
 *
 * Status indicators (10):
 *   pulse-green, pulse-red, pulse-yellow, heartbeat, signal-wave,
 *   loading-bar, progress-ring-v2, notification-badge, breathing-blue,
 *   dot-bounce
 *
 * Linear.app style effects (15):
 *   spotlight-v2, magnetic-pull-v2, noise-overlay-v2, depth-shadow-v2,
 *   glow-border-v2, gradient-sweep-v2, card-lift-v2, icon-bounce-v2,
 *   shimmer-hover-v2, text-glow-v2, dark-surface-v2, aurora-glow-v2,
 *   gradient-mesh-bg-v2, dashed-border, glow-input
 *
 * All effects use OKLCH colors, CSS logical properties, `roycss-` class prefix,
 * `roy-b23-` keyframe prefix, and respect `prefers-reduced-motion`.
 */
export const effectsBatch23: CSSEffect[] = [
  /* ════════════════════════════════════════════════════════════════
   * STATUS INDICATORS (10)
   * ════════════════════════════════════════════════════════════════ */

  /* 1 — status-pulse-green ────────────────────────────────────── */
  {
    id: "status-pulse-green-b23",
    name: "Status Pulse Green",
    category: "microinteractions",
    description: "Green online indicator dot with concentric pulse ring — 'available' status",
    tags: ["status", "online", "green", "pulse", "indicator"],
    previewType: "box",
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["pulse", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Status Pulse Green */
.roycss-status-pulse-green-b23 {
  inline-size: 80px;
  block-size: 80px;
  position: relative;
  display: grid;
  place-items: center;
}

.roycss-status-pulse-green-b23::before,
.roycss-status-pulse-green-b23::after {
  content: "";
  position: absolute;
  inset-block-start: 50%;
  inset-inline-start: 50%;
  inline-size: 16px;
  block-size: 16px;
  border-radius: 9999px;
  background: oklch(0.72 0.19 145);
  translate: -50% -50%;
}

.roycss-status-pulse-green-b23::after {
  background: transparent;
  box-shadow: 0 0 0 2px oklch(0.72 0.19 145);
  animation: roy-b23-pulse-green 1.8s ease-out infinite;
}

@keyframes roy-b23-pulse-green {
  0%   { transform: scale(1); opacity: 0.9; }
  100% { transform: scale(3); opacity: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-pulse-green-b23::after { animation: none; opacity: 0.4; }
}`,
  },

  /* 2 — status-pulse-red ──────────────────────────────────────── */
  {
    id: "status-pulse-red-b23",
    name: "Status Pulse Red",
    category: "microinteractions",
    description: "Red error indicator dot with concentric pulse ring — 'busy' or 'error' status",
    tags: ["status", "busy", "red", "pulse", "indicator"],
    previewType: "box",
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["pulse", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Status Pulse Red */
.roycss-status-pulse-red-b23 {
  inline-size: 80px;
  block-size: 80px;
  position: relative;
  display: grid;
  place-items: center;
}

.roycss-status-pulse-red-b23::before,
.roycss-status-pulse-red-b23::after {
  content: "";
  position: absolute;
  inset-block-start: 50%;
  inset-inline-start: 50%;
  inline-size: 16px;
  block-size: 16px;
  border-radius: 9999px;
  background: oklch(0.65 0.22 25);
  translate: -50% -50%;
}

.roycss-status-pulse-red-b23::after {
  background: transparent;
  box-shadow: 0 0 0 2px oklch(0.65 0.22 25);
  animation: roy-b23-pulse-red 1.4s ease-out infinite;
}

@keyframes roy-b23-pulse-red {
  0%   { transform: scale(1); opacity: 0.95; }
  100% { transform: scale(3.2); opacity: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-pulse-red-b23::after { animation: none; opacity: 0.4; }
}`,
  },

  /* 3 — status-pulse-yellow ───────────────────────────────────── */
  {
    id: "status-pulse-yellow-b23",
    name: "Status Pulse Yellow",
    category: "microinteractions",
    description: "Yellow warning indicator dot with concentric pulse ring — 'away' status",
    tags: ["status", "away", "yellow", "warning", "pulse"],
    previewType: "box",
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["pulse", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Status Pulse Yellow */
.roycss-status-pulse-yellow-b23 {
  inline-size: 80px;
  block-size: 80px;
  position: relative;
  display: grid;
  place-items: center;
}

.roycss-status-pulse-yellow-b23::before,
.roycss-status-pulse-yellow-b23::after {
  content: "";
  position: absolute;
  inset-block-start: 50%;
  inset-inline-start: 50%;
  inline-size: 16px;
  block-size: 16px;
  border-radius: 9999px;
  background: oklch(0.82 0.17 85);
  translate: -50% -50%;
}

.roycss-status-pulse-yellow-b23::after {
  background: transparent;
  box-shadow: 0 0 0 2px oklch(0.82 0.17 85);
  animation: roy-b23-pulse-yellow 1.6s ease-out infinite;
}

@keyframes roy-b23-pulse-yellow {
  0%   { transform: scale(1); opacity: 0.9; }
  100% { transform: scale(3); opacity: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-pulse-yellow-b23::after { animation: none; opacity: 0.4; }
}`,
  },

  /* 4 — status-heartbeat ──────────────────────────────────────── */
  {
    id: "status-heartbeat-b23",
    name: "Status Heartbeat",
    category: "microinteractions",
    description: "ECG-style heartbeat line animation — vital signs / live monitoring indicator",
    tags: ["status", "heartbeat", "ecg", "line", "monitor"],
    previewType: "box",
    spacing: "none",
    radius: "sm",
    accessibility: "AA",
    responsive: false,
    animations: ["keyframes", "draw"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "clip-path"],
    cssCode: `/* Status Heartbeat */
.roycss-status-heartbeat-b23 {
  inline-size: 220px;
  block-size: 80px;
  background: oklch(0.208 0.04 265.75);
  border-radius: 0.5rem;
  position: relative;
  overflow: hidden;
}

.roycss-status-heartbeat-b23::before {
  content: "";
  position: absolute;
  inset: 0;
  background:
    linear-gradient(90deg,
      transparent 0%,
      transparent 38%,
      oklch(0.72 0.19 145) 38%,
      oklch(0.72 0.19 145) 40%,
      transparent 40%,
      transparent 45%,
      oklch(0.72 0.19 145) 45%,
      oklch(0.72 0.19 145) 47%,
      oklch(0.72 0.19 145) 48%,
      transparent 48%,
      transparent 53%,
      oklch(0.72 0.19 145) 53%,
      oklch(0.72 0.19 145) 55%,
      transparent 55%);
  background-size: 200% 100%;
  background-repeat: repeat-x;
  background-position: 50% 50%;
  animation: roy-b23-heartbeat 2s linear infinite;
  mask: linear-gradient(transparent 45%, oklch(1) 47%, oklch(1) 53%, transparent 55%);
}

@keyframes roy-b23-heartbeat {
  0%   { background-position: 100% 50%; }
  100% { background-position: -100% 50%; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-heartbeat-b23::before { animation: none; }
}`,
  },

  /* 5 — status-signal-wave ────────────────────────────────────── */
  {
    id: "status-signal-wave-b23",
    name: "Status Signal Wave",
    category: "microinteractions",
    description: "Vertical bars oscillating like a Wi-Fi signal indicator",
    tags: ["status", "signal", "wave", "bars", "wifi"],
    previewType: "loader",
    childCount: 5,
    spacing: "none",
    radius: "sm",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Status Signal Wave */
.roycss-status-signal-wave-b23 {
  inline-size: 200px;
  block-size: 60px;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  gap: 0.375rem;
  padding-block: 0.5rem;
}

.roycss-status-signal-wave-b23 > span {
  inline-size: 8px;
  block-size: 100%;
  background: linear-gradient(to top, oklch(0.6 0.2 250), oklch(0.7 0.18 200));
  border-radius: 4px;
  transform-origin: bottom;
  animation: roy-b23-signal 1.4s ease-in-out infinite;
}

.roycss-status-signal-wave-b23 > span:nth-child(1) { animation-delay: 0s; }
.roycss-status-signal-wave-b23 > span:nth-child(2) { animation-delay: 0.15s; }
.roycss-status-signal-wave-b23 > span:nth-child(3) { animation-delay: 0.3s; }
.roycss-status-signal-wave-b23 > span:nth-child(4) { animation-delay: 0.45s; }
.roycss-status-signal-wave-b23 > span:nth-child(5) { animation-delay: 0.6s; }

@keyframes roy-b23-signal {
  0%, 100% { transform: scaleY(0.3); }
  50%      { transform: scaleY(1); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-signal-wave-b23 > span { animation: none; transform: scaleY(0.7); }
}`,
  },

  /* 6 — status-loading-bar ────────────────────────────────────── */
  {
    id: "status-loading-bar-b23",
    name: "Status Loading Bar",
    category: "loaders",
    description: "Indeterminate loading bar with a moving highlight segment",
    tags: ["status", "loading", "bar", "progress", "indeterminate"],
    previewType: "loader",
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Status Loading Bar */
.roycss-status-loading-bar-b23 {
  inline-size: 220px;
  block-size: 6px;
  border-radius: 9999px;
  background: color-mix(in oklch, oklch(0.279 0.037 260.03) 70%, transparent);
  position: relative;
  overflow: hidden;
}

.roycss-status-loading-bar-b23::after {
  content: "";
  position: absolute;
  inset-block: 0;
  inline-size: 40%;
  background: linear-gradient(90deg,
    transparent,
    oklch(0.7 0.2 250) 50%,
    transparent);
  border-radius: inherit;
  animation: roy-b23-loading-bar 1.6s ease-in-out infinite;
}

@keyframes roy-b23-loading-bar {
  0%   { inset-inline-start: -40%; }
  100% { inset-inline-start: 100%; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-loading-bar-b23::after { animation: none; inset-inline-start: 30%; }
}`,
  },

  /* 7 — status-progress-ring-v2 ───────────────────────────────── */
  {
    id: "status-progress-ring-v2-b23",
    name: "Status Progress Ring v2",
    category: "loaders",
    description: "Circular progress ring with conic-gradient sweep and animated stroke",
    tags: ["status", "progress", "ring", "circle", "conic"],
    previewType: "loader",
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["rotate", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "conic-gradient"],
    cssCode: `/* Status Progress Ring v2 */
.roycss-status-progress-ring-v2-b23 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 9999px;
  background: conic-gradient(
    from 0deg,
    oklch(0.7 0.2 250) 0%,
    oklch(0.6 0.25 320) 40%,
    color-mix(in oklch, oklch(0.279 0.037 260.03) 60%, transparent) 60%,
    color-mix(in oklch, oklch(0.279 0.037 260.03) 60%, transparent) 100%
  );
  position: relative;
  animation: roy-b23-ring-spin 1.4s linear infinite;
}

.roycss-status-progress-ring-v2-b23::after {
  content: "";
  position: absolute;
  inset: 8px;
  border-radius: 9999px;
  background: oklch(0.208 0.04 265.75);
}

@keyframes roy-b23-ring-spin {
  to { transform: rotate(360deg); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-progress-ring-v2-b23 { animation: none; }
}`,
  },

  /* 8 — status-notification-badge ─────────────────────────────── */
  {
    id: "status-notification-badge-b23",
    name: "Status Notification Badge",
    category: "microinteractions",
    description: "Notification badge that pops in with a scale bounce and gentle pulse",
    tags: ["status", "notification", "badge", "pop", "bell"],
    previewType: "box",
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Status Notification Badge */
.roycss-status-notification-badge-b23 {
  inline-size: 80px;
  block-size: 80px;
  position: relative;
  display: grid;
  place-items: center;
  background:
    linear-gradient(135deg,
      oklch(0.3 0.05 265) 0%,
      oklch(0.25 0.05 265) 100%);
  border-radius: 0.75rem;
}

.roycss-status-notification-badge-b23::after {
  content: "3";
  position: absolute;
  inset-block-start: 12px;
  inset-inline-end: 12px;
  inline-size: 22px;
  block-size: 22px;
  display: grid;
  place-items: center;
  border-radius: 9999px;
  background: oklch(0.65 0.22 25);
  color: oklch(0.98 0.01 250);
  font-size: 12px;
  font-weight: 700;
  font-family: system-ui, sans-serif;
  box-shadow: 0 0 0 2px oklch(0.208 0.04 265.75);
  animation: roy-b23-notif-pop 0.6s cubic-bezier(0.34, 1.56, 0.64, 1) both,
             roy-b23-notif-pulse 2s ease-in-out 0.6s infinite;
}

@keyframes roy-b23-notif-pop {
  0%   { transform: scale(0); }
  60%  { transform: scale(1.25); }
  100% { transform: scale(1); }
}

@keyframes roy-b23-notif-pulse {
  0%, 100% { box-shadow: 0 0 0 2px oklch(0.208 0.04 265.75),
                         0 0 0 0 color-mix(in oklch, oklch(0.65 0.22 25) 60%, transparent); }
  50%      { box-shadow: 0 0 0 2px oklch(0.208 0.04 265.75),
                         0 0 0 8px transparent; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-notification-badge-b23::after { animation: none; }
}`,
  },

  /* 9 — status-breathing-blue ─────────────────────────────────── */
  {
    id: "status-breathing-blue-b23",
    name: "Status Breathing Blue",
    category: "microinteractions",
    description: "Soft blue orb that breathes — slow scale and brightness pulse for ambient status",
    tags: ["status", "breathing", "blue", "ambient", "calm"],
    previewType: "box",
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Status Breathing Blue */
.roycss-status-breathing-blue-b23 {
  inline-size: 60px;
  block-size: 60px;
  border-radius: 9999px;
  background: radial-gradient(circle at 35% 35%,
    oklch(0.85 0.12 230) 0%,
    oklch(0.6 0.18 250) 60%,
    oklch(0.45 0.2 260) 100%);
  box-shadow:
    0 0 24px color-mix(in oklch, oklch(0.6 0.18 250) 70%, transparent),
    inset 0 0 12px color-mix(in oklch, oklch(0.85 0.12 230) 60%, transparent);
  animation: roy-b23-breath 3.5s ease-in-out infinite;
}

@keyframes roy-b23-breath {
  0%, 100% { transform: scale(1);    filter: brightness(1); }
  50%      { transform: scale(1.12); filter: brightness(1.25); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-breathing-blue-b23 { animation: none; }
}`,
  },

  /* 10 — status-dot-bounce ────────────────────────────────────── */
  {
    id: "status-dot-bounce-b23",
    name: "Status Dot Bounce",
    category: "microinteractions",
    description: "Three dots bouncing in sequence — typing-indicator pattern for chat status",
    tags: ["status", "dot", "bounce", "typing", "chat"],
    previewType: "loader",
    childCount: 3,
    spacing: "none",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Status Dot Bounce */
.roycss-status-dot-bounce-b23 {
  inline-size: 200px;
  block-size: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}

.roycss-status-dot-bounce-b23 > span {
  inline-size: 12px;
  block-size: 12px;
  border-radius: 9999px;
  background: oklch(0.65 0.2 250);
  animation: roy-b23-dot-bounce 1.2s ease-in-out infinite;
}

.roycss-status-dot-bounce-b23 > span:nth-child(2) { animation-delay: 0.15s; background: oklch(0.7 0.18 200); }
.roycss-status-dot-bounce-b23 > span:nth-child(3) { animation-delay: 0.3s;  background: oklch(0.7 0.18 160); }

@keyframes roy-b23-dot-bounce {
  0%, 80%, 100% { transform: translateY(0); opacity: 0.6; }
  40%           { transform: translateY(-14px); opacity: 1; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-status-dot-bounce-b23 > span { animation: none; opacity: 1; }
}`,
  },

  /* ════════════════════════════════════════════════════════════════
   * LINEAR.APP STYLE EFFECTS (15)
   * ════════════════════════════════════════════════════════════════ */

  /* 11 — linear-spotlight-v2 ──────────────────────────────────── */
  {
    id: "linear-spotlight-v2-b23",
    name: "Linear Spotlight v2",
    category: "microinteractions",
    description: "Radial spotlight that follows cursor via :hover center — v2 with softer falloff",
    tags: ["linear", "spotlight", "cursor", "radial", "hover"],
    previewType: "card",
    spacing: "md",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["hover"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Spotlight v2 */
.roycss-linear-spotlight-v2-b23 {
  inline-size: 220px;
  block-size: 140px;
  border-radius: 1rem;
  background: linear-gradient(135deg,
    oklch(0.18 0.04 265) 0%,
    oklch(0.22 0.05 265) 100%);
  position: relative;
  overflow: hidden;
  transition: border-color 0.3s ease;
  border: 1px solid oklch(0.3 0.05 265);
}

.roycss-linear-spotlight-v2-b23::before {
  content: "";
  position: absolute;
  inset: 0;
  background: radial-gradient(circle 120px at 50% 50%,
    color-mix(in oklch, oklch(0.65 0.2 250) 30%, transparent) 0%,
    transparent 70%);
  opacity: 0;
  transition: opacity 0.35s ease;
  pointer-events: none;
}

.roycss-linear-spotlight-v2-b23:hover::before {
  opacity: 1;
  background: radial-gradient(circle 140px at 70% 30%,
    color-mix(in oklch, oklch(0.7 0.2 250) 35%, transparent) 0%,
    transparent 70%);
}

.roycss-linear-spotlight-v2-b23:hover {
  border-color: color-mix(in oklch, oklch(0.7 0.2 250) 50%, transparent);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-spotlight-v2-b23,
  .roycss-linear-spotlight-v2-b23::before { transition: none; }
}`,
  },

  /* 12 — linear-magnetic-pull-v2 ──────────────────────────────── */
  {
    id: "linear-magnetic-pull-v2-b23",
    name: "Linear Magnetic Pull v2",
    category: "microinteractions",
    description: "Element translates slightly toward cursor on hover — magnetic snap effect (v2)",
    tags: ["linear", "magnetic", "pull", "cursor", "snap"],
    previewType: "box",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "hover"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Magnetic Pull v2 */
.roycss-linear-magnetic-pull-v2-b23 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1rem;
  background: linear-gradient(135deg,
    oklch(0.6 0.2 250) 0%,
    oklch(0.55 0.22 280) 100%);
  box-shadow:
    0 4px 12px color-mix(in oklch, oklch(0.55 0.2 250) 40%, transparent),
    inset 0 1px 0 color-mix(in oklch, oklch(0.85 0.12 230) 40%, transparent);
  transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1),
              box-shadow 0.25s ease;
}

.roycss-linear-magnetic-pull-v2-b23:hover {
  transform: translate(6px, -6px) scale(1.06);
  box-shadow:
    0 12px 30px color-mix(in oklch, oklch(0.55 0.2 250) 50%, transparent),
    inset 0 1px 0 color-mix(in oklch, oklch(0.85 0.12 230) 50%, transparent);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-magnetic-pull-v2-b23 { transition: none; }
  .roycss-linear-magnetic-pull-v2-b23:hover { transform: none; }
}`,
  },

  /* 13 — linear-noise-overlay-v2 ──────────────────────────────── */
  {
    id: "linear-noise-overlay-v2-b23",
    name: "Linear Noise Overlay v2",
    category: "backgrounds",
    description: "Subtle SVG-noise overlay giving surfaces a film-grain texture (v2)",
    tags: ["linear", "noise", "grain", "texture", "overlay"],
    previewType: "background",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Noise Overlay v2 */
.roycss-linear-noise-overlay-v2-b23 {
  inline-size: 220px;
  block-size: 140px;
  border-radius: 1rem;
  background:
    linear-gradient(135deg,
      oklch(0.18 0.05 265) 0%,
      oklch(0.25 0.05 280) 100%);
  position: relative;
  overflow: hidden;
}

.roycss-linear-noise-overlay-v2-b23::after {
  content: "";
  position: absolute;
  inset: 0;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2'/></filter><rect width='80' height='80' filter='url(%23n)' opacity='0.5'/></svg>");
  opacity: 0.18;
  mix-blend-mode: overlay;
  animation: roy-b23-noise-shift 4s steps(8) infinite;
}

@keyframes roy-b23-noise-shift {
  0%   { transform: translate(0, 0); }
  25%  { transform: translate(-4px, 2px); }
  50%  { transform: translate(2px, -3px); }
  75%  { transform: translate(-2px, 4px); }
  100% { transform: translate(0, 0); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-noise-overlay-v2-b23::after { animation: none; }
}`,
  },

  /* 14 — linear-depth-shadow-v2 ───────────────────────────────── */
  {
    id: "linear-depth-shadow-v2-b23",
    name: "Linear Depth Shadow v2",
    category: "cards",
    description: "Layered box-shadows creating crisp elevation depth — v2 with sharper outline",
    tags: ["linear", "depth", "shadow", "elevation", "card"],
    previewType: "card",
    spacing: "md",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["hover"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Depth Shadow v2 */
.roycss-linear-depth-shadow-v2-b23 {
  inline-size: 200px;
  block-size: 120px;
  border-radius: 1rem;
  background: linear-gradient(135deg,
    oklch(0.2 0.05 265) 0%,
    oklch(0.24 0.05 265) 100%);
  border: 1px solid oklch(0.32 0.04 265);
  box-shadow:
    0 1px 2px oklch(0 0 0 / 0.2),
    0 4px 8px oklch(0 0 0 / 0.18),
    0 12px 24px oklch(0 0 0 / 0.15);
  transition: box-shadow 0.3s ease, transform 0.3s ease;
}

.roycss-linear-depth-shadow-v2-b23:hover {
  transform: translateY(-2px);
  box-shadow:
    0 1px 2px oklch(0 0 0 / 0.25),
    0 6px 12px oklch(0 0 0 / 0.22),
    0 18px 36px oklch(0 0 0 / 0.25),
    0 0 0 1px color-mix(in oklch, oklch(0.65 0.2 250) 40%, transparent);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-depth-shadow-v2-b23 { transition: none; }
  .roycss-linear-depth-shadow-v2-b23:hover { transform: none; }
}`,
  },

  /* 15 — linear-glow-border-v2 ────────────────────────────────── */
  {
    id: "linear-glow-border-v2-b23",
    name: "Linear Glow Border v2",
    category: "borders",
    description: "Animated gradient glow border that rotates around the perimeter (v2)",
    tags: ["linear", "glow", "border", "gradient", "animated"],
    previewType: "card",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["rotate", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "conic-gradient"],
    cssCode: `/* Linear Glow Border v2 */
.roycss-linear-glow-border-v2-b23 {
  inline-size: 200px;
  block-size: 120px;
  border-radius: 1rem;
  position: relative;
  background: oklch(0.16 0.04 265);
  isolation: isolate;
}

.roycss-linear-glow-border-v2-b23::before {
  content: "";
  position: absolute;
  inset: -2px;
  border-radius: inherit;
  background: conic-gradient(
    from 0deg,
    oklch(0.65 0.22 250),
    oklch(0.7 0.2 320),
    oklch(0.7 0.2 200),
    oklch(0.65 0.22 250)
  );
  z-index: -1;
  animation: roy-b23-glow-spin 4s linear infinite;
  filter: blur(1px);
}

.roycss-linear-glow-border-v2-b23::after {
  content: "";
  position: absolute;
  inset: 1px;
  border-radius: calc(1rem - 1px);
  background: oklch(0.16 0.04 265);
  z-index: -1;
}

@keyframes roy-b23-glow-spin {
  to { transform: rotate(360deg); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-glow-border-v2-b23::before { animation: none; }
}`,
  },

  /* 16 — linear-gradient-sweep-v2 ─────────────────────────────── */
  {
    id: "linear-gradient-sweep-v2-b23",
    name: "Linear Gradient Sweep v2",
    category: "backgrounds",
    description: "Background gradient that sweeps diagonally in a slow continuous loop (v2)",
    tags: ["linear", "gradient", "sweep", "background", "animated"],
    previewType: "background",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Gradient Sweep v2 */
.roycss-linear-gradient-sweep-v2-b23 {
  inline-size: 220px;
  block-size: 140px;
  border-radius: 1rem;
  background: linear-gradient(120deg,
    oklch(0.3 0.05 265) 0%,
    oklch(0.35 0.08 280) 25%,
    oklch(0.32 0.07 250) 50%,
    oklch(0.3 0.06 290) 75%,
    oklch(0.3 0.05 265) 100%);
  background-size: 300% 100%;
  background-position: 0% 50%;
  animation: roy-b23-grad-sweep 6s linear infinite;
}

@keyframes roy-b23-grad-sweep {
  0%   { background-position: 0% 50%; }
  100% { background-position: 100% 50%; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-gradient-sweep-v2-b23 { animation: none; }
}`,
  },

  /* 17 — linear-card-lift-v2 ──────────────────────────────────── */
  {
    id: "linear-card-lift-v2-b23",
    name: "Linear Card Lift v2",
    category: "cards",
    description: "Card lifts on hover with shadow grow and border highlight (v2)",
    tags: ["linear", "card", "lift", "hover", "shadow"],
    previewType: "card",
    spacing: "md",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "hover"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Card Lift v2 */
.roycss-linear-card-lift-v2-b23 {
  inline-size: 200px;
  block-size: 130px;
  border-radius: 1rem;
  background: linear-gradient(135deg,
    oklch(0.22 0.05 265) 0%,
    oklch(0.27 0.05 265) 100%);
  border: 1px solid oklch(0.32 0.04 265);
  box-shadow: 0 2px 4px oklch(0 0 0 / 0.15);
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1),
              box-shadow 0.3s ease,
              border-color 0.3s ease;
}

.roycss-linear-card-lift-v2-b23:hover {
  transform: translateY(-6px);
  box-shadow: 0 14px 30px oklch(0 0 0 / 0.3);
  border-color: color-mix(in oklch, oklch(0.7 0.2 250) 50%, transparent);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-card-lift-v2-b23 { transition: none; }
  .roycss-linear-card-lift-v2-b23:hover { transform: none; }
}`,
  },

  /* 18 — linear-icon-bounce-v2 ────────────────────────────────── */
  {
    id: "linear-icon-bounce-v2-b23",
    name: "Linear Icon Bounce v2",
    category: "microinteractions",
    description: "Icon-shaped box that bounces in a spring on hover (v2 — smoother easing)",
    tags: ["linear", "icon", "bounce", "spring", "hover"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Icon Bounce v2 */
.roycss-linear-icon-bounce-v2-b23 {
  inline-size: 70px;
  block-size: 70px;
  border-radius: 0.875rem;
  background: linear-gradient(135deg,
    oklch(0.55 0.2 250) 0%,
    oklch(0.6 0.22 280) 100%);
  display: grid;
  place-items: center;
  color: oklch(0.98 0.01 250);
  font-family: system-ui, sans-serif;
  font-weight: 700;
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.roycss-linear-icon-bounce-v2-b23:hover {
  animation: roy-b23-icon-bounce 0.7s cubic-bezier(0.34, 1.56, 0.64, 1);
}

@keyframes roy-b23-icon-bounce {
  0%   { transform: translateY(0); }
  25%  { transform: translateY(-12px); }
  50%  { transform: translateY(0); }
  70%  { transform: translateY(-4px); }
  100% { transform: translateY(0); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-icon-bounce-v2-b23:hover { animation: none; }
}`,
  },

  /* 19 — linear-shimmer-hover-v2 ──────────────────────────────── */
  {
    id: "linear-shimmer-hover-v2-b23",
    name: "Linear Shimmer Hover v2",
    category: "hover",
    description: "Diagonal shimmer sweeps across on hover (v2 — softer gradient)",
    tags: ["linear", "shimmer", "hover", "sweep", "diagonal"],
    previewType: "card",
    spacing: "md",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["hover", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Shimmer Hover v2 */
.roycss-linear-shimmer-hover-v2-b23 {
  inline-size: 200px;
  block-size: 130px;
  border-radius: 1rem;
  background: linear-gradient(135deg,
    oklch(0.2 0.05 265) 0%,
    oklch(0.25 0.05 265) 100%);
  border: 1px solid oklch(0.32 0.04 265);
  position: relative;
  overflow: hidden;
}

.roycss-linear-shimmer-hover-v2-b23::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.85 0.12 230) 30%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  background-position: 200% 0;
  transition: background-position 0.7s ease;
  pointer-events: none;
}

.roycss-linear-shimmer-hover-v2-b23:hover::before {
  background-position: -50% 0;
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-shimmer-hover-v2-b23::before { transition: none; opacity: 0; }
}`,
  },

  /* 20 — linear-text-glow-v2 ──────────────────────────────────── */
  {
    id: "linear-text-glow-v2-b23",
    name: "Linear Text Glow v2",
    category: "text",
    description: "Text with subtle outer glow that intensifies on hover (v2)",
    tags: ["linear", "text", "glow", "hover", "soft"],
    previewType: "text",
    previewText: "Linear",
    spacing: "none",
    radius: "none",
    accessibility: "AA",
    responsive: false,
    animations: ["hover"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Text Glow v2 */
.roycss-linear-text-glow-v2-b23 {
  display: inline-block;
  font-family: system-ui, sans-serif;
  font-size: 2.5rem;
  font-weight: 800;
  letter-spacing: -0.02em;
  color: oklch(0.98 0.02 250);
  text-shadow:
    0 0 8px color-mix(in oklch, oklch(0.65 0.2 250) 40%, transparent),
    0 0 16px color-mix(in oklch, oklch(0.65 0.2 250) 20%, transparent);
  transition: text-shadow 0.4s ease, color 0.4s ease;
}

.roycss-linear-text-glow-v2-b23:hover {
  color: oklch(0.95 0.04 230);
  text-shadow:
    0 0 12px color-mix(in oklch, oklch(0.7 0.2 250) 70%, transparent),
    0 0 28px color-mix(in oklch, oklch(0.65 0.22 280) 50%, transparent),
    0 0 40px color-mix(in oklch, oklch(0.65 0.22 280) 30%, transparent);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-text-glow-v2-b23 { transition: none; }
}`,
  },

  /* 21 — linear-dark-surface-v2 ───────────────────────────────── */
  {
    id: "linear-dark-surface-v2-b23",
    name: "Linear Dark Surface v2",
    category: "backgrounds",
    description: "Layered dark surface with subtle radial highlight and noise (v2)",
    tags: ["linear", "dark", "surface", "background", "layered"],
    previewType: "background",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["none"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Dark Surface v2 */
.roycss-linear-dark-surface-v2-b23 {
  inline-size: 220px;
  block-size: 140px;
  border-radius: 1rem;
  background:
    radial-gradient(circle at 30% 0%,
      color-mix(in oklch, oklch(0.35 0.1 280) 40%, transparent) 0%,
      transparent 60%),
    radial-gradient(circle at 100% 100%,
      color-mix(in oklch, oklch(0.3 0.08 250) 30%, transparent) 0%,
      transparent 50%),
    linear-gradient(135deg,
      oklch(0.16 0.04 265) 0%,
      oklch(0.2 0.05 265) 100%);
  border: 1px solid color-mix(in oklch, oklch(0.4 0.05 265) 50%, transparent);
  position: relative;
  overflow: hidden;
}

.roycss-linear-dark-surface-v2-b23::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(to bottom,
    color-mix(in oklch, oklch(0.95 0.02 250) 8%, transparent) 0%,
    transparent 50%);
  pointer-events: none;
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-dark-surface-v2-b23 { animation: none; }
}`,
  },

  /* 22 — linear-aurora-glow-v2 ────────────────────────────────── */
  {
    id: "linear-aurora-glow-v2-b23",
    name: "Linear Aurora Glow v2",
    category: "backgrounds",
    description: "Multi-color aurora glow blobs drifting slowly — v2 with deeper saturation",
    tags: ["linear", "aurora", "glow", "gradient", "animated"],
    previewType: "background",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Aurora Glow v2 */
.roycss-linear-aurora-glow-v2-b23 {
  inline-size: 220px;
  block-size: 140px;
  border-radius: 1rem;
  background: oklch(0.13 0.04 265);
  position: relative;
  overflow: hidden;
}

.roycss-linear-aurora-glow-v2-b23::before,
.roycss-linear-aurora-glow-v2-b23::after {
  content: "";
  position: absolute;
  inline-size: 140px;
  block-size: 140px;
  border-radius: 9999px;
  filter: blur(30px);
  opacity: 0.55;
}

.roycss-linear-aurora-glow-v2-b23::before {
  inset-block-start: -20px;
  inset-inline-start: -20px;
  background: radial-gradient(circle,
    oklch(0.65 0.25 280) 0%,
    transparent 70%);
  animation: roy-b23-aurora-1 8s ease-in-out infinite;
}

.roycss-linear-aurora-glow-v2-b23::after {
  inset-block-end: -20px;
  inset-inline-end: -20px;
  background: radial-gradient(circle,
    oklch(0.7 0.22 200) 0%,
    transparent 70%);
  animation: roy-b23-aurora-2 10s ease-in-out infinite;
}

@keyframes roy-b23-aurora-1 {
  0%, 100% { transform: translate(0, 0) scale(1); }
  50%      { transform: translate(40px, 30px) scale(1.2); }
}

@keyframes roy-b23-aurora-2 {
  0%, 100% { transform: translate(0, 0) scale(1); }
  50%      { transform: translate(-30px, -20px) scale(1.15); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-aurora-glow-v2-b23::before,
  .roycss-linear-aurora-glow-v2-b23::after { animation: none; }
}`,
  },

  /* 23 — linear-gradient-mesh-bg-v2 ───────────────────────────── */
  {
    id: "linear-gradient-mesh-bg-v2-b23",
    name: "Linear Gradient Mesh BG v2",
    category: "backgrounds",
    description: "Mesh gradient background with multiple color stops blending in a grid (v2)",
    tags: ["linear", "mesh", "gradient", "background", "multi-color"],
    previewType: "background",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Gradient Mesh BG v2 */
.roycss-linear-gradient-mesh-bg-v2-b23 {
  inline-size: 220px;
  block-size: 140px;
  border-radius: 1rem;
  background-color: oklch(0.16 0.04 265);
  background-image:
    radial-gradient(at 20% 20%, oklch(0.5 0.22 280) 0px, transparent 50%),
    radial-gradient(at 80% 0%,  oklch(0.55 0.22 200) 0px, transparent 50%),
    radial-gradient(at 0% 50%,   oklch(0.5 0.2 250) 0px, transparent 50%),
    radial-gradient(at 80% 50%,  oklch(0.6 0.22 320) 0px, transparent 50%),
    radial-gradient(at 0% 100%,  oklch(0.55 0.2 160) 0px, transparent 50%),
    radial-gradient(at 80% 100%, oklch(0.6 0.22 30) 0px, transparent 50%);
  background-size: 200% 200%;
  animation: roy-b23-mesh-shift 12s ease-in-out infinite;
}

@keyframes roy-b23-mesh-shift {
  0%, 100% { background-position: 0% 0%; }
  25%      { background-position: 50% 25%; }
  50%      { background-position: 100% 50%; }
  75%      { background-position: 50% 75%; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-gradient-mesh-bg-v2-b23 { animation: none; }
}`,
  },

  /* 24 — linear-dashed-border ─────────────────────────────────── */
  {
    id: "linear-dashed-border-b23",
    name: "Linear Dashed Border",
    category: "borders",
    description: "Animated dashed border that flows around the perimeter — marching ants style",
    tags: ["linear", "dashed", "border", "animated", "marching-ants"],
    previewType: "card",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Dashed Border */
.roycss-linear-dashed-border-b23 {
  inline-size: 200px;
  block-size: 130px;
  border-radius: 1rem;
  background: oklch(0.18 0.05 265);
  position: relative;
}

.roycss-linear-dashed-border-b23::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  padding: 1.5px;
  background:
    repeating-linear-gradient(90deg,
      oklch(0.65 0.2 250) 0 8px,
      transparent 8px 16px),
    repeating-linear-gradient(0deg,
      oklch(0.65 0.2 250) 0 8px,
      transparent 8px 16px);
  background-size: 100% 1.5px, 1.5px 100%;
  background-position: 0 0, 100% 0;
  background-repeat: no-repeat;
  -webkit-mask:
    linear-gradient(oklch(0) 0 0) content-box,
    linear-gradient(oklch(0) 0 0);
  -webkit-mask-composite: xor;
          mask-composite: exclude;
  animation: roy-b23-dash-flow 1s linear infinite;
}

@keyframes roy-b23-dash-flow {
  to { background-position: 16px 0, 100% 16px; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-dashed-border-b23::before { animation: none; }
}`,
  },

  /* 25 — linear-glow-input ────────────────────────────────────── */
  {
    id: "linear-glow-input-b23",
    name: "Linear Glow Input",
    category: "forms",
    description: "Form input with focus glow ring and animated border highlight",
    tags: ["linear", "input", "form", "glow", "focus"],
    previewType: "box",
    spacing: "sm",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["hover"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Linear Glow Input */
.roycss-linear-glow-input-b23 {
  inline-size: 220px;
  block-size: 44px;
  border-radius: 0.625rem;
  background: oklch(0.16 0.04 265);
  border: 1px solid oklch(0.32 0.04 265);
  padding-inline: 0.875rem;
  display: flex;
  align-items: center;
  color: oklch(0.7 0.03 256);
  font-family: system-ui, sans-serif;
  font-size: 14px;
  transition: border-color 0.25s ease,
              box-shadow 0.25s ease,
              background 0.25s ease;
}

.roycss-linear-glow-input-b23::before {
  content: "Search";
  color: oklch(0.5 0.03 256);
}

.roycss-linear-glow-input-b23:hover {
  border-color: color-mix(in oklch, oklch(0.65 0.2 250) 50%, transparent);
  background: oklch(0.18 0.04 265);
}

.roycss-linear-glow-input-b23:focus-within {
  border-color: oklch(0.7 0.2 250);
  box-shadow:
    0 0 0 4px color-mix(in oklch, oklch(0.65 0.2 250) 25%, transparent),
    0 0 20px color-mix(in oklch, oklch(0.65 0.2 250) 30%, transparent);
  background: oklch(0.2 0.05 265);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-linear-glow-input-b23 { transition: none; }
}`,
  },
];
