import type { CSSEffect } from "./roycss-types";

/**
 * Batch 21 — Ferrum Gap Fill (40 effects)
 *
 * Derived from analyzing ferrum-effects-unified.css (1311 classes, 696 keyframes).
 * These are unique effects that ferrum has but RoyCSS was missing:
 *
 * - Apple material design (frosted vibrancy, ultra-thin, material thick/thin)
 * - 3D objects (book, gallery, poster)
 * - Text effects (fire, scramble, water, emboss, mirror, reflection, blink, stretch)
 * - Backgrounds (lava, lava lamp, plasma, smoke, starfield, checkerboard, circuit, hexagon)
 * - Borders (marching ants, torn paper, ribbon, sticker, polaroid)
 * - Loaders (atom, dna, hourglass, pacman, moon, whale, pencil)
 * - Microinteractions (fab expand, modal scale, tab indicator)
 * - Unique (ascii rain, matrix, blueprint, book open)
 *
 * All effects use OKLCH colors, logical properties, roycss- class prefix,
 * roy-b21- keyframe prefix, and respect prefers-reduced-motion.
 */
export const effectsBatch21: CSSEffect[] = [
  /* ─── APPLE MATERIAL DESIGN (5) ─── */

  {
    id: "apple-frosted-vibrancy-b21",
    name: "Apple Frosted Vibrancy",
    category: "glass-ui",
    description: "Apple-style frosted glass with vibrancy effect — iOS/macOS material design",
    tags: ["apple", "frosted", "vibrancy", "glass", "ios"],
    previewType: "box",
    cssCode: `/* Apple Frosted Vibrancy */
.roycss-apple-frosted-vibrancy-b21 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1.5rem;
  background: color-mix(in oklch, oklch(0.9 0.02 250) 20%, transparent);
  backdrop-filter: blur(30px) saturate(180%) brightness(1.1);
  -webkit-backdrop-filter: blur(30px) saturate(180%) brightness(1.1);
  border: 0.5px solid color-mix(in oklch, white 30%, transparent);
  box-shadow:
    inset 0 0.5px 0 color-mix(in oklch, white 20%, transparent),
    0 4px 16px color-mix(in oklch, oklch(0.1 0.02 250) 20%, transparent);
}`,
  },

  {
    id: "apple-ultra-thin-b21",
    name: "Apple Ultra Thin Material",
    category: "glass-ui",
    description: "Ultra-thin translucent material — Apple's thinnest glass effect",
    tags: ["apple", "ultra-thin", "material", "glass", "translucent"],
    previewType: "box",
    cssCode: `/* Apple Ultra Thin Material */
.roycss-apple-ultra-thin-b21 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1.5rem;
  background: color-mix(in oklch, oklch(0.9 0.02 250) 8%, transparent);
  backdrop-filter: blur(20px) saturate(120%);
  border: 0.5px solid color-mix(in oklch, white 10%, transparent);
}`,
  },

  {
    id: "apple-material-thick-b21",
    name: "Apple Thick Material",
    category: "glass-ui",
    description: "Thick opaque material — macOS sidebar and toolbar style",
    tags: ["apple", "thick", "material", "glass", "macos"],
    previewType: "box",
    cssCode: `/* Apple Thick Material */
.roycss-apple-material-thick-b21 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1rem;
  background: color-mix(in oklch, oklch(0.9 0.02 250) 70%, transparent);
  backdrop-filter: blur(40px) saturate(200%);
  border: 1px solid color-mix(in oklch, white 20%, transparent);
  box-shadow: 0 8px 32px color-mix(in oklch, oklch(0.1 0.02 250) 25%, transparent);
}`,
  },

  {
    id: "apple-sidebar-material-b21",
    name: "Apple Sidebar Material",
    category: "glass-ui",
    description: "macOS sidebar material — vibrancy with translucency for navigation sidebars",
    tags: ["apple", "sidebar", "material", "glass", "macos"],
    previewType: "box",
    cssCode: `/* Apple Sidebar Material */
.roycss-apple-sidebar-material-b21 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 0.75rem;
  background: color-mix(in oklch, oklch(0.85 0.02 250) 40%, transparent);
  backdrop-filter: blur(25px) saturate(150%);
  border: 0.5px solid color-mix(in oklch, white 15%, transparent);
}`,
  },

  {
    id: "apple-vibrancy-dark-b21",
    name: "Apple Dark Vibrancy",
    category: "glass-ui",
    description: "Dark mode vibrancy — Apple's dark material with saturated backdrop",
    tags: ["apple", "vibrancy", "dark", "material", "glass"],
    previewType: "box",
    cssCode: `/* Apple Dark Vibrancy */
.roycss-apple-vibrancy-dark-b21 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1rem;
  background: color-mix(in oklch, oklch(0.15 0.02 250) 50%, transparent);
  backdrop-filter: blur(30px) saturate(180%) brightness(0.9);
  border: 0.5px solid color-mix(in oklch, white 8%, transparent);
}`,
  },

  /* ─── 3D OBJECTS (3) ─── */

  {
    id: "3d-book-b21",
    name: "3D Book",
    category: "3d-transforms",
    description: "A 3D book that opens on hover — interactive cover with perspective depth",
    tags: ["3d", "book", "open", "perspective", "interactive"],
    previewType: "box",
    cssCode: `/* 3D Book */
.roycss-3d-book-b21 {
  inline-size: 60px;
  block-size: 80px;
  transform-style: preserve-3d;
  transform: perspective(600px) rotateY(-25deg);
  transition: transform 0.4s ease;
}

.roycss-3d-book-b21:hover {
  transform: perspective(600px) rotateY(-5deg);
}`,
  },

  {
    id: "3d-poster-b21",
    name: "3D Poster",
    category: "3d-transforms",
    description: "A 3D movie poster with depth layers — parallax poster effect",
    tags: ["3d", "poster", "parallax", "depth", "movie"],
    previewType: "box",
    cssCode: `/* 3D Poster */
.roycss-3d-poster-b21 {
  inline-size: 60px;
  block-size: 80px;
  border-radius: 0.5rem;
  background: linear-gradient(135deg, oklch(0.4 0.15 280), oklch(0.3 0.1 250));
  transform-style: preserve-3d;
  transform: perspective(500px) rotateX(5deg) rotateY(-5deg);
  box-shadow:
    5px 5px 15px color-mix(in oklch, oklch(0.1 0.02 250) 40%, transparent),
    -5px -5px 15px color-mix(in oklch, oklch(0.6 0.2 280) 10%, transparent);
  transition: transform 0.3s ease;
}

.roycss-3d-poster-b21:hover {
  transform: perspective(500px) rotateX(0deg) rotateY(0deg) scale(1.05);
}`,
  },

  {
    id: "3d-gallery-frame-b21",
    name: "3D Gallery Frame",
    category: "3d-transforms",
    description: "A 3D picture frame with shadow depth — gallery exhibition style",
    tags: ["3d", "gallery", "frame", "picture", "exhibition"],
    previewType: "box",
    cssCode: `/* 3D Gallery Frame */
.roycss-3d-gallery-frame-b21 {
  inline-size: 60px;
  block-size: 60px;
  border-radius: 0.25rem;
  background: oklch(0.2 0.02 250);
  border: 4px solid oklch(0.85 0.01 250);
  box-shadow:
    0 1px 2px color-mix(in oklch, oklch(0.1 0.02 250) 20%, transparent),
    0 4px 8px color-mix(in oklch, oklch(0.1 0.02 250) 30%, transparent),
    0 10px 20px color-mix(in oklch, oklch(0.1 0.02 250) 25%, transparent),
    0 20px 40px color-mix(in oklch, oklch(0.1 0.02 250) 20%, transparent);
  transform: perspective(400px) rotateX(2deg);
  transition: transform 0.3s ease;
}

.roycss-3d-gallery-frame-b21:hover {
  transform: perspective(400px) rotateX(0deg) translateY(-4px);
}`,
  },

  /* ─── TEXT EFFECTS (10) ─── */

  {
    id: "text-fire-b21",
    name: "Fire Text",
    category: "text",
    description: "Text with a fire gradient effect — orange/red flame colors",
    tags: ["text", "fire", "flame", "gradient", "hot"],
    previewType: "text",
    cssCode: `/* Fire Text */
.roycss-text-fire-b21 {
  background: linear-gradient(
    0deg,
    oklch(0.6 0.25 25),
    oklch(0.7 0.2 55),
    oklch(0.8 0.15 75),
    oklch(0.85 0.1 90)
  );
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
  text-shadow: 0 -2px 4px color-mix(in oklch, oklch(0.6 0.25 25) 50%, transparent);
}`,
  },

  {
    id: "text-scramble-b21",
    name: "Scramble Text",
    category: "text",
    description: "Text with a scrambling/flickering animation — hacker terminal aesthetic",
    tags: ["text", "scramble", "flicker", "hacker", "terminal"],
    previewType: "text",
    cssCode: `/* Scramble Text */
.roycss-text-scramble-b21 {
  animation: roy-b21-scramble 0.15s steps(1) infinite;
}

@keyframes roy-b21-scramble {
  0% { opacity: 0.8; filter: blur(0.5px); }
  50% { opacity: 1; filter: blur(0); }
  100% { opacity: 0.9; filter: blur(0.3px); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-text-scramble-b21 { animation: none; }
}`,
  },

  {
    id: "text-water-b21",
    name: "Water Text",
    category: "text",
    description: "Text with a watery wave distortion — liquid/fluid text effect",
    tags: ["text", "water", "wave", "liquid", "fluid"],
    previewType: "text",
    cssCode: `/* Water Text */
.roycss-text-water-b21 {
  background: linear-gradient(
    90deg,
    oklch(0.5 0.2 220),
    oklch(0.6 0.15 200),
    oklch(0.5 0.2 220)
  );
  background-size: 200% auto;
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
  animation: roy-b21-water 3s ease-in-out infinite;
}

@keyframes roy-b21-water {
  0%, 100% { background-position: 0% center; }
  50% { background-position: 100% center; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-text-water-b21 { animation: none; }
}`,
  },

  {
    id: "text-emboss-b21",
    name: "Embossed Text",
    category: "text",
    description: "Text with embossed/letterpress effect — raised from the surface",
    tags: ["text", "emboss", "letterpress", "raised", "tactile"],
    previewType: "text",
    cssCode: `/* Embossed Text */
.roycss-text-emboss-b21 {
  color: oklch(0.3 0.02 250);
  text-shadow:
    0 1px 0 color-mix(in oklch, white 60%, transparent),
    0 -1px 0 color-mix(in oklch, oklch(0.1 0.02 250) 40%, transparent);
}`,
  },

  {
    id: "text-mirror-b21",
    name: "Mirror Text",
    category: "text",
    description: "Text with a mirrored reflection below — water reflection effect",
    tags: ["text", "mirror", "reflection", "water", "flip"],
    previewType: "text",
    cssCode: `/* Mirror Text */
.roycss-text-mirror-b21 {
  position: relative;
}

.roycss-text-mirror-b21::after {
  content: attr(data-text);
  position: absolute;
  inset-block-start: 100%;
  inset-inline-start: 0;
  transform: scaleY(-1);
  background: linear-gradient(
    to bottom,
    color-mix(in oklch, oklch(0.6 0.2 162) 40%, transparent),
    transparent
  );
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
  opacity: 0.5;
}`,
  },

  {
    id: "text-blink-b21",
    name: "Blink Text",
    category: "text",
    description: "Text that blinks on and off — attention-grabbing alert effect",
    tags: ["text", "blink", "alert", "attention", "flash"],
    previewType: "text",
    cssCode: `/* Blink Text */
.roycss-text-blink-b21 {
  animation: roy-b21-blink 1s step-end infinite;
}

@keyframes roy-b21-blink {
  0%, 50% { opacity: 1; }
  51%, 100% { opacity: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-text-blink-b21 { animation: none; opacity: 1; }
}`,
  },

  {
    id: "text-stretch-b21",
    name: "Stretch Text",
    category: "text",
    description: "Text that stretches horizontally — elastic/springy text animation",
    tags: ["text", "stretch", "elastic", "spring", "animate"],
    previewType: "text",
    cssCode: `/* Stretch Text */
.roycss-text-stretch-b21 {
  display: inline-block;
  animation: roy-b21-stretch 2s ease-in-out infinite;
}

@keyframes roy-b21-stretch {
  0%, 100% { transform: scaleX(1); }
  50% { transform: scaleX(1.3); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-text-stretch-b21 { animation: none; }
}`,
  },

  {
    id: "text-shadow-pop-b21",
    name: "Shadow Pop Text",
    category: "text",
    description: "Text with a pop-out layered shadow — comic book style depth",
    tags: ["text", "shadow", "pop", "comic", "layered"],
    previewType: "text",
    cssCode: `/* Shadow Pop Text */
.roycss-text-shadow-pop-b21 {
  color: oklch(0.95 0.02 250);
  text-shadow:
    2px 2px 0 oklch(0.6 0.2 25),
    4px 4px 0 oklch(0.5 0.2 25),
    6px 6px 0 oklch(0.4 0.15 25),
    8px 8px 10px color-mix(in oklch, oklch(0.1 0.02 250) 50%, transparent);
}`,
  },

  {
    id: "text-highlight-marker-b21",
    name: "Marker Highlight",
    category: "text",
    description: "Text with a marker-style highlight background — hand-drawn highlighter effect",
    tags: ["text", "highlight", "marker", "underline", "hand-drawn"],
    previewType: "text",
    cssCode: `/* Marker Highlight */
.roycss-text-highlight-marker-b21 {
  background: linear-gradient(
    to bottom,
    transparent 40%,
    oklch(0.8 0.15 90) 40%,
    oklch(0.8 0.15 90) 90%,
    transparent 90%
  );
  padding-inline: 0.25rem;
}`,
  },

  {
    id: "text-typing-cursor-b21",
    name: "Typing Cursor",
    category: "text",
    description: "A blinking cursor at the end of text — terminal/typing indicator",
    tags: ["text", "cursor", "typing", "terminal", "blink"],
    previewType: "text",
    cssCode: `/* Typing Cursor */
.roycss-text-typing-cursor-b21::after {
  content: "▋";
  margin-inline-start: 2px;
  animation: roy-b21-typing-cursor 0.8s step-end infinite;
}

@keyframes roy-b21-typing-cursor {
  0%, 50% { opacity: 1; }
  51%, 100% { opacity: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-text-typing-cursor-b21::after { animation: none; }
}`,
  },

  /* ─── BACKGROUNDS (7) ─── */

  {
    id: "bg-lava-lamp-b21",
    name: "Lava Lamp Background",
    category: "backgrounds",
    description: "Animated lava lamp blobs — organic flowing shapes in the background",
    tags: ["background", "lava", "lamp", "blob", "organic"],
    previewType: "background",
    cssCode: `/* Lava Lamp Background */
.roycss-bg-lava-lamp-b21 {
  inline-size: 100%;
  block-size: 100%;
  background: oklch(0.1 0.02 25);
  border-radius: 1rem;
  position: relative;
  overflow: hidden;
}

.roycss-bg-lava-lamp-b21::before,
.roycss-bg-lava-lamp-b21::after {
  content: "";
  position: absolute;
  inline-size: 60%;
  block-size: 60%;
  border-radius: 50%;
  filter: blur(30px);
  opacity: 0.6;
}

.roycss-bg-lava-lamp-b21::before {
  background: oklch(0.6 0.25 25);
  inset-block-start: 10%;
  inset-inline-start: 10%;
  animation: roy-b21-lava-1 6s ease-in-out infinite;
}

.roycss-bg-lava-lamp-b21::after {
  background: oklch(0.5 0.2 55);
  inset-block-end: 10%;
  inset-inline-end: 10%;
  animation: roy-b21-lava-2 8s ease-in-out infinite;
}

@keyframes roy-b21-lava-1 {
  0%, 100% { transform: translate(0, 0) scale(1); }
  50% { transform: translate(20px, -20px) scale(1.2); }
}

@keyframes roy-b21-lava-2 {
  0%, 100% { transform: translate(0, 0) scale(1); }
  50% { transform: translate(-20px, 20px) scale(0.8); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-bg-lava-lamp-b21::before,
  .roycss-bg-lava-lamp-b21::after { animation: none; }
}`,
  },

  {
    id: "bg-plasma-b21",
    name: "Plasma Background",
    category: "backgrounds",
    description: "Animated plasma field — shifting organic color blobs",
    tags: ["background", "plasma", "organic", "animated", "color"],
    previewType: "background",
    cssCode: `/* Plasma Background */
.roycss-bg-plasma-b21 {
  inline-size: 100%;
  block-size: 100%;
  background:
    radial-gradient(at 20% 30%, oklch(0.6 0.2 280) 0%, transparent 50%),
    radial-gradient(at 80% 70%, oklch(0.5 0.25 330) 0%, transparent 50%),
    radial-gradient(at 50% 50%, oklch(0.55 0.2 200) 0%, transparent 50%),
    oklch(0.1 0.02 250);
  background-size: 200% 200%;
  border-radius: 1rem;
  animation: roy-b21-plasma 10s ease infinite;
}

@keyframes roy-b21-plasma {
  0%, 100% { background-position: 0% 0%, 100% 100%, 50% 50%; }
  33% { background-position: 50% 50%, 0% 100%, 100% 0%; }
  66% { background-position: 100% 0%, 50% 50%, 0% 100%; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-bg-plasma-b21 { animation: none; }
}`,
  },

  {
    id: "bg-smoke-b21",
    name: "Smoke Background",
    category: "backgrounds",
    description: "Drifting smoke effect — atmospheric background with soft moving clouds",
    tags: ["background", "smoke", "atmosphere", "drift", "soft"],
    previewType: "background",
    cssCode: `/* Smoke Background */
.roycss-bg-smoke-b21 {
  inline-size: 100%;
  block-size: 100%;
  background: oklch(0.12 0.02 250);
  border-radius: 1rem;
  position: relative;
  overflow: hidden;
}

.roycss-bg-smoke-b21::before {
  content: "";
  position: absolute;
  inset: -50%;
  background: radial-gradient(
    ellipse at 30% 50%,
    color-mix(in oklch, oklch(0.3 0.02 250) 30%, transparent),
    transparent 60%
  );
  animation: roy-b21-smoke 15s linear infinite;
}

@keyframes roy-b21-smoke {
  from { transform: rotate(0deg) translateX(10px); }
  to { transform: rotate(360deg) translateX(10px); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-bg-smoke-b21::before { animation: none; }
}`,
  },

  {
    id: "bg-starfield-b21",
    name: "Starfield Background",
    category: "backgrounds",
    description: "A starfield with twinkling stars — space/night sky background",
    tags: ["background", "starfield", "stars", "space", "night"],
    previewType: "background",
    cssCode: `/* Starfield Background */
.roycss-bg-starfield-b21 {
  inline-size: 100%;
  block-size: 100%;
  background-color: oklch(0.05 0.01 250);
  background-image:
    radial-gradient(1px 1px at 20% 30%, white, transparent),
    radial-gradient(1px 1px at 40% 70%, white, transparent),
    radial-gradient(1px 1px at 60% 20%, white, transparent),
    radial-gradient(2px 2px at 80% 80%, white, transparent),
    radial-gradient(1px 1px at 10% 90%, white, transparent),
    radial-gradient(1.5px 1.5px at 90% 10%, white, transparent),
    radial-gradient(1px 1px at 50% 50%, white, transparent),
    radial-gradient(1px 1px at 30% 10%, white, transparent);
  background-size: 200px 200px;
  border-radius: 1rem;
  animation: roy-b21-starfield 100s linear infinite;
}

@keyframes roy-b21-starfield {
  from { background-position: 0 0; }
  to { background-position: 200px 200px; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-bg-starfield-b21 { animation: none; }
}`,
  },

  {
    id: "bg-checkerboard-b21",
    name: "Checkerboard Background",
    category: "backgrounds",
    description: "A classic checkerboard pattern — transparency grid and game board aesthetic",
    tags: ["background", "checkerboard", "pattern", "grid", "transparency"],
    previewType: "background",
    cssCode: `/* Checkerboard Background */
.roycss-bg-checkerboard-b21 {
  inline-size: 100%;
  block-size: 100%;
  background-color: oklch(0.9 0.01 250);
  background-image:
    linear-gradient(45deg, oklch(0.7 0.01 250) 25%, transparent 25%),
    linear-gradient(-45deg, oklch(0.7 0.01 250) 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, oklch(0.7 0.01 250) 75%),
    linear-gradient(-45deg, transparent 75%, oklch(0.7 0.01 250) 75%);
  background-size: 20px 20px;
  background-position: 0 0, 0 10px, 10px -10px, -10px 0;
  border-radius: 1rem;
}`,
  },

  {
    id: "bg-hexagon-b21",
    name: "Hexagon Pattern",
    category: "backgrounds",
    description: "A hexagon grid pattern — tech/sci-fi background aesthetic",
    tags: ["background", "hexagon", "pattern", "tech", "grid"],
    previewType: "background",
    cssCode: `/* Hexagon Pattern */
.roycss-bg-hexagon-b21 {
  inline-size: 100%;
  block-size: 100%;
  background-color: oklch(0.1 0.02 250);
  background-image:
    radial-gradient(circle at 50% 0, transparent 12px, oklch(0.3 0.05 250) 13px, oklch(0.3 0.05 250) 14px, transparent 15px),
    radial-gradient(circle at 0 25%, transparent 12px, oklch(0.3 0.05 250) 13px, oklch(0.3 0.05 250) 14px, transparent 15px),
    radial-gradient(circle at 100% 25%, transparent 12px, oklch(0.3 0.05 250) 13px, oklch(0.3 0.05 250) 14px, transparent 15px);
  background-size: 30px 52px;
  border-radius: 1rem;
}`,
  },

  {
    id: "bg-circuit-b21",
    name: "Circuit Board",
    category: "backgrounds",
    description: "A circuit board pattern — tech/engineering background with trace lines",
    tags: ["background", "circuit", "board", "tech", "engineering"],
    previewType: "background",
    cssCode: `/* Circuit Board */
.roycss-bg-circuit-b21 {
  inline-size: 100%;
  block-size: 100%;
  background-color: oklch(0.08 0.03 162);
  background-image:
    linear-gradient(oklch(0.3 0.1 162) 1px, transparent 1px),
    linear-gradient(90deg, oklch(0.3 0.1 162) 1px, transparent 1px),
    radial-gradient(circle at 25% 25%, oklch(0.5 0.15 162) 2px, transparent 3px),
    radial-gradient(circle at 75% 75%, oklch(0.5 0.15 162) 2px, transparent 3px);
  background-size: 40px 40px;
  border-radius: 1rem;
}`,
  },

  /* ─── BORDERS (5) ─── */

  {
    id: "border-marching-ants-b21",
    name: "Marching Ants Border",
    category: "borders",
    description: "Animated dashed border that moves — selection indicator effect",
    tags: ["border", "marching", "ants", "dashed", "selection"],
    previewType: "box",
    cssCode: `/* Marching Ants Border */
.roycss-border-marching-ants-b21 {
  inline-size: 80px;
  block-size: 80px;
  border: 2px dashed oklch(0.6 0.2 162);
  border-radius: 0.5rem;
  animation: roy-b21-marching-ants 0.5s linear infinite;
}

@keyframes roy-b21-marching-ants {
  to { background-position: 20px 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-border-marching-ants-b21 { animation: none; }
}`,
  },

  {
    id: "border-torn-paper-b21",
    name: "Torn Paper Border",
    category: "borders",
    description: "A torn paper edge effect using clip-path — craft/scrapbook aesthetic",
    tags: ["border", "torn", "paper", "clip-path", "craft"],
    previewType: "box",
    cssCode: `/* Torn Paper Border */
.roycss-border-torn-paper-b21 {
  inline-size: 80px;
  block-size: 80px;
  background: oklch(0.85 0.05 90);
  clip-path: polygon(
    0% 5%, 5% 0%, 10% 6%, 15% 1%, 20% 5%, 25% 0%, 30% 4%, 35% 1%, 40% 6%, 45% 0%, 50% 5%, 55% 1%, 60% 4%, 65% 0%, 70% 6%, 75% 1%, 80% 5%, 85% 0%, 90% 4%, 95% 1%, 100% 5%,
    100% 95%, 95% 100%, 90% 94%, 85% 99%, 80% 95%, 75% 100%, 70% 96%, 65% 99%, 60% 94%, 55% 100%, 50% 95%, 45% 99%, 40% 96%, 35% 100%, 30% 94%, 25% 99%, 20% 95%, 15% 100%, 10% 96%, 5% 99%, 0% 95%
  );
}`,
  },

  {
    id: "border-ribbon-b21",
    name: "Ribbon Border",
    category: "borders",
    description: "A decorative ribbon-style border — banner and award aesthetic",
    tags: ["border", "ribbon", "decorative", "banner", "award"],
    previewType: "box",
    cssCode: `/* Ribbon Border */
.roycss-border-ribbon-b21 {
  inline-size: 80px;
  block-size: 80px;
  border: 4px solid oklch(0.6 0.2 25);
  border-radius: 0.25rem;
  box-shadow:
    0 0 0 2px oklch(0.4 0.15 25),
    inset 0 0 0 2px oklch(0.7 0.15 25);
  background: oklch(0.95 0.02 250);
}`,
  },

  {
    id: "border-corner-brackets-b21",
    name: "Corner Brackets",
    category: "borders",
    description: "L-shaped corner brackets — camera viewfinder and tech targeting aesthetic",
    tags: ["border", "corner", "brackets", "viewfinder", "target"],
    previewType: "box",
    cssCode: `/* Corner Brackets */
.roycss-border-corner-brackets-b21 {
  inline-size: 80px;
  block-size: 80px;
  position: relative;
}

.roycss-border-corner-brackets-b21::before,
.roycss-border-corner-brackets-b21::after {
  content: "";
  position: absolute;
  inline-size: 20px;
  block-size: 20px;
  border: 3px solid oklch(0.6 0.2 162);
}

.roycss-border-corner-brackets-b21::before {
  inset-block-start: 0;
  inset-inline-start: 0;
  border-right: none;
  border-block-end: none;
}

.roycss-border-corner-brackets-b21::after {
  inset-block-end: 0;
  inset-inline-end: 0;
  border-left: none;
  border-block-start: none;
}`,
  },

  {
    id: "border-sticker-b21",
    name: "Sticker Border",
    category: "borders",
    description: "A sticker/label style border with offset shadow — playful peel-off effect",
    tags: ["border", "sticker", "label", "playful", "peel"],
    previewType: "box",
    cssCode: `/* Sticker Border */
.roycss-border-sticker-b21 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 0.5rem;
  background: oklch(0.85 0.15 90);
  border: 2px solid oklch(0.3 0.02 250);
  box-shadow: 3px 3px 0 oklch(0.3 0.02 250);
}`,
  },

  /* ─── LOADERS (5) ─── */

  {
    id: "loader-atom-b21",
    name: "Atom Loader",
    category: "loaders",
    description: "Electrons orbiting a nucleus — atom/spinning loader with 3 orbits",
    tags: ["loader", "atom", "orbit", "electron", "science"],
    previewType: "loader",
    childCount: 3,
    cssCode: `/* Atom Loader */
.roycss-loader-atom-b21 {
  position: relative;
  inline-size: 50px;
  block-size: 50px;
}

.roycss-loader-atom-b21::before {
  content: "";
  position: absolute;
  inset-block-start: 50%;
  inset-inline-start: 50%;
  inline-size: 8px;
  block-size: 8px;
  margin: -4px;
  border-radius: 50%;
  background: oklch(0.6 0.2 162);
}

.roycss-loader-atom-b21 > span {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  border: 2px solid transparent;
  border-block-start-color: oklch(0.6 0.2 162);
}

.roycss-loader-atom-b21 > span:nth-child(1) { animation: roy-b21-atom-1 1.5s linear infinite; }
.roycss-loader-atom-b21 > span:nth-child(2) { animation: roy-b21-atom-2 2s linear infinite; border-block-start-color: oklch(0.55 0.25 280); }
.roycss-loader-atom-b21 > span:nth-child(3) { animation: roy-b21-atom-3 2.5s linear infinite; border-block-start-color: oklch(0.7 0.2 30); }

@keyframes roy-b21-atom-1 { to { transform: rotate(360deg); } }
@keyframes roy-b21-atom-2 { to { transform: rotate(-360deg); } }
@keyframes roy-b21-atom-3 { to { transform: rotate(360deg); } }

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-atom-b21 > span { animation: none; }
}`,
  },

  {
    id: "loader-dna-b21",
    name: "DNA Loader",
    category: "loaders",
    description: "A DNA double-helix loader — science/biology themed loading animation",
    tags: ["loader", "dna", "helix", "science", "biology"],
    previewType: "loader",
    childCount: 6,
    cssCode: `/* DNA Loader */
.roycss-loader-dna-b21 {
  display: flex;
  flex-direction: column;
  gap: 2px;
  align-items: center;
}

.roycss-loader-dna-b21 > span {
  inline-size: 20px;
  block-size: 4px;
  border-radius: 2px;
  background: oklch(0.6 0.2 162);
  animation: roy-b21-dna 1s ease-in-out infinite;
}

.roycss-loader-dna-b21 > span:nth-child(odd) { background: oklch(0.55 0.25 280); }
.roycss-loader-dna-b21 > span:nth-child(1) { animation-delay: 0s; }
.roycss-loader-dna-b21 > span:nth-child(2) { animation-delay: 0.1s; }
.roycss-loader-dna-b21 > span:nth-child(3) { animation-delay: 0.2s; }
.roycss-loader-dna-b21 > span:nth-child(4) { animation-delay: 0.3s; }
.roycss-loader-dna-b21 > span:nth-child(5) { animation-delay: 0.4s; }
.roycss-loader-dna-b21 > span:nth-child(6) { animation-delay: 0.5s; }

@keyframes roy-b21-dna {
  0%, 100% { transform: scaleX(1); }
  50% { transform: scaleX(0.3); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-dna-b21 > span { animation: none; }
}`,
  },

  {
    id: "loader-hourglass-b21",
    name: "Hourglass Loader",
    category: "loaders",
    description: "An hourglass shape with sand flowing — time/loading indicator",
    tags: ["loader", "hourglass", "sand", "time", "loading"],
    previewType: "box",
    cssCode: `/* Hourglass Loader */
.roycss-loader-hourglass-b21 {
  inline-size: 30px;
  block-size: 40px;
  position: relative;
  animation: roy-b21-hourglass-rotate 2s ease-in-out infinite;
}

.roycss-loader-hourglass-b21::before {
  content: "";
  position: absolute;
  inset: 0;
  background:
    linear-gradient(to bottom, oklch(0.6 0.2 162) 0%, oklch(0.6 0.2 162) 45%, transparent 45%, transparent 55%, oklch(0.6 0.2 162) 55%, oklch(0.6 0.2 162) 100%);
  clip-path: polygon(0 0, 100% 0, 50% 50%, 100% 100%, 0 100%, 50% 50%);
}

@keyframes roy-b21-hourglass-rotate {
  0%, 50% { transform: rotate(0deg); }
  50.1%, 100% { transform: rotate(180deg); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-hourglass-b21 { animation: none; }
}`,
  },

  {
    id: "loader-pacman-b21",
    name: "Pacman Loader",
    category: "loaders",
    description: "Pacman eating dots — retro arcade game loading animation",
    tags: ["loader", "pacman", "arcade", "retro", "game"],
    previewType: "loader",
    childCount: 3,
    cssCode: `/* Pacman Loader */
.roycss-loader-pacman-b21 {
  display: flex;
  align-items: center;
  gap: 8px;
}

.roycss-loader-pacman-b21::before {
  content: "";
  inline-size: 20px;
  block-size: 20px;
  border-radius: 50%;
  background: oklch(0.8 0.15 90);
  clip-path: polygon(0 0, 100% 0, 100% 40%, 50% 50%, 100% 60%, 100% 100%, 0 100%);
  animation: roy-b21-pacman-mouth 0.3s ease-in-out infinite;
}

.roycss-loader-pacman-b21 > span {
  inline-size: 6px;
  block-size: 6px;
  border-radius: 50%;
  background: oklch(0.6 0.2 162);
  animation: roy-b21-pacman-dot 1.5s linear infinite;
}

.roycss-loader-pacman-b21 > span:nth-child(1) { animation-delay: 0s; }
.roycss-loader-pacman-b21 > span:nth-child(2) { animation-delay: 0.5s; }
.roycss-loader-pacman-b21 > span:nth-child(3) { animation-delay: 1s; }

@keyframes roy-b21-pacman-mouth {
  0%, 100% { clip-path: polygon(0 0, 100% 0, 100% 40%, 50% 50%, 100% 60%, 100% 100%, 0 100%); }
  50% { clip-path: polygon(0 0, 100% 0, 100% 45%, 50% 50%, 100% 55%, 100% 100%, 0 100%); }
}

@keyframes roy-b21-pacman-dot {
  0% { opacity: 1; }
  100% { opacity: 0; transform: translateX(-10px); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-pacman-b21::before,
  .roycss-loader-pacman-b21 > span { animation: none; }
}`,
  },

  {
    id: "loader-whale-b21",
    name: "Whale Loader",
    category: "loaders",
    description: "A whale spouting water — playful nature-themed loader",
    tags: ["loader", "whale", "playful", "nature", "animal"],
    previewType: "box",
    cssCode: `/* Whale Loader */
.roycss-loader-whale-b21 {
  inline-size: 40px;
  block-size: 30px;
  position: relative;
  animation: roy-b21-whale-float 2s ease-in-out infinite;
}

.roycss-loader-whale-b21::before {
  content: "";
  position: absolute;
  inset-block-start: 0;
  inset-inline-start: 0;
  inline-size: 30px;
  block-size: 20px;
  border-radius: 50% 50% 30% 50%;
  background: oklch(0.5 0.1 220);
}

.roycss-loader-whale-b21::after {
  content: "";
  position: absolute;
  inset-block-start: -10px;
  inset-inline-start: 15px;
  inline-size: 4px;
  block-size: 12px;
  border-radius: 2px;
  background: oklch(0.6 0.15 200);
  animation: roy-b21-whale-spout 1s ease-in-out infinite;
}

@keyframes roy-b21-whale-float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}

@keyframes roy-b21-whale-spout {
  0% { block-size: 0; opacity: 1; }
  100% { block-size: 15px; opacity: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-whale-b21 { animation: none; }
  .roycss-loader-whale-b21::after { animation: none; }
}`,
  },

  /* ─── ANIMATIONS / UNIQUE (5) ─── */

  {
    id: "anim-ascii-rain-b21",
    name: "ASCII Rain",
    category: "visual",
    description: "Matrix-style falling characters — digital rain effect",
    tags: ["matrix", "rain", "ascii", "digital", "code"],
    previewType: "background",
    cssCode: `/* ASCII Rain */
.roycss-anim-ascii-rain-b21 {
  inline-size: 100%;
  block-size: 100%;
  background: oklch(0.05 0.02 162);
  position: relative;
  overflow: hidden;
  border-radius: 1rem;
}

.roycss-anim-ascii-rain-b21::before {
  content: "0 1 0 1 1 0 1 0 0 1 1 0 1 0 1 1 0 0 1 0";
  position: absolute;
  inset-block-start: 0;
  inset-inline-start: 0;
  inline-size: 100%;
  color: oklch(0.6 0.2 162);
  font-family: monospace;
  font-size: 10px;
  line-height: 1.5;
  word-break: break-all;
  animation: roy-b21-ascii-rain 3s linear infinite;
  opacity: 0.6;
}

@keyframes roy-b21-ascii-rain {
  from { transform: translateY(-100%); }
  to { transform: translateY(100%); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-ascii-rain-b21::before { animation: none; }
}`,
  },

  {
    id: "anim-book-open-b21",
    name: "Book Open",
    category: "animations",
    description: "A book that opens on hover — interactive reveal animation",
    tags: ["book", "open", "reveal", "interactive", "3d"],
    previewType: "box",
    cssCode: `/* Book Open */
.roycss-anim-book-open-b21 {
  inline-size: 60px;
  block-size: 40px;
  transform-style: preserve-3d;
  transform: perspective(400px) rotateX(10deg);
  transition: transform 0.5s ease;
}

.roycss-anim-book-open-b21:hover {
  transform: perspective(400px) rotateX(0deg) rotateY(-15deg);
}`,
  },

  {
    id: "anim-blueprint-b21",
    name: "Blueprint Grid",
    category: "visual",
    description: "An architectural blueprint grid with measurement marks — technical drawing aesthetic",
    tags: ["blueprint", "grid", "technical", "architectural", "drawing"],
    previewType: "background",
    cssCode: `/* Blueprint Grid */
.roycss-anim-blueprint-b21 {
  inline-size: 100%;
  block-size: 100%;
  background-color: oklch(0.3 0.1 240);
  background-image:
    linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px),
    linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px);
  background-size: 40px 40px, 40px 40px, 8px 8px, 8px 8px;
  border-radius: 1rem;
}`,
  },

  {
    id: "anim-breathe-b21",
    name: "Breathe",
    category: "animations",
    description: "A gentle breathing scale animation — zen/meditative ambient effect",
    tags: ["breathe", "zen", "meditate", "ambient", "calm"],
    previewType: "box",
    cssCode: `/* Breathe */
.roycss-anim-breathe-b21 {
  inline-size: 60px;
  block-size: 60px;
  border-radius: 50%;
  background: radial-gradient(circle, oklch(0.7 0.15 162), oklch(0.4 0.1 162));
  animation: roy-b21-breathe 4s ease-in-out infinite;
}

@keyframes roy-b21-breathe {
  0%, 100% { transform: scale(0.9); opacity: 0.7; }
  50% { transform: scale(1.1); opacity: 1; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-breathe-b21 { animation: none; }
}`,
  },

  {
    id: "anim-bounce-rotate-b21",
    name: "Bounce & Rotate",
    category: "animations",
    description: "Element bounces while rotating — playful spring entrance animation",
    tags: ["bounce", "rotate", "spring", "playful", "entrance"],
    previewType: "box",
    cssCode: `/* Bounce & Rotate */
.roycss-anim-bounce-rotate-b21 {
  inline-size: 60px;
  block-size: 60px;
  border-radius: 1rem;
  background: linear-gradient(135deg, oklch(0.7 0.2 30), oklch(0.6 0.25 55));
  animation: roy-b21-bounce-rotate 1.5s ease-in-out infinite;
}

@keyframes roy-b21-bounce-rotate {
  0%, 100% { transform: translateY(0) rotate(0deg); }
  25% { transform: translateY(-15px) rotate(90deg); }
  50% { transform: translateY(0) rotate(180deg); }
  75% { transform: translateY(-15px) rotate(270deg); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-bounce-rotate-b21 { animation: none; }
}`,
  },
];
