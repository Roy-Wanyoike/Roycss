import type { CSSEffect } from "./roycss-types";

/**
 * RoyCSS Patterns — UI state patterns that teach WHY, not just HOW.
 *
 * Different from recipes (which are combinations of effects).
 * Patterns explain UI/UX states:
 * - Empty State
 * - Loading State
 * - Error State
 * - Success State
 * - Offline State
 * - Skeleton State
 * - Progressive Disclosure
 * - Wizard / Master Detail
 */

export interface Pattern {
  id: string;
  name: string;
  category: "states" | "layouts" | "feedback";
  description: string;
  /** When to use this pattern */
  whenToUse: string;
  /** HTML code for the pattern */
  html: string;
  /** Effect IDs used in this pattern */
  effectIds: string[];
  /** Tags for searchability */
  tags: string[];
}

export const patterns: Pattern[] = [
  /* ─── STATES ─── */

  {
    id: "pattern-empty-state",
    name: "Empty State",
    category: "states",
    description: "A calming empty state with a breathing orb and clear CTA — guides users to take action",
    whenToUse: "When a list, dashboard, or content area has no items yet. Always include a clear CTA button.",
    effectIds: ["anim-breathing-orb-b18"],
    tags: ["empty", "state", "placeholder", "cta", "calm"],
    html: `<div style="display: flex; flex-direction: column; align-items: center; gap: 1rem; padding: 3rem;">
  <div class="roycss-anim-breathing-orb-b18"></div>
  <h3 style="margin: 0; color: oklch(0.7 0.02 250);">Nothing here yet</h3>
  <p style="margin: 0; font-size: 0.875rem; color: oklch(0.5 0.02 250);">Create your first item to get started.</p>
  <button style="padding: 0.5rem 1.5rem; border-radius: 0.5rem; background: oklch(0.6 0.2 162); color: white; border: none; cursor: pointer; font-weight: 600;">
    Create Item
  </button>
</div>`,
  },

  {
    id: "pattern-loading-state",
    name: "Loading State",
    category: "states",
    description: "A loading state with a spinner, progress text, and skeleton content — sets expectations",
    whenToUse: "When fetching data. Show a spinner for short waits, skeleton for long waits. Always communicate progress.",
    effectIds: ["loader-ring-spin", "loader-skeleton-card-b20"],
    tags: ["loading", "state", "spinner", "skeleton", "progress"],
    html: `<div style="display: flex; flex-direction: column; align-items: center; gap: 1rem; padding: 2rem;">
  <div class="roycss-loader-ring-spin"></div>
  <p style="margin: 0; font-size: 0.875rem; color: oklch(0.6 0.02 250);">Loading your dashboard...</p>
  <div class="roycss-loader-skeleton-card-b20" style="position: relative;"></div>
</div>`,
  },

  {
    id: "pattern-error-state",
    name: "Error State",
    category: "states",
    description: "An error state with a shake animation, clear message, and retry button — actionable feedback",
    whenToUse: "When an action fails. Always explain what went wrong and provide a retry button. Use red/rose for errors.",
    effectIds: ["micro-shake-error"],
    tags: ["error", "state", "shake", "retry", "feedback"],
    html: `<div class="roycss-micro-shake-error" style="display: flex; flex-direction: column; align-items: center; gap: 1rem; padding: 2rem; background: oklch(0.25 0.05 25); border-radius: 1rem; border: 1px solid oklch(0.4 0.1 25);">
  <span style="font-size: 2rem;">⚠️</span>
  <h3 style="margin: 0; color: oklch(0.8 0.15 25);">Something went wrong</h3>
  <p style="margin: 0; font-size: 0.875rem; color: oklch(0.6 0.1 25);">We couldn't load your data. Please try again.</p>
  <button style="padding: 0.5rem 1.5rem; border-radius: 0.5rem; background: oklch(0.6 0.2 25); color: white; border: none; cursor: pointer; font-weight: 600;">
    Retry
  </button>
</div>`,
  },

  {
    id: "pattern-success-state",
    name: "Success State",
    category: "states",
    description: "A success state with confetti burst and confirmation message — celebrates completion",
    whenToUse: "When a user completes a significant action (signup, purchase, submission). Use confetti for delight.",
    effectIds: ["anim-confetti-burst-b20"],
    tags: ["success", "state", "confetti", "celebration", "confirmation"],
    html: `<div style="display: flex; flex-direction: column; align-items: center; gap: 1rem; padding: 2rem;">
  <div class="roycss-anim-confetti-burst-b20">
    <span></span><span></span><span></span><span></span><span></span><span></span>
  </div>
  <span style="font-size: 2rem; color: oklch(0.7 0.2 162);">✓</span>
  <h3 style="margin: 0; color: oklch(0.7 0.2 162);">Success!</h3>
  <p style="margin: 0; font-size: 0.875rem; color: oklch(0.6 0.02 250);">Your changes have been saved.</p>
</div>`,
  },

  {
    id: "pattern-offline-state",
    name: "Offline State",
    category: "states",
    description: "An offline indicator with a pulsing dot and reconnect message — handles connectivity loss gracefully",
    whenToUse: "When the app detects no internet connection. Show a banner, not a full-page block. Auto-dismiss on reconnect.",
    effectIds: ["anim-notification-dot-b20"],
    tags: ["offline", "state", "connectivity", "banner", "reconnect"],
    html: `<div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem 1.5rem; background: oklch(0.3 0.1 75); border-radius: 0.5rem; border: 1px solid oklch(0.5 0.15 75);">
  <div class="roycss-anim-notification-dot-b20" style="inline-size: 12px; block-size: 12px; background: transparent;">
    <span style="inline-size: 8px; block-size: 8px; border-radius: 50%; background: oklch(0.7 0.2 75); display: block;"></span>
  </div>
  <p style="margin: 0; font-size: 0.875rem; color: oklch(0.9 0.1 75);">You're offline. Changes will sync when you reconnect.</p>
</div>`,
  },

  /* ─── FEEDBACK ─── */

  {
    id: "pattern-skeleton-state",
    name: "Skeleton Loading",
    category: "feedback",
    description: "Skeleton placeholder that mimics the content layout — reduces perceived loading time",
    whenToUse: "When loading content that has a known layout (cards, articles, lists). Skeletons feel faster than spinners.",
    effectIds: ["loader-skeleton-card-b20", "loader-skeleton-text-b20"],
    tags: ["skeleton", "loading", "placeholder", "layout", "perceived-performance"],
    html: `<div style="display: flex; flex-direction: column; gap: 1rem; padding: 1rem;">
  <div class="roycss-loader-skeleton-card-b20" style="position: relative;"></div>
  <div class="roycss-loader-skeleton-text-b20"></div>
</div>`,
  },

  {
    id: "pattern-progressive-disclosure",
    name: "Progressive Disclosure",
    category: "feedback",
    description: "Content that reveals more on interaction — accordion expand for long content",
    whenToUse: "When you have a lot of content but don't want to overwhelm. Show summary, expand on click.",
    effectIds: ["micro-accordion-expand-b20"],
    tags: ["progressive", "disclosure", "accordion", "expand", "content"],
    html: `<div style="display: flex; flex-direction: column; gap: 0.5rem; inline-size: 200px;">
  <div class="roycss-micro-accordion-expand-b20" style="background: oklch(0.2 0.02 250); border-radius: 0.5rem; padding: 0.5rem; font-size: 12px; color: oklch(0.8 0.02 250);">
    Click to expand...
  </div>
</div>`,
  },

  {
    id: "pattern-toast-feedback",
    name: "Toast Feedback",
    category: "feedback",
    description: "A slide-in toast for non-blocking feedback — success, error, info notifications",
    whenToUse: "When you need to confirm an action without blocking the user. Auto-dismiss after 3-5 seconds.",
    effectIds: ["micro-toast-slide-b20"],
    tags: ["toast", "feedback", "notification", "slide", "non-blocking"],
    html: `<div class="roycss-micro-toast-slide-b20" style="inline-size: auto; padding: 0.5rem 1rem;">
  ✓ Saved successfully
</div>`,
  },

  /* ─── LAYOUTS ─── */

  {
    id: "pattern-master-detail",
    name: "Master-Detail Layout",
    category: "layouts",
    description: "A split layout with a list (master) and detail panel — email and file manager pattern",
    whenToUse: "When you have a list of items and each has detailed content. Common in email clients, file managers, settings.",
    effectIds: ["hover-lift-glow-b18"],
    tags: ["master", "detail", "split", "layout", "list"],
    html: `<div style="display: flex; gap: 1rem; inline-size: 100%;">
  <div style="inline-size: 40%; display: flex; flex-direction: column; gap: 0.5rem;">
    <div class="roycss-hover-lift-glow-b18" style="inline-size: 100%; block-size: 40px; border-radius: 0.5rem;"></div>
    <div class="roycss-hover-lift-glow-b18" style="inline-size: 100%; block-size: 40px; border-radius: 0.5rem;"></div>
    <div class="roycss-hover-lift-glow-b18" style="inline-size: 100%; block-size: 40px; border-radius: 0.5rem;"></div>
  </div>
  <div style="flex: 1; background: oklch(0.2 0.02 250); border-radius: 0.5rem; min-block-size: 120px; padding: 1rem;">
    <p style="color: oklch(0.6 0.02 250); font-size: 0.875rem;">Detail panel</p>
  </div>
</div>`,
  },

  {
    id: "pattern-wizard-steps",
    name: "Wizard Steps",
    category: "layouts",
    description: "A multi-step wizard with progress indicator — checkout and onboarding pattern",
    whenToUse: "When a process has multiple sequential steps (checkout, onboarding, form wizard). Show progress.",
    effectIds: ["nav-stepper-b20"],
    tags: ["wizard", "steps", "multi-step", "checkout", "onboarding"],
    html: `<div style="display: flex; flex-direction: column; gap: 1rem; padding: 1rem;">
  <div class="roycss-nav-stepper-b20">
    <div class="step"></div>
    <div class="connector"></div>
    <div class="step"></div>
    <div class="connector"></div>
    <div class="step inactive"></div>
    <div class="connector inactive"></div>
    <div class="step inactive"></div>
  </div>
  <p style="margin: 0; font-size: 0.875rem; color: oklch(0.6 0.02 250);">Step 2 of 4: Shipping Information</p>
</div>`,
  },
];

export function searchPatterns(query: string, category?: string) {
  const q = query.toLowerCase().trim();
  let results = patterns;

  if (category) {
    results = results.filter((p) => p.category === category);
  }

  if (q) {
    results = results.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.whenToUse.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q)),
    );
  }

  return results;
}
