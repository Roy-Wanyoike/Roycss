"use client";

import { useState, useMemo, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, ArrowRight } from "lucide-react";
import { effects, categoryMeta } from "@/lib/roycss-effects";
import type { CSSEffect } from "@/lib/roycss-types";

/* ═══════════════════════════════════════════════════════════════
   Search Overlay — ⌘K command palette for quick effect search
   ═══════════════════════════════════════════════════════════════ */

interface SearchOverlayProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectEffect: (effect: CSSEffect) => void;
  onJumpToSection: (id: string) => void;
}

export function SearchOverlay({
  open,
  onOpenChange,
  onSelectEffect,
  onJumpToSection,
}: SearchOverlayProps) {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Focus input when overlay opens
  const [prevOpen, setPrevOpen] = useState(false);
  if (open !== prevOpen) {
    setPrevOpen(open);
    if (open) {
      setQuery("");
      setSelectedIndex(0);
    }
  }

  useEffect(() => {
    if (open) {
      const timer = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(timer);
    }
  }, [open]);

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return effects
      .filter(
        (e) =>
          e.name.toLowerCase().includes(q) ||
          e.description.toLowerCase().includes(q) ||
          e.tags.some((t) => t.toLowerCase().includes(q)) ||
          e.id.includes(q) ||
          e.category.includes(q),
      )
      .slice(0, 8);
  }, [query]);

  // Sections for quick jump
  const sections = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    const allSections = [
      { id: "get-started", label: "Get Started", desc: "Installation guide" },
      { id: "effects", label: "Effects", desc: "Browse all 1000+ effects" },
      { id: "recipes", label: "Recipes", desc: "Curated UI patterns" },
      { id: "platform", label: "Platform", desc: "16+ products ecosystem" },
      { id: "docs", label: "Docs", desc: "Documentation & guides" },
      { id: "faq", label: "FAQ", desc: "Frequently asked questions" },
    ];
    return allSections.filter(
      (s) => s.label.toLowerCase().includes(q) || s.desc.toLowerCase().includes(q),
    );
  }, [query]);

  const totalResults = results.length + sections.length;

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelectedIndex((i) => Math.min(i + 1, totalResults - 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelectedIndex((i) => Math.max(i - 1, 0));
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (selectedIndex < sections.length && sections[selectedIndex]) {
          onJumpToSection(`#${sections[selectedIndex].id}`);
          onOpenChange(false);
        } else if (results[selectedIndex - sections.length]) {
          onSelectEffect(results[selectedIndex - sections.length]);
          onOpenChange(false);
        }
      }
    },
    [selectedIndex, totalResults, sections, results, onJumpToSection, onSelectEffect, onOpenChange],
  );

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] flex items-start justify-center pt-[15vh] px-4"
          onClick={() => onOpenChange(false)}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />

          {/* Search panel */}
          <motion.div
            initial={{ scale: 0.95, y: -10 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.95, y: -10 }}
            transition={{ duration: 0.15 }}
            className="relative w-full max-w-xl rounded-2xl border border-border bg-card shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Search input */}
            <div className="flex items-center gap-3 p-4 border-b border-border/50">
              <Search className="size-5 text-muted-foreground shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSelectedIndex(0);
                }}
                onKeyDown={handleKeyDown}
                placeholder="Search effects, sections... (⌘K)"
                className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
                autoComplete="off"
                spellCheck={false}
              />
              <button
                onClick={() => onOpenChange(false)}
                className="flex items-center justify-center size-7 rounded-md bg-muted text-muted-foreground hover:text-foreground transition-colors cursor-pointer shrink-0"
                aria-label="Close search"
              >
                <X className="size-3.5" />
              </button>
            </div>

            {/* Results */}
            <div ref={resultsRef} className="max-h-[50vh] overflow-y-auto scrollbar-thin">
              {query.trim() === "" ? (
                <div className="p-8 text-center">
                  <p className="text-sm text-muted-foreground">
                    Search for effects by name, tag, or category.
                  </p>
                  <p className="text-xs text-muted-foreground/60 mt-2">
                    Try: "glass", "loader", "neon", "hover glow"
                  </p>
                </div>
              ) : totalResults === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-sm text-muted-foreground">
                    No results for &ldquo;{query}&rdquo;
                  </p>
                </div>
              ) : (
                <div className="p-2">
                  {/* Sections */}
                  {sections.map((section, i) => (
                    <button
                      key={section.id}
                      onClick={() => {
                        onJumpToSection(`#${section.id}`);
                        onOpenChange(false);
                      }}
                      onMouseEnter={() => setSelectedIndex(i)}
                      className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all cursor-pointer text-left ${
                        selectedIndex === i ? "bg-primary/10" : "hover:bg-muted/50"
                      }`}
                    >
                      <div className="flex items-center justify-center size-8 rounded-lg bg-muted text-muted-foreground shrink-0">
                        <ArrowRight className="size-3.5" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground">{section.label}</p>
                        <p className="text-xs text-muted-foreground">{section.desc}</p>
                      </div>
                    </button>
                  ))}

                  {/* Divider */}
                  {sections.length > 0 && results.length > 0 && (
                    <div className="h-px bg-border/50 my-1" />
                  )}

                  {/* Effects */}
                  {results.map((effect, i) => {
                    const index = i + sections.length;
                    return (
                      <button
                        key={effect.id}
                        onClick={() => {
                          onSelectEffect(effect);
                          onOpenChange(false);
                        }}
                        onMouseEnter={() => setSelectedIndex(index)}
                        className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all cursor-pointer text-left ${
                          selectedIndex === index ? "bg-primary/10" : "hover:bg-muted/50"
                        }`}
                      >
                        <div className="flex items-center justify-center size-8 rounded-lg bg-primary/10 text-primary shrink-0">
                          <div className={`roycss-${effect.id} scale-50 origin-center`} style={{ width: 16, height: 16 }} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-foreground truncate">{effect.name}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {categoryMeta[effect.category].label} · {effect.tags.slice(0, 2).join(", ")}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-4 py-2 border-t border-border/50 bg-muted/30">
              <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <kbd className="px-1 py-0.5 rounded bg-muted border border-border/50">↑↓</kbd>
                  Navigate
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1 py-0.5 rounded bg-muted border border-border/50">↵</kbd>
                  Select
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1 py-0.5 rounded bg-muted border border-border/50">Esc</kbd>
                  Close
                </span>
              </div>
              <span className="text-[10px] text-muted-foreground">
                {totalResults > 0 && `${totalResults} results`}
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
