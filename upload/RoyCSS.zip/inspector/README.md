# RoyCSS Inspector

Chrome Extension — inspect any webpage and see the RoyCSS equivalent.

## What It Does

Click "Inspect Element" in the extension popup, then click any element on any webpage. The Inspector shows:

- **Element info**: tag, classes, dimensions
- **Colors**: background, text, border (with swatches)
- **Spacing**: padding, margin
- **Visual**: border radius, box shadow, font size, font weight
- **RoyCSS Equivalent**: maps CSS values to RoyCSS tokens (radius, shadow, spacing)
- **Suggested Effects**: recommends RoyCSS effects that match the element's style

## Installation

### Load as Unpacked Extension (Development)

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `inspector/` directory
5. The RoyCSS Inspector icon appears in your toolbar

### From Chrome Web Store (Coming Soon)

Search for "RoyCSS Inspector" in the Chrome Web Store.

## Usage

1. Click the RoyCSS Inspector icon in your toolbar
2. Click **"Inspect Element"**
3. Click any element on the page
4. View the CSS properties and RoyCSS equivalents in the popup

## How It Works

```
┌─────────────┐     Chrome API     ┌─────────────┐
│  Popup      │ ←────────────────→ │  Content    │
│  (results)  │                    │  Script     │
└─────────────┘                    └──────┬──────┘
                                          │
                                   ┌──────┴──────┐
                                   │ Page Element │
                                   │ (computed    │
                                   │  styles)     │
                                   └─────────────┘
```

1. Popup sends "inspect" command via `chrome.scripting.executeScript`
2. Content script creates a crosshair overlay on the page
3. User clicks an element — content script reads `getComputedStyle()`
4. Results are sent back to the popup via `chrome.runtime.sendMessage`
5. Popup displays the CSS properties + RoyCSS equivalents

## RoyCSS Mapping

| CSS Property | RoyCSS Token |
|---|---|
| `border-radius: 0` | `radius: none` |
| `border-radius: 4px` | `radius: sm` |
| `border-radius: 8px` | `radius: md` |
| `border-radius: 16px` | `radius: lg` |
| `border-radius: 50%` | `radius: full` |
| `box-shadow: none` | `shadow: none` |
| `box-shadow: 0 4px...` | `shadow: md` |
| `box-shadow: 0 0 20px...` | `glow effect` |
| `padding: 0` | `spacing: none` |
| `padding: 4px` | `spacing: sm` |
| `padding: 8px` | `spacing: md` |
| `padding: 16px` | `spacing: lg` |

## License

MIT — part of the RoyCSS project.
