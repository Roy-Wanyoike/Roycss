import type { CSSEffect } from "./roycss-types";

/**
 * Batch 25 — Milestone Batch (6 effects)
 * Crosses the 1000+ effects milestone.
 *
 * Unique effects not found in any previous batch or Ferrum:
 * - Gradient mesh text (CSS-only mesh gradient clipped to text)
 * - Glassmorphic toggle (iOS-style frosted toggle)
 * - Neon underline pulse (animated underline that pulses)
 * - Holographic card tilt (iridescent card with 3D tilt)
 * - Wave divider (SVG-free wave divider using clip-path)
 * - Aurora border (animated aurora gradient border)
 *
 * All effects use OKLCH colors, logical properties, roycss- class prefix,
 * roy-b25- keyframe prefix, and respect prefers-reduced-motion.
 */
export const effectsBatch25: CSSEffect[] = [
  {
    id: "text-mesh-gradient-b25",
    name: "Mesh Gradient Text",
    category: "text",
    description: "Text filled with a multi-point mesh gradient — organic flowing color blend inside text",
    tags: ["text", "mesh", "gradient", "organic", "blend"],
    previewType: "text",
    cssCode: `/* Mesh Gradient Text */
.roycss-text-mesh-gradient-b25 {
  background:
    radial-gradient(at 20% 30%, oklch(0.7 0.2 162) 0%, transparent 50%),
    radial-gradient(at 80% 20%, oklch(0.65 0.25 280) 0%, transparent 50%),
    radial-gradient(at 40% 80%, oklch(0.7 0.2 30) 0%, transparent 50%),
    oklch(0.2 0.02 250);
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
}`,
  },

  {
    id: "micro-glass-toggle-b25",
    name: "Glassmorphic Toggle",
    category: "microinteractions",
    description: "An iOS-style frosted glass toggle switch with smooth spring knob animation",
    tags: ["toggle", "glass", "ios", "switch", "frosted"],
    previewType: "box",
    cssCode: `/* Glassmorphic Toggle */
.roycss-micro-glass-toggle-b25 {
  inline-size: 52px;
  block-size: 30px;
  border-radius: 2rem;
  background: color-mix(in oklch, oklch(0.3 0.02 250) 60%, transparent);
  backdrop-filter: blur(12px) saturate(150%);
  border: 1px solid color-mix(in oklch, oklch(0.5 0.05 250) 50%, transparent);
  position: relative;
  cursor: pointer;
  transition: background 0.3s ease;
}

.roycss-micro-glass-toggle-b25::after {
  content: "";
  position: absolute;
  inset-block-start: 3px;
  inset-inline-start: 3px;
  inline-size: 22px;
  block-size: 22px;
  border-radius: 50%;
  background: oklch(0.95 0.01 250);
  box-shadow: 0 2px 6px color-mix(in oklch, oklch(0.1 0.02 250) 40%, transparent);
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.roycss-micro-glass-toggle-b25:hover {
  background: color-mix(in oklch, oklch(0.6 0.2 162) 40%, transparent);
  border-color: oklch(0.6 0.2 162);
}

.roycss-micro-glass-toggle-b25:hover::after {
  transform: translateX(22px);
}`,
  },

  {
    id: "text-neon-underline-pulse-b25",
    name: "Neon Underline Pulse",
    category: "text",
    description: "An animated neon underline that pulses beneath text — cyberpunk link effect",
    tags: ["text", "neon", "underline", "pulse", "cyberpunk"],
    previewType: "text",
    cssCode: `/* Neon Underline Pulse */
.roycss-text-neon-underline-pulse-b25 {
  position: relative;
  display: inline-block;
}

.roycss-text-neon-underline-pulse-b25::after {
  content: "";
  position: absolute;
  inset-block-start: 100%;
  inset-inline-start: 0;
  inline-size: 100%;
  block-size: 2px;
  background: oklch(0.6 0.25 200);
  box-shadow: 0 0 8px oklch(0.6 0.25 200), 0 0 16px oklch(0.6 0.25 200);
  animation: roy-b25-neon-underline 1.5s ease-in-out infinite;
}

@keyframes roy-b25-neon-underline {
  0%, 100% { opacity: 0.6; box-shadow: 0 0 8px oklch(0.6 0.25 200); }
  50% { opacity: 1; box-shadow: 0 0 16px oklch(0.6 0.25 200), 0 0 32px oklch(0.6 0.25 200); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-text-neon-underline-pulse-b25::after { animation: none; }
}`,
  },

  {
    id: "card-holo-tilt-b25",
    name: "Holographic Tilt Card",
    category: "cards",
    description: "An iridescent holographic card that tilts in 3D on hover with shifting rainbow reflections",
    tags: ["card", "holographic", "tilt", "3d", "iridescent"],
    previewType: "card",
    cssCode: `/* Holographic Tilt Card */
.roycss-card-holo-tilt-b25 {
  position: relative;
  inline-size: 144px;
  block-size: 96px;
  border-radius: 1rem;
  overflow: hidden;
  background: oklch(0.15 0.02 250);
  border: 1px solid oklch(0.3 0.05 250);
  transform-style: preserve-3d;
  transition: transform 0.3s ease;
}

.roycss-card-holo-tilt-b25::before {
  content: "";
  position: absolute;
  inset: 0;
  background: conic-gradient(
    from 0deg,
    oklch(0.7 0.15 0),
    oklch(0.65 0.2 60),
    oklch(0.7 0.15 120),
    oklch(0.65 0.2 180),
    oklch(0.7 0.15 240),
    oklch(0.65 0.2 300),
    oklch(0.7 0.15 360)
  );
  opacity: 0.3;
  mix-blend-mode: screen;
  background-size: 200% 200%;
  animation: roy-b25-holo-shift 4s ease infinite;
}

.roycss-card-holo-tilt-b25:hover {
  transform: perspective(500px) rotateX(10deg) rotateY(-10deg) scale(1.05);
}

@keyframes roy-b25-holo-shift {
  0%, 100% { background-position: 0% 0%; }
  50% { background-position: 100% 100%; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-card-holo-tilt-b25::before { animation: none; }
}`,
  },

  {
    id: "bg-wave-divider-b25",
    name: "Wave Divider",
    category: "borders",
    description: "A wave-shaped section divider using clip-path — no SVG needed, pure CSS",
    tags: ["border", "wave", "divider", "clip-path", "section"],
    previewType: "box",
    cssCode: `/* Wave Divider */
.roycss-bg-wave-divider-b25 {
  inline-size: 100%;
  block-size: 40px;
  background: oklch(0.6 0.2 162);
  clip-path: polygon(
    0% 50%,
    12.5% 25%, 25% 50%, 37.5% 75%, 50% 50%,
    62.5% 25%, 75% 50%, 87.5% 75%, 100% 50%,
    100% 100%, 0% 100%
  );
}`,
  },

  {
    id: "border-aurora-animated-b25",
    name: "Aurora Animated Border",
    category: "borders",
    description: "An animated aurora gradient border that shifts colors continuously — eye-catching container",
    tags: ["border", "aurora", "animated", "gradient", "container"],
    previewType: "box",
    cssCode: `/* Aurora Animated Border */
.roycss-border-aurora-animated-b25 {
  position: relative;
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1rem;
  background: oklch(0.15 0.02 250);
  overflow: hidden;
}

.roycss-border-aurora-animated-b25::before {
  content: "";
  position: absolute;
  inset: -50%;
  background: conic-gradient(
    from 0deg,
    oklch(0.6 0.2 162),
    oklch(0.55 0.25 200),
    oklch(0.5 0.2 280),
    oklch(0.6 0.25 330),
    oklch(0.55 0.2 30),
    oklch(0.6 0.2 162)
  );
  animation: roy-b25-aurora-border 4s linear infinite;
  z-index: -1;
}

.roycss-border-aurora-animated-b25::after {
  content: "";
  position: absolute;
  inset: 2px;
  border-radius: calc(1rem - 2px);
  background: oklch(0.15 0.02 250);
  z-index: -1;
}

@keyframes roy-b25-aurora-border {
  to { transform: rotate(360deg); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-border-aurora-animated-b25::before { animation: none; }
}`,
  },
];
