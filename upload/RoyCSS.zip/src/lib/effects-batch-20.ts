import type { CSSEffect } from "./roycss-types";

/**
 * Batch 20 — Missing & Unique Effects (40 effects)
 *
 * Gap analysis findings:
 * - Marquee/scrolling text: 0 references → ADD
 * - Skeleton screen loaders: only 3 → ADD more
 * - Stepper/wizard UI: underrepresented → ADD
 * - Tooltip animations: underrepresented → ADD
 * - Accordion expand/collapse: underrepresented → ADD
 * - Dropdown menu: underrepresented → ADD
 * - Avatar effects: only 12 → ADD
 * - Breadcrumb: only 11 → ADD
 * - Confetti burst: only 25 → ADD unique variants
 * - Progress ring (circular): ADD
 * - Image hover effects (zoom, overlay, reveal): ADD
 * - Sticky header shrink: ADD
 * - Toast slide-in: ADD
 * - Text reveal mask (clip-path): ADD
 * - Parallax tilt (3D card): ADD
 * - Counter animation (number roll-up): ADD
 * - Notification dot: ADD
 * - Search bar expand: ADD
 * - Modal backdrop blur: ADD
 * - Sidebar slide: ADD
 *
 * All effects use OKLCH colors, logical properties, roycss- class prefix,
 * roy-b20- keyframe prefix, and respect prefers-reduced-motion.
 */
export const effectsBatch20: CSSEffect[] = [
  /* ─── ANIMATIONS (8) ─── */

  {
    id: "anim-marquee-text-b20",
    name: "Marquee Text Scroll",
    category: "animations",
    description: "Text that scrolls horizontally in an infinite loop — perfect for news tickers and announcements",
    tags: ["marquee", "scroll", "text", "ticker", "infinite"],
    previewType: "text",
    cssCode: `/* Marquee Text Scroll */
.roycss-anim-marquee-text-b20 {
  display: inline-block;
  white-space: nowrap;
  animation: roy-b20-marquee 10s linear infinite;
  padding-inline-end: 2rem;
}

@keyframes roy-b20-marquee {
  0% { transform: translateX(100%); }
  100% { transform: translateX(-100%); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-marquee-text-b20 { animation: none; }
}`,
  },

  {
    id: "anim-counter-rollup-b20",
    name: "Counter Roll-Up",
    category: "animations",
    description: "A number that rolls up from 0 to target — animated counter for stats and metrics",
    tags: ["counter", "number", "roll", "stats", "animate"],
    previewType: "text",
    previewText: "840",
    cssCode: `/* Counter Roll-Up */
.roycss-anim-counter-rollup-b20 {
  font-variant-numeric: tabular-nums;
  animation: roy-b20-counter-rollup 2s ease-out forwards;
  counter-reset: count 0;
}

.roycss-anim-counter-rollup-b20::after {
  content: counter(count);
  animation: roy-b20-counter-rollup-after 2s ease-out forwards;
}

@keyframes roy-b20-counter-rollup-after {
  0% { content: "0"; }
  10% { content: "84"; }
  20% { content: "168"; }
  30% { content: "252"; }
  40% { content: "336"; }
  50% { content: "420"; }
  60% { content: "504"; }
  70% { content: "588"; }
  80% { content: "672"; }
  90% { content: "756"; }
  100% { content: "840"; }
}

@keyframes roy-b20-counter-rollup {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-counter-rollup-b20 { animation: none; }
}`,
  },

  {
    id: "anim-confetti-burst-b20",
    name: "Confetti Burst",
    category: "animations",
    description: "Confetti particles that burst outward from center — celebration effect for success states",
    tags: ["confetti", "burst", "celebration", "success", "particles"],
    previewType: "box",
    childCount: 6,
    cssCode: `/* Confetti Burst */
.roycss-anim-confetti-burst-b20 {
  position: relative;
  inline-size: 80px;
  block-size: 80px;
}

.roycss-anim-confetti-burst-b20 > span {
  position: absolute;
  inset-block-start: 50%;
  inset-inline-start: 50%;
  inline-size: 6px;
  block-size: 6px;
  border-radius: 1px;
}

.roycss-anim-confetti-burst-b20 > span:nth-child(1) { background: oklch(0.7 0.2 162); animation: roy-b20-confetti-1 1.5s ease-out infinite; }
.roycss-anim-confetti-burst-b20 > span:nth-child(2) { background: oklch(0.65 0.25 280); animation: roy-b20-confetti-2 1.5s ease-out infinite; }
.roycss-anim-confetti-burst-b20 > span:nth-child(3) { background: oklch(0.7 0.2 30); animation: roy-b20-confetti-3 1.5s ease-out infinite; }
.roycss-anim-confetti-burst-b20 > span:nth-child(4) { background: oklch(0.65 0.25 200); animation: roy-b20-confetti-4 1.5s ease-out infinite; }
.roycss-anim-confetti-burst-b20 > span:nth-child(5) { background: oklch(0.7 0.2 330); animation: roy-b20-confetti-5 1.5s ease-out infinite; }
.roycss-anim-confetti-burst-b20 > span:nth-child(6) { background: oklch(0.65 0.25 60); animation: roy-b20-confetti-6 1.5s ease-out infinite; }

@keyframes roy-b20-confetti-1 { 0% { transform: translate(-50%,-50%) rotate(0deg); opacity: 1; } 100% { transform: translate(20px,-30px) rotate(180deg); opacity: 0; } }
@keyframes roy-b20-confetti-2 { 0% { transform: translate(-50%,-50%) rotate(0deg); opacity: 1; } 100% { transform: translate(-25px,-20px) rotate(-180deg); opacity: 0; } }
@keyframes roy-b20-confetti-3 { 0% { transform: translate(-50%,-50%) rotate(0deg); opacity: 1; } 100% { transform: translate(30px,15px) rotate(360deg); opacity: 0; } }
@keyframes roy-b20-confetti-4 { 0% { transform: translate(-50%,-50%) rotate(0deg); opacity: 1; } 100% { transform: translate(-20px,25px) rotate(-360deg); opacity: 0; } }
@keyframes roy-b20-confetti-5 { 0% { transform: translate(-50%,-50%) rotate(0deg); opacity: 1; } 100% { transform: translate(15px,-35px) rotate(180deg); opacity: 0; } }
@keyframes roy-b20-confetti-6 { 0% { transform: translate(-50%,-50%) rotate(0deg); opacity: 1; } 100% { transform: translate(-30px,-10px) rotate(-180deg); opacity: 0; } }

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-confetti-burst-b20 > span { animation: none; }
}`,
  },

  {
    id: "anim-text-reveal-mask-b20",
    name: "Text Reveal Mask",
    category: "animations",
    description: "Text revealed through a moving clip-path mask — cinematic reveal animation",
    tags: ["text", "reveal", "mask", "clip-path", "cinematic"],
    previewType: "text",
    cssCode: `/* Text Reveal Mask */
.roycss-anim-text-reveal-mask-b20 {
  clip-path: inset(0 100% 0 0);
  animation: roy-b20-text-reveal-mask 2s ease-out forwards;
}

@keyframes roy-b20-text-reveal-mask {
  to { clip-path: inset(0 0 0 0); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-text-reveal-mask-b20 { clip-path: none; animation: none; }
}`,
  },

  {
    id: "anim-float-rotate-b20",
    name: "Float & Rotate",
    category: "animations",
    description: "Element floats up while slowly rotating — ambient decorative animation",
    tags: ["float", "rotate", "ambient", "decorative", "3d"],
    previewType: "box",
    cssCode: `/* Float & Rotate */
.roycss-anim-float-rotate-b20 {
  inline-size: 60px;
  block-size: 60px;
  border-radius: 1rem;
  background: linear-gradient(135deg, oklch(0.6 0.2 162), oklch(0.55 0.25 200));
  animation: roy-b20-float-rotate 4s ease-in-out infinite;
}

@keyframes roy-b20-float-rotate {
  0%, 100% { transform: translateY(0) rotate(0deg); }
  50% { transform: translateY(-15px) rotate(180deg); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-float-rotate-b20 { animation: none; }
}`,
  },

  {
    id: "anim-gradient-border-rotate-b20",
    name: "Rotating Gradient Border",
    category: "animations",
    description: "A conic gradient border that rotates around the element — eye-catching container effect",
    tags: ["gradient", "border", "rotate", "conic", "animated"],
    previewType: "box",
    cssCode: `/* Rotating Gradient Border */
.roycss-anim-gradient-border-rotate-b20 {
  position: relative;
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1rem;
  background: oklch(0.15 0.02 250);
  overflow: hidden;
}

.roycss-anim-gradient-border-rotate-b20::before {
  content: "";
  position: absolute;
  inset: -50%;
  background: conic-gradient(
    from 0deg,
    oklch(0.6 0.2 162),
    oklch(0.55 0.25 200),
    oklch(0.5 0.2 280),
    oklch(0.6 0.2 162)
  );
  animation: roy-b20-gradient-border-rotate 4s linear infinite;
  z-index: -1;
}

.roycss-anim-gradient-border-rotate-b20::after {
  content: "";
  position: absolute;
  inset: 2px;
  border-radius: calc(1rem - 2px);
  background: oklch(0.15 0.02 250);
  z-index: -1;
}

@keyframes roy-b20-gradient-border-rotate {
  to { transform: rotate(360deg); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-gradient-border-rotate-b20::before { animation: none; }
}`,
  },

  {
    id: "anim-notification-dot-b20",
    name: "Notification Dot",
    category: "animations",
    description: "A small pulsing dot indicator — perfect for unread notifications and status badges",
    tags: ["notification", "dot", "pulse", "badge", "status"],
    previewType: "box",
    cssCode: `/* Notification Dot */
.roycss-anim-notification-dot-b20 {
  position: relative;
  inline-size: 40px;
  block-size: 40px;
  border-radius: 50%;
  background: oklch(0.25 0.03 250);
  display: flex;
  align-items: center;
  justify-content: center;
}

.roycss-anim-notification-dot-b20::after {
  content: "";
  position: absolute;
  inset-block-start: 6px;
  inset-inline-end: 6px;
  inline-size: 10px;
  block-size: 10px;
  border-radius: 50%;
  background: oklch(0.6 0.25 25);
  box-shadow: 0 0 8px oklch(0.6 0.25 25);
  animation: roy-b20-notification-dot 1.5s ease-in-out infinite;
}

@keyframes roy-b20-notification-dot {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.5; transform: scale(0.8); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-anim-notification-dot-b20::after { animation: none; }
}`,
  },

  {
    id: "anim-sticky-header-shrink-b20",
    name: "Sticky Header Shrink",
    category: "animations",
    description: "A header that shrinks on scroll — modern sticky navigation effect",
    tags: ["sticky", "header", "shrink", "scroll", "navigation"],
    previewType: "box",
    cssCode: `/* Sticky Header Shrink */
.roycss-anim-sticky-header-shrink-b20 {
  position: sticky;
  inset-block-start: 0;
  z-index: 10;
  inline-size: 100%;
  block-size: 60px;
  background: color-mix(in oklch, oklch(0.15 0.02 250) 90%, transparent);
  backdrop-filter: blur(12px);
  border-block-end: 1px solid oklch(0.3 0.05 250);
  transition: block-size 0.3s ease, background 0.3s ease;
}

.roycss-anim-sticky-header-shrink-b20:hover {
  block-size: 44px;
  background: color-mix(in oklch, oklch(0.15 0.02 250) 95%, transparent);
}`,
  },

  /* ─── LOADERS (5) ─── */

  {
    id: "loader-skeleton-card-b20",
    name: "Skeleton Card Loader",
    category: "loaders",
    description: "A card-shaped skeleton with shimmer animation — modern content placeholder",
    tags: ["skeleton", "card", "shimmer", "placeholder", "loading"],
    previewType: "box",
    cssCode: `/* Skeleton Card Loader */
.roycss-loader-skeleton-card-b20 {
  inline-size: 120px;
  block-size: 80px;
  border-radius: 0.75rem;
  overflow: hidden;
  background: oklch(0.2 0.02 250);
}

.roycss-loader-skeleton-card-b20::before {
  content: "";
  position: absolute;
  inset-block-start: 8px;
  inset-inline-start: 8px;
  inline-size: 40%;
  block-size: 10px;
  border-radius: 4px;
  background: oklch(0.3 0.02 250);
  animation: roy-b20-skeleton-shimmer 1.5s ease-in-out infinite;
}

.roycss-loader-skeleton-card-b20::after {
  content: "";
  position: absolute;
  inset-block-start: 28px;
  inset-inline-start: 8px;
  inline-size: 80%;
  block-size: 6px;
  border-radius: 3px;
  background: oklch(0.25 0.02 250);
  animation: roy-b20-skeleton-shimmer 1.5s ease-in-out infinite 0.2s;
  box-shadow: 0 14px 0 oklch(0.25 0.02 250), 0 28px 0 oklch(0.25 0.02 250);
}

@keyframes roy-b20-skeleton-shimmer {
  0% { opacity: 0.3; }
  50% { opacity: 0.6; }
  100% { opacity: 0.3; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-skeleton-card-b20::before,
  .roycss-loader-skeleton-card-b20::after { animation: none; }
}`,
  },

  {
    id: "loader-skeleton-text-b20",
    name: "Skeleton Text Lines",
    category: "loaders",
    description: "Animated skeleton text lines — perfect for article and blog post loading states",
    tags: ["skeleton", "text", "lines", "shimmer", "loading"],
    previewType: "box",
    cssCode: `/* Skeleton Text Lines */
.roycss-loader-skeleton-text-b20 {
  inline-size: 120px;
  block-size: 60px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 0.5rem;
}

.roycss-loader-skeleton-text-b20::before,
.roycss-loader-skeleton-text-b20::after {
  content: "";
  block-size: 8px;
  border-radius: 4px;
  background: linear-gradient(
    90deg,
    oklch(0.2 0.02 250) 0%,
    oklch(0.35 0.02 250) 50%,
    oklch(0.2 0.02 250) 100%
  );
  background-size: 200% 100%;
  animation: roy-b20-skeleton-text 1.5s ease infinite;
}

.roycss-loader-skeleton-text-b20::before {
  inline-size: 100%;
}

.roycss-loader-skeleton-text-b20::after {
  inline-size: 70%;
}

@keyframes roy-b20-skeleton-text {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-skeleton-text-b20::before,
  .roycss-loader-skeleton-text-b20::after { animation: none; }
}`,
  },

  {
    id: "loader-progress-ring-b20",
    name: "Circular Progress Ring",
    category: "loaders",
    description: "A circular progress ring that fills from 0 to 100% — modern loading indicator",
    tags: ["progress", "ring", "circular", "circle", "loading"],
    previewType: "box",
    cssCode: `/* Circular Progress Ring */
.roycss-loader-progress-ring-b20 {
  inline-size: 60px;
  block-size: 60px;
  border-radius: 50%;
  background: conic-gradient(
    oklch(0.6 0.2 162) 0%,
    oklch(0.6 0.2 162) 75%,
    oklch(0.2 0.02 250) 75%,
    oklch(0.2 0.02 250) 100%
  );
  -webkit-mask: radial-gradient(transparent 55%, black 56%);
  mask: radial-gradient(transparent 55%, black 56%);
  animation: roy-b20-progress-ring 2s ease-in-out infinite;
}

@keyframes roy-b20-progress-ring {
  0% { background: conic-gradient(oklch(0.6 0.2 162) 0%, oklch(0.2 0.02 250) 0%); }
  50% { background: conic-gradient(oklch(0.6 0.2 162) 50%, oklch(0.2 0.02 250) 50%); }
  100% { background: conic-gradient(oklch(0.6 0.2 162) 100%, oklch(0.2 0.02 250) 100%); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-progress-ring-b20 { animation: none; }
}`,
  },

  {
    id: "loader-progress-bar-b20",
    name: "Animated Progress Bar",
    category: "loaders",
    description: "A horizontal progress bar with a moving shimmer — file upload / loading indicator",
    tags: ["progress", "bar", "horizontal", "shimmer", "loading"],
    previewType: "box",
    cssCode: `/* Animated Progress Bar */
.roycss-loader-progress-bar-b20 {
  inline-size: 120px;
  block-size: 8px;
  border-radius: 4px;
  background: oklch(0.2 0.02 250);
  overflow: hidden;
  position: relative;
}

.roycss-loader-progress-bar-b20::after {
  content: "";
  position: absolute;
  inset-block-start: 0;
  inset-inline-start: -40%;
  inline-size: 40%;
  block-size: 100%;
  border-radius: 4px;
  background: linear-gradient(
    90deg,
    transparent,
    oklch(0.6 0.2 162),
    transparent
  );
  animation: roy-b20-progress-bar 1.5s ease-in-out infinite;
}

@keyframes roy-b20-progress-bar {
  0% { inset-inline-start: -40%; }
  100% { inset-inline-start: 100%; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-progress-bar-b20::after { animation: none; }
}`,
  },

  {
    id: "loader-pulse-blocks-b20",
    name: "Pulse Blocks",
    category: "loaders",
    description: "Four blocks that pulse in sequence — modern minimal loading indicator",
    tags: ["pulse", "blocks", "sequence", "minimal", "loading"],
    previewType: "loader",
    childCount: 4,
    cssCode: `/* Pulse Blocks */
.roycss-loader-pulse-blocks-b20 {
  display: inline-flex;
  gap: 4px;
  align-items: flex-end;
  block-size: 30px;
}

.roycss-loader-pulse-blocks-b20 > span {
  inline-size: 8px;
  block-size: 100%;
  border-radius: 2px;
  background: oklch(0.6 0.2 162);
  animation: roy-b20-pulse-blocks 1s ease-in-out infinite;
}

.roycss-loader-pulse-blocks-b20 > span:nth-child(1) { animation-delay: 0s; }
.roycss-loader-pulse-blocks-b20 > span:nth-child(2) { animation-delay: 0.15s; }
.roycss-loader-pulse-blocks-b20 > span:nth-child(3) { animation-delay: 0.3s; }
.roycss-loader-pulse-blocks-b20 > span:nth-child(4) { animation-delay: 0.45s; }

@keyframes roy-b20-pulse-blocks {
  0%, 100% { transform: scaleY(0.4); opacity: 0.5; }
  50% { transform: scaleY(1); opacity: 1; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-loader-pulse-blocks-b20 > span { animation: none; }
}`,
  },

  /* ─── MICROINTERACTIONS (6) ─── */

  {
    id: "micro-tooltip-fade-b20",
    name: "Tooltip Fade",
    category: "microinteractions",
    description: "A tooltip that fades in above an element on hover — clean and accessible",
    tags: ["tooltip", "fade", "hover", "info", "micro"],
    previewType: "box",
    cssCode: `/* Tooltip Fade */
.roycss-micro-tooltip-fade-b20 {
  position: relative;
  inline-size: 60px;
  block-size: 60px;
  border-radius: 1rem;
  background: oklch(0.25 0.03 250);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.roycss-micro-tooltip-fade-b20::after {
  content: "Info";
  position: absolute;
  inset-block-end: 100%;
  inset-inline-start: 50%;
  transform: translateX(-50%) translateY(4px);
  margin-block-end: 6px;
  padding: 0.25rem 0.6rem;
  border-radius: 0.375rem;
  background: oklch(0.1 0.02 250);
  color: oklch(0.95 0.02 250);
  font-size: 11px;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: all 0.2s ease;
}

.roycss-micro-tooltip-fade-b20:hover::after {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}`,
  },

  {
    id: "micro-accordion-expand-b20",
    name: "Accordion Expand",
    category: "microinteractions",
    description: "Smooth height expansion for accordion content — FAQ and collapsible sections",
    tags: ["accordion", "expand", "collapse", "faq", "smooth"],
    previewType: "box",
    cssCode: `/* Accordion Expand */
.roycss-micro-accordion-expand-b20 {
  inline-size: 120px;
  border-radius: 0.5rem;
  overflow: hidden;
  transition: block-size 0.3s ease;
  block-size: 30px;
  background: oklch(0.25 0.03 250);
  border: 1px solid oklch(0.35 0.05 250);
}

.roycss-micro-accordion-expand-b20:hover {
  block-size: 80px;
}`,
  },

  {
    id: "micro-dropdown-slide-b20",
    name: "Dropdown Slide",
    category: "microinteractions",
    description: "A dropdown menu that slides down from a trigger — menu and select interactions",
    tags: ["dropdown", "slide", "menu", "select", "micro"],
    previewType: "box",
    cssCode: `/* Dropdown Slide */
.roycss-micro-dropdown-slide-b20 {
  position: relative;
  inline-size: 100px;
  block-size: 36px;
  border-radius: 0.5rem;
  background: oklch(0.25 0.03 250);
  border: 1px solid oklch(0.35 0.05 250);
  overflow: visible;
  cursor: pointer;
}

.roycss-micro-dropdown-slide-b20::after {
  content: "Menu Item 1\\AMenu Item 2\\AMenu Item 3";
  white-space: pre;
  position: absolute;
  inset-block-start: 100%;
  inset-inline-start: 0;
  inline-size: 100%;
  padding: 0.5rem;
  margin-block-start: 4px;
  border-radius: 0.5rem;
  background: oklch(0.2 0.02 250);
  border: 1px solid oklch(0.3 0.05 250);
  font-size: 11px;
  color: oklch(0.8 0.02 250);
  opacity: 0;
  transform: translateY(-10px);
  pointer-events: none;
  transition: all 0.2s ease;
  z-index: 10;
}

.roycss-micro-dropdown-slide-b20:hover::after {
  opacity: 1;
  transform: translateY(0);
}`,
  },

  {
    id: "micro-toast-slide-b20",
    name: "Toast Slide-In",
    category: "microinteractions",
    description: "A toast notification that slides in from the side — success/error feedback",
    tags: ["toast", "slide", "notification", "feedback", "snackbar"],
    previewType: "box",
    cssCode: `/* Toast Slide-In */
.roycss-micro-toast-slide-b20 {
  inline-size: 120px;
  block-size: 36px;
  border-radius: 0.5rem;
  background: oklch(0.3 0.1 162);
  border: 1px solid oklch(0.5 0.15 162);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  color: oklch(0.95 0.02 162);
  animation: roy-b20-toast-slide 0.4s ease-out;
}

@keyframes roy-b20-toast-slide {
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-micro-toast-slide-b20 { animation: none; }
}`,
  },

  {
    id: "micro-toggle-switch-b20",
    name: "Toggle Switch",
    category: "microinteractions",
    description: "A modern toggle switch with smooth knob slide — settings and preferences",
    tags: ["toggle", "switch", "slide", "settings", "preferences"],
    previewType: "box",
    cssCode: `/* Toggle Switch */
.roycss-micro-toggle-switch-b20 {
  inline-size: 48px;
  block-size: 26px;
  border-radius: 2rem;
  background: oklch(0.3 0.02 250);
  border: 1px solid oklch(0.4 0.05 250);
  position: relative;
  cursor: pointer;
  transition: background 0.3s ease;
}

.roycss-micro-toggle-switch-b20::after {
  content: "";
  position: absolute;
  inset-block-start: 2px;
  inset-inline-start: 2px;
  inline-size: 20px;
  block-size: 20px;
  border-radius: 50%;
  background: oklch(0.9 0.02 250);
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  box-shadow: 0 2px 4px color-mix(in oklch, oklch(0.1 0.02 250) 30%, transparent);
}

.roycss-micro-toggle-switch-b20:hover {
  background: oklch(0.6 0.2 162);
}

.roycss-micro-toggle-switch-b20:hover::after {
  transform: translateX(22px);
}`,
  },

  {
    id: "micro-search-expand-b20",
    name: "Search Bar Expand",
    category: "microinteractions",
    description: "A search icon that expands into a full input on hover — compact navigation pattern",
    tags: ["search", "expand", "input", "navigation", "compact"],
    previewType: "box",
    cssCode: `/* Search Bar Expand */
.roycss-micro-search-expand-b20 {
  inline-size: 36px;
  block-size: 36px;
  border-radius: 2rem;
  background: oklch(0.25 0.03 250);
  border: 1px solid oklch(0.35 0.05 250);
  transition: inline-size 0.3s ease;
  overflow: hidden;
  cursor: pointer;
}

.roycss-micro-search-expand-b20:hover {
  inline-size: 160px;
}`,
  },

  /* ─── CARDS (5) ─── */

  {
    id: "card-image-zoom-b20",
    name: "Image Zoom Card",
    category: "cards",
    description: "A card with an image that zooms on hover — product card and gallery effect",
    tags: ["card", "image", "zoom", "hover", "product"],
    previewType: "card",
    cssCode: `/* Image Zoom Card */
.roycss-card-image-zoom-b20 {
  position: relative;
  inline-size: 144px;
  block-size: 96px;
  border-radius: 1rem;
  overflow: hidden;
  background: oklch(0.2 0.02 250);
}

.roycss-card-image-zoom-b20::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, oklch(0.5 0.15 162), oklch(0.4 0.2 200));
  transition: transform 0.4s ease;
}

.roycss-card-image-zoom-b20:hover::before {
  transform: scale(1.15);
}`,
  },

  {
    id: "card-overlay-reveal-b20",
    name: "Overlay Reveal Card",
    category: "cards",
    description: "A card with an overlay that slides up on hover — image gallery and portfolio pattern",
    tags: ["card", "overlay", "reveal", "hover", "gallery"],
    previewType: "card",
    cssCode: `/* Overlay Reveal Card */
.roycss-card-overlay-reveal-b20 {
  position: relative;
  inline-size: 144px;
  block-size: 96px;
  border-radius: 1rem;
  overflow: hidden;
  background: linear-gradient(135deg, oklch(0.5 0.15 280), oklch(0.4 0.2 330));
}

.roycss-card-overlay-reveal-b20::after {
  content: "View Details";
  position: absolute;
  inset-block-start: 100%;
  inset-inline: 0;
  block-size: 100%;
  background: color-mix(in oklch, oklch(0.1 0.02 250) 80%, transparent);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  color: oklch(0.95 0.02 250);
  font-size: 12px;
  font-weight: 600;
  transition: inset-block-start 0.3s ease;
}

.roycss-card-overlay-reveal-b20:hover::after {
  inset-block-start: 0;
}`,
  },

  {
    id: "card-parallax-tilt-b20",
    name: "Parallax Tilt Card",
    category: "cards",
    description: "A card that tilts in 3D space with layered depth — premium product showcase",
    tags: ["card", "parallax", "tilt", "3d", "depth"],
    previewType: "card",
    cssCode: `/* Parallax Tilt Card */
.roycss-card-parallax-tilt-b20 {
  inline-size: 144px;
  block-size: 96px;
  border-radius: 1rem;
  background: oklch(0.2 0.02 250);
  border: 1px solid oklch(0.3 0.05 250);
  transform-style: preserve-3d;
  transition: transform 0.3s ease;
  box-shadow: 0 4px 10px color-mix(in oklch, oklch(0.1 0.02 250) 30%, transparent);
}

.roycss-card-parallax-tilt-b20:hover {
  transform: perspective(500px) rotateX(10deg) rotateY(-10deg) scale(1.05);
  box-shadow:
    -10px 10px 20px color-mix(in oklch, oklch(0.1 0.02 250) 40%, transparent),
    0 0 20px color-mix(in oklch, oklch(0.6 0.2 162) 20%, transparent);
}`,
  },

  {
    id: "card-flip-3d-b20",
    name: "3D Flip Card",
    category: "cards",
    description: "A card that flips in 3D to reveal content on the back — interactive info card",
    tags: ["card", "flip", "3d", "reveal", "interactive"],
    previewType: "card",
    cssCode: `/* 3D Flip Card */
.roycss-card-flip-3d-b20 {
  inline-size: 144px;
  block-size: 96px;
  perspective: 600px;
}

.roycss-card-flip-3d-b20 > .flip-inner {
  inline-size: 100%;
  block-size: 100%;
  position: relative;
  transform-style: preserve-3d;
  transition: transform 0.6s;
}

.roycss-card-flip-3d-b20:hover > .flip-inner {
  transform: rotateY(180deg);
}`,
  },

  {
    id: "card-glow-border-b20",
    name: "Glow Border Card",
    category: "cards",
    description: "A card with an animated glowing border — attention-grabbing feature container",
    tags: ["card", "glow", "border", "animated", "feature"],
    previewType: "card",
    cssCode: `/* Glow Border Card */
.roycss-card-glow-border-b20 {
  position: relative;
  inline-size: 144px;
  block-size: 96px;
  border-radius: 1rem;
  background: oklch(0.15 0.02 250);
  border: 1px solid oklch(0.3 0.05 250);
  animation: roy-b20-glow-border 2s ease-in-out infinite;
}

@keyframes roy-b20-glow-border {
  0%, 100% { box-shadow: 0 0 10px color-mix(in oklch, oklch(0.6 0.2 162) 20%, transparent); }
  50% { box-shadow: 0 0 25px color-mix(in oklch, oklch(0.6 0.2 162) 40%, transparent); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-card-glow-border-b20 { animation: none; }
}`,
  },

  /* ─── NAVIGATION (4) ─── */

  {
    id: "nav-breadcrumb-b20",
    name: "Breadcrumb Trail",
    category: "navigation",
    description: "A breadcrumb navigation with chevron separators — hierarchy and path indicator",
    tags: ["breadcrumb", "navigation", "path", "hierarchy", "trail"],
    previewType: "box",
    cssCode: `/* Breadcrumb Trail */
.roycss-nav-breadcrumb-b20 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 12px;
  color: oklch(0.6 0.02 250);
}

.roycss-nav-breadcrumb-b20 > * + *::before {
  content: "›";
  margin-inline-end: 0.5rem;
  color: oklch(0.4 0.02 250);
}`,
  },

  {
    id: "nav-stepper-b20",
    name: "Stepper Progress",
    category: "navigation",
    description: "A horizontal stepper showing progress through multiple steps — checkout and wizard",
    tags: ["stepper", "steps", "progress", "wizard", "checkout"],
    previewType: "box",
    cssCode: `/* Stepper Progress */
.roycss-nav-stepper-b20 {
  display: flex;
  align-items: center;
  gap: 0;
  inline-size: 140px;
}

.roycss-nav-stepper-b20 > .step {
  inline-size: 20px;
  block-size: 20px;
  border-radius: 50%;
  background: oklch(0.6 0.2 162);
  border: 2px solid oklch(0.6 0.2 162);
  z-index: 1;
}

.roycss-nav-stepper-b20 > .step.inactive {
  background: transparent;
  border-color: oklch(0.4 0.05 250);
}

.roycss-nav-stepper-b20 > .connector {
  flex: 1;
  block-size: 2px;
  background: oklch(0.6 0.2 162);
}

.roycss-nav-stepper-b20 > .connector.inactive {
  background: oklch(0.3 0.05 250);
}`,
  },

  {
    id: "nav-tabs-underline-b20",
    name: "Tabs with Underline",
    category: "navigation",
    description: "Tab navigation with an animated underline that slides between active tabs",
    tags: ["tabs", "navigation", "underline", "animated", "slide"],
    previewType: "box",
    cssCode: `/* Tabs with Underline */
.roycss-nav-tabs-underline-b20 {
  display: flex;
  gap: 1rem;
  border-block-end: 2px solid oklch(0.3 0.05 250);
  padding-block-end: 0.5rem;
}

.roycss-nav-tabs-underline-b20 > .tab {
  font-size: 12px;
  color: oklch(0.6 0.02 250);
  cursor: pointer;
  padding-block-end: 0.5rem;
  margin-block-end: -0.5rem;
  border-block-end: 2px solid transparent;
  transition: border-color 0.3s ease, color 0.3s ease;
}

.roycss-nav-tabs-underline-b20 > .tab.active,
.roycss-nav-tabs-underline-b20 > .tab:hover {
  color: oklch(0.95 0.02 250);
  border-block-end-color: oklch(0.6 0.2 162);
}`,
  },

  {
    id: "nav-sidebar-slide-b20",
    name: "Sidebar Slide",
    category: "navigation",
    description: "A sidebar that slides in from the left — mobile menu and drawer pattern",
    tags: ["sidebar", "slide", "drawer", "mobile", "menu"],
    previewType: "box",
    cssCode: `/* Sidebar Slide */
.roycss-nav-sidebar-slide-b20 {
  inline-size: 0;
  block-size: 80px;
  background: oklch(0.2 0.02 250);
  border-block-end: 1px solid oklch(0.3 0.05 250);
  overflow: hidden;
  transition: inline-size 0.3s ease;
}

.roycss-nav-sidebar-slide-b20:hover {
  inline-size: 120px;
}`,
  },

  /* ─── FORMS (4) ─── */

  {
    id: "form-input-glow-b20",
    name: "Glow Input Focus",
    category: "forms",
    description: "An input field that glows on focus — modern form interaction feedback",
    tags: ["input", "form", "glow", "focus", "feedback"],
    previewType: "box",
    cssCode: `/* Glow Input Focus */
.roycss-form-input-glow-b20 {
  inline-size: 120px;
  block-size: 36px;
  border-radius: 0.5rem;
  background: oklch(0.2 0.02 250);
  border: 2px solid oklch(0.35 0.05 250);
  padding-inline: 0.75rem;
  color: oklch(0.9 0.02 250);
  font-size: 13px;
  transition: all 0.3s ease;
}

.roycss-form-input-glow-b20:focus {
  outline: none;
  border-color: oklch(0.6 0.2 162);
  box-shadow: 0 0 0 3px color-mix(in oklch, oklch(0.6 0.2 162) 20%, transparent);
}`,
  },

  {
    id: "form-checkbox-custom-b20",
    name: "Custom Checkbox",
    category: "forms",
    description: "A custom-styled checkbox with smooth check animation — modern form replacement",
    tags: ["checkbox", "form", "custom", "check", "animation"],
    previewType: "box",
    cssCode: `/* Custom Checkbox */
.roycss-form-checkbox-custom-b20 {
  inline-size: 24px;
  block-size: 24px;
  border-radius: 6px;
  border: 2px solid oklch(0.4 0.05 250);
  background: oklch(0.2 0.02 250);
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
}

.roycss-form-checkbox-custom-b20:hover {
  border-color: oklch(0.6 0.2 162);
}

.roycss-form-checkbox-custom-b20::after {
  content: "";
  position: absolute;
  inset-block-start: 3px;
  inset-inline-start: 7px;
  inline-size: 6px;
  block-size: 11px;
  border: solid oklch(0.95 0.02 250);
  border-width: 0 2px 2px 0;
  transform: rotate(45deg) scale(0);
  transition: transform 0.2s ease;
}

.roycss-form-checkbox-custom-b20:checked,
.roycss-form-checkbox-custom-b20.active {
  background: oklch(0.6 0.2 162);
  border-color: oklch(0.6 0.2 162);
}

.roycss-form-checkbox-custom-b20:checked::after,
.roycss-form-checkbox-custom-b20.active::after {
  transform: rotate(45deg) scale(1);
}`,
  },

  {
    id: "form-radio-custom-b20",
    name: "Custom Radio Button",
    category: "forms",
    description: "A custom radio button with smooth fill animation — modern form styling",
    tags: ["radio", "form", "custom", "fill", "animation"],
    previewType: "box",
    cssCode: `/* Custom Radio Button */
.roycss-form-radio-custom-b20 {
  inline-size: 22px;
  block-size: 22px;
  border-radius: 50%;
  border: 2px solid oklch(0.4 0.05 250);
  background: oklch(0.2 0.02 250);
  cursor: pointer;
  transition: border-color 0.2s ease;
  position: relative;
}

.roycss-form-radio-custom-b20:hover {
  border-color: oklch(0.6 0.2 162);
}

.roycss-form-radio-custom-b20::after {
  content: "";
  position: absolute;
  inset: 3px;
  border-radius: 50%;
  background: oklch(0.6 0.2 162);
  transform: scale(0);
  transition: transform 0.2s ease;
}

.roycss-form-radio-custom-b20:checked,
.roycss-form-radio-custom-b20.active {
  border-color: oklch(0.6 0.2 162);
}

.roycss-form-radio-custom-b20:checked::after,
.roycss-form-radio-custom-b20.active::after {
  transform: scale(1);
}`,
  },

  {
    id: "form-float-label-b20",
    name: "Floating Label Input",
    category: "forms",
    description: "An input with a label that floats up on focus — space-efficient form pattern",
    tags: ["form", "input", "label", "floating", "compact"],
    previewType: "box",
    cssCode: `/* Floating Label Input */
.roycss-form-float-label-b20 {
  position: relative;
  inline-size: 120px;
  block-size: 40px;
}

.roycss-form-float-label-b20::before {
  content: "Email";
  position: absolute;
  inset-block-start: 50%;
  inset-inline-start: 0.75rem;
  transform: translateY(-50%);
  font-size: 13px;
  color: oklch(0.5 0.02 250);
  pointer-events: none;
  transition: all 0.2s ease;
}

.roycss-form-float-label-b20:focus-within::before,
.roycss-form-float-label-b20:hover::before {
  inset-block-start: 0;
  transform: translateY(-50%) scale(0.8);
  color: oklch(0.6 0.2 162);
}`,
  },

  /* ─── VISUAL (4) ─── */

  {
    id: "vis-avatar-ring-b20",
    name: "Avatar with Ring",
    category: "visual",
    description: "An avatar with a gradient ring border — profile and user display component",
    tags: ["avatar", "ring", "profile", "gradient", "user"],
    previewType: "box",
    cssCode: `/* Avatar with Ring */
.roycss-vis-avatar-ring-b20 {
  inline-size: 60px;
  block-size: 60px;
  border-radius: 50%;
  padding: 3px;
  background: conic-gradient(
    from 0deg,
    oklch(0.6 0.2 162),
    oklch(0.55 0.25 200),
    oklch(0.5 0.2 280),
    oklch(0.6 0.2 162)
  );
}

.roycss-vis-avatar-ring-b20 > .avatar-inner {
  inline-size: 100%;
  block-size: 100%;
  border-radius: 50%;
  background: oklch(0.3 0.05 250);
  border: 2px solid oklch(0.15 0.02 250);
}`,
  },

  {
    id: "vis-badge-gradient-b20",
    name: "Gradient Badge",
    category: "visual",
    description: "A badge with a gradient background — status indicator and label component",
    tags: ["badge", "gradient", "status", "label", "indicator"],
    previewType: "box",
    cssCode: `/* Gradient Badge */
.roycss-vis-badge-gradient-b20 {
  display: inline-flex;
  align-items: center;
  padding: 0.25rem 0.75rem;
  border-radius: 2rem;
  background: linear-gradient(135deg, oklch(0.6 0.2 162), oklch(0.55 0.25 200));
  color: oklch(0.98 0.01 250);
  font-size: 11px;
  font-weight: 600;
  box-shadow: 0 2px 8px color-mix(in oklch, oklch(0.6 0.2 162) 30%, transparent);
}`,
  },

  {
    id: "vis-modal-backdrop-blur-b20",
    name: "Modal Backdrop Blur",
    category: "visual",
    description: "A modal backdrop with blur effect — modern overlay and dialog pattern",
    tags: ["modal", "backdrop", "blur", "overlay", "dialog"],
    previewType: "background",
    cssCode: `/* Modal Backdrop Blur */
.roycss-vis-modal-backdrop-blur-b20 {
  inline-size: 100%;
  block-size: 100%;
  background: color-mix(in oklch, oklch(0.05 0.01 250) 50%, transparent);
  backdrop-filter: blur(8px) saturate(120%);
  border-radius: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
}`,
  },

  {
    id: "vis-divider-gradient-b20",
    name: "Gradient Divider",
    category: "visual",
    description: "A horizontal divider with a gradient fade — modern section separator",
    tags: ["divider", "gradient", "separator", "section", "line"],
    previewType: "box",
    cssCode: `/* Gradient Divider */
.roycss-vis-divider-gradient-b20 {
  inline-size: 120px;
  block-size: 2px;
  border-radius: 1px;
  background: linear-gradient(
    90deg,
    transparent,
    oklch(0.6 0.2 162) 50%,
    transparent
  );
}`,
  },

  /* ─── HOVER (4) ─── */

  {
    id: "hover-image-zoom-b20",
    name: "Image Zoom Hover",
    category: "hover",
    description: "An image/element that zooms in on hover — gallery and thumbnail interaction",
    tags: ["hover", "image", "zoom", "scale", "gallery"],
    previewType: "box",
    cssCode: `/* Image Zoom Hover */
.roycss-hover-image-zoom-b20 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1rem;
  overflow: hidden;
  background: linear-gradient(135deg, oklch(0.5 0.15 162), oklch(0.4 0.2 200));
  transition: transform 0.3s ease;
}

.roycss-hover-image-zoom-b20:hover {
  transform: scale(1.1);
}`,
  },

  {
    id: "hover-text-underline-slide-b20",
    name: "Underline Slide Hover",
    category: "hover",
    description: "An underline that slides in from left to right on hover — link and nav effect",
    tags: ["hover", "underline", "slide", "link", "nav"],
    previewType: "text",
    cssCode: `/* Underline Slide Hover */
.roycss-hover-text-underline-slide-b20 {
  position: relative;
  cursor: pointer;
}

.roycss-hover-text-underline-slide-b20::after {
  content: "";
  position: absolute;
  inset-block-start: 100%;
  inset-inline-start: 0;
  inline-size: 100%;
  block-size: 2px;
  background: oklch(0.6 0.2 162);
  transform: scaleX(0);
  transform-origin: left;
  transition: transform 0.3s ease;
}

.roycss-hover-text-underline-slide-b20:hover::after {
  transform: scaleX(1);
}`,
  },

  {
    id: "hover-icon-bounce-b20",
    name: "Icon Bounce Hover",
    category: "hover",
    description: "An icon that bounces up on hover — playful micro-interaction for buttons",
    tags: ["hover", "icon", "bounce", "playful", "micro"],
    previewType: "box",
    cssCode: `/* Icon Bounce Hover */
.roycss-hover-icon-bounce-b20 {
  inline-size: 60px;
  block-size: 60px;
  border-radius: 1rem;
  background: oklch(0.25 0.03 250);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  cursor: pointer;
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.roycss-hover-icon-bounce-b20:hover {
  transform: translateY(-6px);
}`,
  },

  {
    id: "hover-color-swap-b20",
    name: "Color Swap Hover",
    category: "hover",
    description: "Element swaps background and text colors on hover — clean button interaction",
    tags: ["hover", "color", "swap", "invert", "button"],
    previewType: "box",
    cssCode: `/* Color Swap Hover */
.roycss-hover-color-swap-b20 {
  inline-size: 80px;
  block-size: 80px;
  border-radius: 1rem;
  background: oklch(0.6 0.2 162);
  border: 2px solid oklch(0.6 0.2 162);
  transition: all 0.3s ease;
  cursor: pointer;
}

.roycss-hover-color-swap-b20:hover {
  background: transparent;
  border-color: oklch(0.6 0.2 162);
}`,
  },

  /* ─── TEXT (4) ─── */

  {
    id: "text-typewriter-b20",
    name: "Typewriter Effect",
    category: "text",
    description: "Text that types out character by character — terminal and hero text effect",
    tags: ["text", "typewriter", "typing", "terminal", "hero"],
    previewType: "text",
    previewText: "Hello World",
    cssCode: `/* Typewriter Effect */
.roycss-text-typewriter-b20 {
  overflow: hidden;
  white-space: nowrap;
  border-inline-end: 3px solid oklch(0.6 0.2 162);
  animation: roy-b20-typewriter 3s steps(11) forwards, roy-b20-cursor 0.5s step-end infinite;
}

@keyframes roy-b20-typewriter {
  from { inline-size: 0; }
  to { inline-size: 100%; }
}

@keyframes roy-b20-cursor {
  50% { border-inline-end-color: transparent; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-text-typewriter-b20 { animation: none; inline-size: auto; border-inline-end: none; }
}`,
  },

  {
    id: "text-strike-through-b20",
    name: "Animated Strikethrough",
    category: "text",
    description: "A strikethrough line that animates across text — todo list and completed state",
    tags: ["text", "strikethrough", "animated", "todo", "completed"],
    previewType: "text",
    cssCode: `/* Animated Strikethrough */
.roycss-text-strike-through-b20 {
  position: relative;
  cursor: pointer;
}

.roycss-text-strike-through-b20::after {
  content: "";
  position: absolute;
  inset-block-start: 50%;
  inset-inline-start: 0;
  inline-size: 0;
  block-size: 2px;
  background: oklch(0.6 0.2 25);
  transition: inline-size 0.3s ease;
}

.roycss-text-strike-through-b20:hover::after {
  inline-size: 100%;
}`,
  },

  {
    id: "text-split-color-b20",
    name: "Split Color Text",
    category: "text",
    description: "Text with top half one color and bottom half another — creative split effect",
    tags: ["text", "split", "color", "gradient", "creative"],
    previewType: "text",
    cssCode: `/* Split Color Text */
.roycss-text-split-color-b20 {
  background: linear-gradient(
    to bottom,
    oklch(0.9 0.02 250) 0%,
    oklch(0.9 0.02 250) 49%,
    oklch(0.6 0.2 162) 51%,
    oklch(0.6 0.2 162) 100%
  );
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
}`,
  },

  {
    id: "text-gradient-animate-b20",
    name: "Animated Text Gradient",
    category: "text",
    description: "Text with a gradient that continuously shifts — eye-catching heading effect",
    tags: ["text", "gradient", "animated", "shift", "heading"],
    previewType: "text",
    cssCode: `/* Animated Text Gradient */
.roycss-text-gradient-animate-b20 {
  background: linear-gradient(
    90deg,
    oklch(0.7 0.2 162),
    oklch(0.65 0.25 200),
    oklch(0.7 0.2 280),
    oklch(0.65 0.25 330),
    oklch(0.7 0.2 162)
  );
  background-size: 200% auto;
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
  animation: roy-b20-text-gradient 4s linear infinite;
}

@keyframes roy-b20-text-gradient {
  to { background-position: 200% center; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-text-gradient-animate-b20 { animation: none; }
}`,
  },
];
