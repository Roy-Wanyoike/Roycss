import type { CSSEffect } from "./roycss-types";

/**
 * Batch 22 — Skeleton & Image Effects (30 effects)
 *
 * Ferrum gap fill: many skeleton-loader and image-reveal patterns were
 * underrepresented in the RoyCSS library. This batch adds:
 *
 * Skeletons (15):
 *   wave, pulse-grid, circle-avatar, text-lines-v2, card-full, list, profile,
 *   article, table, sidebar, navbar, comment, notification, dashboard, chat
 *
 * Image effects (15):
 *   zoom-pan, reveal-up, shutter-horizontal, split-diagonal, tilt-3d-v2,
 *   grayscale-to-color, blur-to-sharp, overlay-slide, rotate-zoom, pan-right,
 *   circle-mask, clip-triangle, flip-3d, vignette, duotone
 *
 * All effects use OKLCH colors, CSS logical properties, `roycss-` class prefix,
 * `roy-b22-` keyframe prefix, and respect `prefers-reduced-motion`.
 */
export const effectsBatch22: CSSEffect[] = [
  /* ════════════════════════════════════════════════════════════════
   * SKELETON LOADERS (15)
   * ════════════════════════════════════════════════════════════════ */

  /* 1 — skeleton-wave ──────────────────────────────────────────── */
  {
    id: "skeleton-wave-b22",
    name: "Skeleton Wave",
    category: "loaders",
    description: "A skeleton placeholder with a soft horizontal wave shimmer that crosses the surface",
    tags: ["skeleton", "wave", "shimmer", "loading", "placeholder"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface", "custom-property"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Wave */
.roycss-skeleton-wave-b22 {
  inline-size: 220px;
  block-size: 90px;
  border-radius: 0.75rem;
  background: oklch(0.279 0.037 260.03);
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-wave-b22::before {
  content: "";
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 120% 60% at 0% 50%,
      color-mix(in oklch, oklch(0.711 0.035 256.79) 35%, transparent) 0%,
      transparent 60%);
  background-size: 200% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-wave-sweep 1.8s ease-in-out infinite;
}

@keyframes roy-b22-wave-sweep {
  0%   { background-position: 150% 0; }
  100% { background-position: -150% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-wave-b22::before { animation: none; opacity: 0.4; }
}`,
  },

  /* 2 — skeleton-pulse-grid ───────────────────────────────────── */
  {
    id: "skeleton-pulse-grid-b22",
    name: "Skeleton Pulse Grid",
    category: "loaders",
    description: "A 3×3 grid of skeleton cells pulsing in staggered rhythm",
    tags: ["skeleton", "grid", "pulse", "loading", "stagger"],
    previewType: "loader",
    childCount: 9,
    spacing: "md",
    radius: "sm",
    accessibility: "AA",
    responsive: true,
    animations: ["pulse", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "container-queries"],
    cssCode: `/* Skeleton Pulse Grid */
.roycss-skeleton-pulse-grid-b22 {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0.5rem;
  inline-size: 180px;
  block-size: 180px;
}

.roycss-skeleton-pulse-grid-b22 > span {
  border-radius: 0.375rem;
  background: oklch(0.279 0.037 260.03);
  animation: roy-b22-grid-pulse 1.4s ease-in-out infinite;
}

.roycss-skeleton-pulse-grid-b22 > span:nth-child(1) { animation-delay: 0s; }
.roycss-skeleton-pulse-grid-b22 > span:nth-child(2) { animation-delay: 0.1s; }
.roycss-skeleton-pulse-grid-b22 > span:nth-child(3) { animation-delay: 0.2s; }
.roycss-skeleton-pulse-grid-b22 > span:nth-child(4) { animation-delay: 0.3s; }
.roycss-skeleton-pulse-grid-b22 > span:nth-child(5) { animation-delay: 0.4s; }
.roycss-skeleton-pulse-grid-b22 > span:nth-child(6) { animation-delay: 0.5s; }
.roycss-skeleton-pulse-grid-b22 > span:nth-child(7) { animation-delay: 0.6s; }
.roycss-skeleton-pulse-grid-b22 > span:nth-child(8) { animation-delay: 0.7s; }
.roycss-skeleton-pulse-grid-b22 > span:nth-child(9) { animation-delay: 0.8s; }

@keyframes roy-b22-grid-pulse {
  0%, 100% { background: oklch(0.279 0.037 260.03); }
  50%      { background: color-mix(in oklch, oklch(0.711 0.035 256.79) 40%, oklch(0.279 0.037 260.03)); }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-pulse-grid-b22 > span { animation: none; }
}`,
  },

  /* 3 — skeleton-circle-avatar ────────────────────────────────── */
  {
    id: "skeleton-circle-avatar-b22",
    name: "Skeleton Circle Avatar",
    category: "loaders",
    description: "Circular avatar placeholder with concentric pulse ring around it",
    tags: ["skeleton", "circle", "avatar", "pulse", "profile"],
    previewType: "loader",
    spacing: "md",
    radius: "full",
    accessibility: "AA",
    responsive: false,
    animations: ["pulse", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Circle Avatar */
.roycss-skeleton-circle-avatar-b22 {
  inline-size: 220px;
  block-size: 90px;
  display: flex;
  align-items: center;
  gap: 0.875rem;
  padding-inline: 0.75rem;
  border-radius: 0.75rem;
  background: oklch(0.208 0.04 265.75);
}

.roycss-skeleton-circle-avatar-b22::before {
  content: "";
  inline-size: 56px;
  block-size: 56px;
  block-size: 56px;
  border-radius: 9999px;
  background: oklch(0.279 0.037 260.03);
  position: relative;
  box-shadow:
    0 0 0 0 color-mix(in oklch, oklch(0.711 0.035 256.79) 60%, transparent),
    0 0 0 0 color-mix(in oklch, oklch(0.6 0.2 270) 50%, transparent);
  animation: roy-b22-avatar-pulse 1.8s ease-out infinite;
  flex: 0 0 auto;
}

.roycss-skeleton-circle-avatar-b22::after {
  content: "";
  flex: 1;
  block-size: 56px;
  background:
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 0 8px / 100% 12px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 0 30px / 70% 10px no-repeat;
  border-radius: 4px;
}

@keyframes roy-b22-avatar-pulse {
  0%   { box-shadow: 0 0 0 0 color-mix(in oklch, oklch(0.711 0.035 256.79) 70%, transparent); }
  100% { box-shadow: 0 0 0 14px transparent; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-circle-avatar-b22::before { animation: none; }
}`,
  },

  /* 4 — skeleton-text-lines-v2 ────────────────────────────────── */
  {
    id: "skeleton-text-lines-v2-b22",
    name: "Skeleton Text Lines v2",
    category: "loaders",
    description: "Multi-line text placeholder with gradient shimmer sweep and varied widths",
    tags: ["skeleton", "text", "lines", "shimmer", "placeholder"],
    previewType: "loader",
    spacing: "md",
    radius: "sm",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Text Lines v2 */
.roycss-skeleton-text-lines-v2-b22 {
  inline-size: 220px;
  block-size: 110px;
  background:
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 0 0  / 92% 14px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 0 26px / 78% 12px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 0 46px / 88% 12px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 0 66px / 55% 12px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 0 86px / 35% 12px no-repeat,
    transparent;
  border-radius: 0.375rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-text-lines-v2-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(100deg,
    transparent 35%,
    color-mix(in oklch, oklch(0.85 0.04 256) 30%, transparent) 50%,
    transparent 65%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-text-shimmer-v2 1.5s linear infinite;
}

@keyframes roy-b22-text-shimmer-v2 {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-text-lines-v2-b22::after { animation: none; opacity: 0.3; }
}`,
  },

  /* 5 — skeleton-card-full ────────────────────────────────────── */
  {
    id: "skeleton-card-full-b22",
    name: "Skeleton Card Full",
    category: "loaders",
    description: "Full skeleton card with image block, title, and body text — common article loader",
    tags: ["skeleton", "card", "image", "loading", "article"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Card Full */
.roycss-skeleton-card-full-b22 {
  inline-size: 220px;
  block-size: 160px;
  border-radius: 0.75rem;
  background:
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 0 0   / 100% 70px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 86px  / 80% 14px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 108px / 95% 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 124px / 60% 10px no-repeat,
    oklch(0.208 0.04 265.75);
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-card-full-b22::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 20%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-card-full-shimmer 1.6s linear infinite;
}

@keyframes roy-b22-card-full-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-card-full-b22::before { animation: none; opacity: 0.25; }
}`,
  },

  /* 6 — skeleton-list ─────────────────────────────────────────── */
  {
    id: "skeleton-list-b22",
    name: "Skeleton List",
    category: "loaders",
    description: "List of skeleton rows, each with avatar circle and two text lines",
    tags: ["skeleton", "list", "rows", "loading", "placeholder"],
    previewType: "loader",
    spacing: "md",
    radius: "sm",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton List */
.roycss-skeleton-list-b22 {
  inline-size: 220px;
  block-size: 150px;
  background:
    radial-gradient(circle 12px at 22px 22px, oklch(0.279 0.037 260.03) 98%, transparent 100%),
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 44px 14px / 130px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 44px 28px / 90px 8px no-repeat,

    radial-gradient(circle 12px at 22px 64px, oklch(0.279 0.037 260.03) 98%, transparent 100%),
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 44px 56px / 120px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 44px 70px / 70px 8px no-repeat,

    radial-gradient(circle 12px at 22px 106px, oklch(0.279 0.037 260.03) 98%, transparent 100%),
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 44px 98px / 110px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 44px 112px / 60px 8px no-repeat,

    oklch(0.208 0.04 265.75);
  border-radius: 0.75rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-list-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 18%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-list-shimmer 1.7s linear infinite;
}

@keyframes roy-b22-list-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-list-b22::after { animation: none; opacity: 0.25; }
}`,
  },

  /* 7 — skeleton-profile ──────────────────────────────────────── */
  {
    id: "skeleton-profile-b22",
    name: "Skeleton Profile",
    category: "loaders",
    description: "Profile header skeleton with centered avatar, name, and stats row",
    tags: ["skeleton", "profile", "avatar", "header", "loading"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Profile */
.roycss-skeleton-profile-b22 {
  inline-size: 220px;
  block-size: 170px;
  background:
    radial-gradient(circle 30px at 110px 42px, oklch(0.279 0.037 260.03) 99%, transparent 100%),
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 70px 86px / 100px 12px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 60px 104px / 100px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 30px 130px / 40px 14px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 90px 130px / 40px 14px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 150px 130px / 40px 14px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.75rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-profile-b22::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 22%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-profile-shimmer 1.6s linear infinite;
}

@keyframes roy-b22-profile-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-profile-b22::before { animation: none; opacity: 0.25; }
}`,
  },

  /* 8 — skeleton-article ──────────────────────────────────────── */
  {
    id: "skeleton-article-b22",
    name: "Skeleton Article",
    category: "loaders",
    description: "Article skeleton with headline, byline, and body paragraph blocks",
    tags: ["skeleton", "article", "blog", "headline", "loading"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Article */
.roycss-skeleton-article-b22 {
  inline-size: 220px;
  block-size: 170px;
  background:
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 12px 12px / 180px 22px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 42px / 90px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 64px / 196px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 80px / 196px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 96px / 160px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 120px / 196px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 136px / 120px 10px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.75rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-article-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 20%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-article-shimmer 1.8s linear infinite;
}

@keyframes roy-b22-article-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-article-b22::after { animation: none; opacity: 0.25; }
}`,
  },

  /* 9 — skeleton-table ────────────────────────────────────────── */
  {
    id: "skeleton-table-b22",
    name: "Skeleton Table",
    category: "loaders",
    description: "Skeleton table with header row and 3 data rows of cells",
    tags: ["skeleton", "table", "grid", "rows", "loading"],
    previewType: "loader",
    spacing: "md",
    radius: "sm",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Table */
.roycss-skeleton-table-b22 {
  inline-size: 220px;
  block-size: 130px;
  background:
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 0 0   / 100% 22px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 8px 34px  / 60px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 78px 34px / 70px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 158px 34px / 50px 10px no-repeat,

    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 8px 60px  / 60px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 78px 60px / 70px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 158px 60px / 50px 10px no-repeat,

    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 8px 86px  / 60px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 78px 86px / 70px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 158px 86px / 50px 10px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.5rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-table-b22::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 18%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-table-shimmer 1.7s linear infinite;
}

@keyframes roy-b22-table-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-table-b22::before { animation: none; opacity: 0.25; }
}`,
  },

  /* 10 — skeleton-sidebar ─────────────────────────────────────── */
  {
    id: "skeleton-sidebar-b22",
    name: "Skeleton Sidebar",
    category: "loaders",
    description: "Sidebar skeleton with logo block and stacked nav item placeholders",
    tags: ["skeleton", "sidebar", "nav", "loading", "layout"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Sidebar */
.roycss-skeleton-sidebar-b22 {
  inline-size: 180px;
  block-size: 170px;
  background:
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 12px 12px / 100px 22px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 50px  / 156px 16px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 74px  / 156px 16px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 98px  / 156px 16px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 12px 122px / 100px 16px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.75rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-sidebar-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 20%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-sidebar-shimmer 1.6s linear infinite;
}

@keyframes roy-b22-sidebar-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-sidebar-b22::after { animation: none; opacity: 0.25; }
}`,
  },

  /* 11 — skeleton-navbar ──────────────────────────────────────── */
  {
    id: "skeleton-navbar-b22",
    name: "Skeleton Navbar",
    category: "loaders",
    description: "Navbar skeleton with logo block on left and link blocks on right",
    tags: ["skeleton", "navbar", "header", "loading", "layout"],
    previewType: "loader",
    spacing: "md",
    radius: "sm",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Navbar */
.roycss-skeleton-navbar-b22 {
  inline-size: 220px;
  block-size: 60px;
  background:
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 12px 18px / 80px 24px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 130px 22px / 40px 16px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 178px 22px / 40px 16px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.5rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-navbar-b22::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 20%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-navbar-shimmer 1.5s linear infinite;
}

@keyframes roy-b22-navbar-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-navbar-b22::before { animation: none; opacity: 0.25; }
}`,
  },

  /* 12 — skeleton-comment ─────────────────────────────────────── */
  {
    id: "skeleton-comment-b22",
    name: "Skeleton Comment",
    category: "loaders",
    description: "Comment skeleton with avatar circle, name, and two text lines",
    tags: ["skeleton", "comment", "avatar", "loading", "social"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Comment */
.roycss-skeleton-comment-b22 {
  inline-size: 220px;
  block-size: 90px;
  background:
    radial-gradient(circle 18px at 28px 32px, oklch(0.279 0.037 260.03) 99%, transparent 100%),
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 56px 18px / 80px 10px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 56px 36px / 130px 8px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 56px 50px / 110px 8px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 56px 64px / 60px 8px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.75rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-comment-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 18%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-comment-shimmer 1.6s linear infinite;
}

@keyframes roy-b22-comment-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-comment-b22::after { animation: none; opacity: 0.25; }
}`,
  },

  /* 13 — skeleton-notification ────────────────────────────────── */
  {
    id: "skeleton-notification-b22",
    name: "Skeleton Notification",
    category: "loaders",
    description: "Notification card skeleton with icon block, title, and message line",
    tags: ["skeleton", "notification", "toast", "icon", "loading"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Notification */
.roycss-skeleton-notification-b22 {
  inline-size: 220px;
  block-size: 70px;
  background:
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 12px 18px / 34px 34px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 56px 16px / 130px 12px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 56px 34px / 100px 8px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 56px 48px / 70px 8px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.75rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-notification-b22::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 22%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-notif-shimmer 1.5s linear infinite;
}

@keyframes roy-b22-notif-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-notification-b22::before { animation: none; opacity: 0.25; }
}`,
  },

  /* 14 — skeleton-dashboard ───────────────────────────────────── */
  {
    id: "skeleton-dashboard-b22",
    name: "Skeleton Dashboard",
    category: "loaders",
    description: "Dashboard skeleton with KPI cards row and a chart placeholder below",
    tags: ["skeleton", "dashboard", "kpi", "chart", "loading"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Dashboard */
.roycss-skeleton-dashboard-b22 {
  inline-size: 220px;
  block-size: 160px;
  background:
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 10px 10px  / 60px 60px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 80px 10px  / 60px 60px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 150px 10px / 60px 60px no-repeat,
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 10px 80px / 200px 70px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.75rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-dashboard-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 20%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-dashboard-shimmer 1.8s linear infinite;
}

@keyframes roy-b22-dashboard-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-dashboard-b22::after { animation: none; opacity: 0.25; }
}`,
  },

  /* 15 — skeleton-chat ────────────────────────────────────────── */
  {
    id: "skeleton-chat-b22",
    name: "Skeleton Chat",
    category: "loaders",
    description: "Chat thread skeleton with two incoming bubbles and one outgoing bubble",
    tags: ["skeleton", "chat", "message", "bubble", "loading"],
    previewType: "loader",
    spacing: "md",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["shimmer", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Skeleton Chat */
.roycss-skeleton-chat-b22 {
  inline-size: 220px;
  block-size: 150px;
  background:
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 10px 12px  / 120px 18px no-repeat,
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 10px 36px  / 80px 12px no-repeat,

    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 90px 62px  / 120px 18px no-repeat,
    linear-gradient(oklch(0.279 0.037 260.03), oklch(0.279 0.037 260.03)) 90px 86px  / 100px 12px no-repeat,

    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 10px 110px / 140px 18px no-repeat,
    linear-gradient(oklch(0.322 0.04 265), oklch(0.322 0.04 265)) 10px 134px / 70px 12px no-repeat,
    oklch(0.208 0.04 265.75);
  border-radius: 0.75rem;
  position: relative;
  overflow: hidden;
}

.roycss-skeleton-chat-b22::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(110deg,
    transparent 30%,
    color-mix(in oklch, oklch(0.711 0.035 256.79) 18%, transparent) 50%,
    transparent 70%);
  background-size: 250% 100%;
  background-repeat: no-repeat;
  animation: roy-b22-chat-shimmer 1.7s linear infinite;
}

@keyframes roy-b22-chat-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -50% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .roycss-skeleton-chat-b22::before { animation: none; opacity: 0.25; }
}`,
  },

  /* ════════════════════════════════════════════════════════════════
   * IMAGE EFFECTS (15)
   * ════════════════════════════════════════════════════════════════ */

  /* 16 — img-zoom-pan ─────────────────────────────────────────── */
  {
    id: "img-zoom-pan-b22",
    name: "Image Zoom Pan",
    category: "hover",
    description: "Image zooms in and pans diagonally on hover — classic gallery reveal effect",
    tags: ["image", "zoom", "pan", "hover", "gallery"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["scale", "translate"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Zoom Pan */
.roycss-img-zoom-pan-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(135deg,
      oklch(0.65 0.18 270) 0%,
      oklch(0.55 0.22 320) 50%,
      oklch(0.7 0.18 200) 100%);
  background-size: 100% 100%;
  background-position: center;
  transition: background-size 0.6s ease, background-position 0.6s ease;
  overflow: hidden;
}

.roycss-img-zoom-pan-b22:hover {
  background-size: 160% 160%;
  background-position: 70% 30%;
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-zoom-pan-b22 { transition: none; }
  .roycss-img-zoom-pan-b22:hover { background-size: 100% 100%; background-position: center; }
}`,
  },

  /* 17 — img-reveal-up ────────────────────────────────────────── */
  {
    id: "img-reveal-up-b22",
    name: "Image Reveal Up",
    category: "hover",
    description: "Image hidden by a curtain that slides up on hover to reveal it",
    tags: ["image", "reveal", "curtain", "hover", "mask"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate", "keyframes"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "clip-path"],
    cssCode: `/* Image Reveal Up */
.roycss-img-reveal-up-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(135deg,
      oklch(0.7 0.15 35) 0%,
      oklch(0.55 0.22 350) 100%);
  position: relative;
  overflow: hidden;
}

.roycss-img-reveal-up-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: oklch(0.208 0.04 265.75);
  transform: translateY(0);
  transition: transform 0.55s cubic-bezier(0.65, 0, 0.35, 1);
}

.roycss-img-reveal-up-b22:hover::after {
  transform: translateY(-100%);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-reveal-up-b22::after { transition: none; }
}`,
  },

  /* 18 — img-shutter-horizontal ───────────────────────────────── */
  {
    id: "img-shutter-horizontal-b22",
    name: "Image Shutter Horizontal",
    category: "hover",
    description: "Image revealed by two horizontal shutters sliding apart on hover",
    tags: ["image", "shutter", "horizontal", "reveal", "hover"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Shutter Horizontal */
.roycss-img-shutter-horizontal-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(45deg,
      oklch(0.6 0.2 160) 0%,
      oklch(0.7 0.18 200) 100%);
  position: relative;
  overflow: hidden;
}

.roycss-img-shutter-horizontal-b22::before,
.roycss-img-shutter-horizontal-b22::after {
  content: "";
  position: absolute;
  inset-inline: 0;
  block-size: 50%;
  background: oklch(0.208 0.04 265.75);
  transition: transform 0.5s cubic-bezier(0.7, 0, 0.3, 1);
}

.roycss-img-shutter-horizontal-b22::before {
  inset-block-start: 0;
}

.roycss-img-shutter-horizontal-b22::after {
  inset-block-end: 0;
}

.roycss-img-shutter-horizontal-b22:hover::before {
  transform: translateY(-100%);
}

.roycss-img-shutter-horizontal-b22:hover::after {
  transform: translateY(100%);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-shutter-horizontal-b22::before,
  .roycss-img-shutter-horizontal-b22::after { transition: none; }
}`,
  },

  /* 19 — img-split-diagonal ───────────────────────────────────── */
  {
    id: "img-split-diagonal-b22",
    name: "Image Split Diagonal",
    category: "hover",
    description: "Image revealed by two diagonal halves sliding apart on hover",
    tags: ["image", "diagonal", "split", "reveal", "clip-path"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "clip-path"],
    cssCode: `/* Image Split Diagonal */
.roycss-img-split-diagonal-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(60deg,
      oklch(0.7 0.18 280) 0%,
      oklch(0.6 0.2 320) 100%);
  position: relative;
  overflow: hidden;
}

.roycss-img-split-diagonal-b22::before,
.roycss-img-split-diagonal-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: oklch(0.208 0.04 265.75);
  transition: transform 0.55s cubic-bezier(0.6, 0, 0.4, 1);
}

.roycss-img-split-diagonal-b22::before {
  clip-path: polygon(0 0, 100% 0, 0 100%);
  transform-origin: top left;
}

.roycss-img-split-diagonal-b22::after {
  clip-path: polygon(100% 0, 100% 100%, 0 100%);
  transform-origin: bottom right;
}

.roycss-img-split-diagonal-b22:hover::before {
  transform: translate(-60%, -60%);
}

.roycss-img-split-diagonal-b22:hover::after {
  transform: translate(60%, 60%);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-split-diagonal-b22::before,
  .roycss-img-split-diagonal-b22::after { transition: none; }
}`,
  },

  /* 20 — img-tilt-3d-v2 ───────────────────────────────────────── */
  {
    id: "img-tilt-3d-v2-b22",
    name: "Image Tilt 3D v2",
    category: "3d-transforms",
    description: "3D perspective tilt on hover with depth shadow — v2 with smoother spring",
    tags: ["image", "3d", "tilt", "perspective", "hover"],
    previewType: "box",
    spacing: "none",
    radius: "lg",
    accessibility: "AA",
    responsive: false,
    animations: ["rotate", "scale"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "3d-transforms"],
    cssCode: `/* Image Tilt 3D v2 */
.roycss-img-tilt-3d-v2-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 1rem;
  background:
    linear-gradient(135deg,
      oklch(0.55 0.22 30) 0%,
      oklch(0.65 0.2 350) 100%);
  transform-style: preserve-3d;
  transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1),
              box-shadow 0.4s ease;
  box-shadow: 0 4px 12px oklch(0 0 0 / 0.2);
}

.roycss-img-tilt-3d-v2-b22:hover {
  transform: perspective(800px) rotateX(12deg) rotateY(-12deg) scale(1.04);
  box-shadow:
    -10px 14px 28px oklch(0 0 0 / 0.35),
    0 0 0 1px color-mix(in oklch, oklch(0.7 0.2 350) 50%, transparent);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-tilt-3d-v2-b22 { transition: none; }
  .roycss-img-tilt-3d-v2-b22:hover { transform: none; }
}`,
  },

  /* 21 — img-grayscale-to-color ───────────────────────────────── */
  {
    id: "img-grayscale-to-color-b22",
    name: "Image Grayscale to Color",
    category: "filters",
    description: "Image starts grayscale and fades to full color on hover",
    tags: ["image", "grayscale", "color", "filter", "hover"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["filter"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Grayscale to Color */
.roycss-img-grayscale-to-color-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    radial-gradient(circle at 30% 30%, oklch(0.7 0.22 25) 0%, transparent 50%),
    radial-gradient(circle at 70% 70%, oklch(0.6 0.25 200) 0%, transparent 50%),
    linear-gradient(135deg, oklch(0.55 0.2 320), oklch(0.7 0.18 35));
  filter: grayscale(1);
  transition: filter 0.5s ease;
}

.roycss-img-grayscale-to-color-b22:hover {
  filter: grayscale(0);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-grayscale-to-color-b22 { transition: none; filter: grayscale(0); }
}`,
  },

  /* 22 — img-blur-to-sharp ────────────────────────────────────── */
  {
    id: "img-blur-to-sharp-b22",
    name: "Image Blur to Sharp",
    category: "filters",
    description: "Image starts blurred and sharpens to focus on hover",
    tags: ["image", "blur", "focus", "filter", "hover"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["filter"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Blur to Sharp */
.roycss-img-blur-to-sharp-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(135deg,
      oklch(0.7 0.18 200) 0%,
      oklch(0.6 0.22 250) 100%);
  filter: blur(8px);
  transition: filter 0.5s ease;
}

.roycss-img-blur-to-sharp-b22:hover {
  filter: blur(0);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-blur-to-sharp-b22 { transition: none; filter: blur(0); }
}`,
  },

  /* 23 — img-overlay-slide ────────────────────────────────────── */
  {
    id: "img-overlay-slide-b22",
    name: "Image Overlay Slide",
    category: "hover",
    description: "Color overlay slides up from the bottom on hover, with centered caption",
    tags: ["image", "overlay", "slide", "caption", "hover"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Overlay Slide */
.roycss-img-overlay-slide-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(135deg,
      oklch(0.65 0.18 160) 0%,
      oklch(0.55 0.2 200) 100%);
  position: relative;
  overflow: hidden;
}

.roycss-img-overlay-slide-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
    to top,
    color-mix(in oklch, oklch(0.3 0.04 265) 85%, transparent),
    transparent
  );
  transform: translateY(100%);
  transition: transform 0.45s cubic-bezier(0.4, 0, 0.2, 1);
}

.roycss-img-overlay-slide-b22:hover::after {
  transform: translateY(0);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-overlay-slide-b22::after { transition: none; }
}`,
  },

  /* 24 — img-rotate-zoom ──────────────────────────────────────── */
  {
    id: "img-rotate-zoom-b22",
    name: "Image Rotate Zoom",
    category: "hover",
    description: "Image rotates slightly and zooms in on hover — dynamic accent effect",
    tags: ["image", "rotate", "zoom", "hover", "dynamic"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["rotate", "scale"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Rotate Zoom */
.roycss-img-rotate-zoom-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(45deg,
      oklch(0.7 0.2 35) 0%,
      oklch(0.55 0.25 350) 50%,
      oklch(0.6 0.22 290) 100%);
  background-size: 100% 100%;
  transition: transform 0.5s cubic-bezier(0.4, 0, 0.2, 1),
              background-size 0.5s ease;
  overflow: hidden;
}

.roycss-img-rotate-zoom-b22:hover {
  transform: rotate(4deg);
  background-size: 140% 140%;
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-rotate-zoom-b22 { transition: none; }
  .roycss-img-rotate-zoom-b22:hover { transform: none; background-size: 100%; }
}`,
  },

  /* 25 — img-pan-right ────────────────────────────────────────── */
  {
    id: "img-pan-right-b22",
    name: "Image Pan Right",
    category: "hover",
    description: "Image background pans to the right on hover — Ken Burns style drift",
    tags: ["image", "pan", "ken-burns", "hover", "background"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["translate"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Pan Right */
.roycss-img-pan-right-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(110deg,
      oklch(0.55 0.22 280) 0%,
      oklch(0.7 0.2 320) 40%,
      oklch(0.6 0.22 200) 100%);
  background-size: 200% 100%;
  background-position: 0% center;
  transition: background-position 0.7s ease;
}

.roycss-img-pan-right-b22:hover {
  background-position: 100% center;
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-pan-right-b22 { transition: none; }
}`,
  },

  /* 26 — img-circle-mask ──────────────────────────────────────── */
  {
    id: "img-circle-mask-b22",
    name: "Image Circle Mask",
    category: "hover",
    description: "Image revealed through an expanding circle mask on hover",
    tags: ["image", "circle", "mask", "clip-path", "reveal"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["scale"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "clip-path"],
    cssCode: `/* Image Circle Mask */
.roycss-img-circle-mask-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(135deg,
      oklch(0.7 0.2 200) 0%,
      oklch(0.6 0.22 250) 100%);
  position: relative;
  overflow: hidden;
}

.roycss-img-circle-mask-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 50% 50%,
      oklch(0.7 0.2 35) 0%,
      oklch(0.55 0.22 350) 100%);
  clip-path: circle(0% at 50% 50%);
  transition: clip-path 0.55s cubic-bezier(0.65, 0, 0.35, 1);
}

.roycss-img-circle-mask-b22:hover::after {
  clip-path: circle(75% at 50% 50%);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-circle-mask-b22::after { transition: none; }
}`,
  },

  /* 27 — img-clip-triangle ────────────────────────────────────── */
  {
    id: "img-clip-triangle-b22",
    name: "Image Clip Triangle",
    category: "hover",
    description: "Image clipped into a triangle that morphs to a rectangle on hover",
    tags: ["image", "clip", "triangle", "polygon", "morph"],
    previewType: "box",
    spacing: "none",
    radius: "sm",
    accessibility: "AA",
    responsive: false,
    animations: ["clip"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "clip-path"],
    cssCode: `/* Image Clip Triangle */
.roycss-img-clip-triangle-b22 {
  inline-size: 200px;
  block-size: 140px;
  background:
    linear-gradient(45deg,
      oklch(0.6 0.2 30) 0%,
      oklch(0.7 0.18 60) 50%,
      oklch(0.55 0.22 320) 100%);
  clip-path: polygon(50% 0, 100% 100%, 0 100%);
  transition: clip-path 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}

.roycss-img-clip-triangle-b22:hover {
  clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-clip-triangle-b22 { transition: none; clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%); }
}`,
  },

  /* 28 — img-flip-3d ──────────────────────────────────────────── */
  {
    id: "img-flip-3d-b22",
    name: "Image Flip 3D",
    category: "3d-transforms",
    description: "3D Y-axis flip on hover revealing a different background on the back face",
    tags: ["image", "flip", "3d", "rotate", "card"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["rotate"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties", "3d-transforms"],
    cssCode: `/* Image Flip 3D */
.roycss-img-flip-3d-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(135deg,
      oklch(0.65 0.2 280) 0%,
      oklch(0.55 0.22 320) 100%);
  transform-style: preserve-3d;
  transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;
}

.roycss-img-flip-3d-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background:
    linear-gradient(135deg,
      oklch(0.55 0.22 35) 0%,
      oklch(0.7 0.18 60) 100%);
  backface-visibility: hidden;
  transform: rotateY(180deg);
}

.roycss-img-flip-3d-b22:hover {
  transform: rotateY(180deg);
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-flip-3d-b22 { transition: none; }
  .roycss-img-flip-3d-b22:hover { transform: none; }
}`,
  },

  /* 29 — img-vignette ─────────────────────────────────────────── */
  {
    id: "img-vignette-b22",
    name: "Image Vignette",
    category: "filters",
    description: "Image with a soft radial vignette that lightens on hover",
    tags: ["image", "vignette", "radial", "gradient", "filter"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["filter"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Vignette */
.roycss-img-vignette-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    radial-gradient(circle at 50% 50%,
      oklch(0.7 0.18 200) 0%,
      oklch(0.55 0.22 250) 80%,
      oklch(0.208 0.04 265.75) 100%);
  position: relative;
  overflow: hidden;
  transition: filter 0.4s ease;
}

.roycss-img-vignette-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 50% 50%,
    transparent 30%,
    color-mix(in oklch, oklch(0.1 0.04 265) 80%, transparent) 100%);
  transition: opacity 0.5s ease;
  opacity: 1;
}

.roycss-img-vignette-b22:hover::after {
  opacity: 0.2;
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-vignette-b22::after { transition: none; }
}`,
  },

  /* 30 — img-duotone ──────────────────────────────────────────── */
  {
    id: "img-duotone-b22",
    name: "Image Duotone",
    category: "filters",
    description: "Two-tone duotone image effect using mix-blend-mode overlay — mint/purple palette",
    tags: ["image", "duotone", "blend", "filter", "two-tone"],
    previewType: "box",
    spacing: "none",
    radius: "md",
    accessibility: "AA",
    responsive: false,
    animations: ["filter"],
    tokens: ["surface"],
    modernCSS: ["oklch", "color-mix", "logical-properties"],
    cssCode: `/* Image Duotone */
.roycss-img-duotone-b22 {
  inline-size: 200px;
  block-size: 140px;
  border-radius: 0.75rem;
  background:
    linear-gradient(135deg,
      oklch(0.6 0.18 160) 0%,
      oklch(0.5 0.2 200) 50%,
      oklch(0.55 0.22 250) 100%);
  position: relative;
  overflow: hidden;
  transition: filter 0.5s ease;
}

.roycss-img-duotone-b22::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg,
    oklch(0.7 0.22 350) 0%,
    oklch(0.5 0.25 290) 100%);
  mix-blend-mode: color;
  opacity: 0.85;
  transition: opacity 0.5s ease;
}

.roycss-img-duotone-b22::after {
  content: "";
  position: absolute;
  inset: 0;
  background: oklch(0.15 0.05 280);
  mix-blend-mode: multiply;
  opacity: 0.4;
}

.roycss-img-duotone-b22:hover::before {
  opacity: 0.3;
}

@media (prefers-reduced-motion: reduce) {
  .roycss-img-duotone-b22,
  .roycss-img-duotone-b22::before { transition: none; }
}`,
  },
];
